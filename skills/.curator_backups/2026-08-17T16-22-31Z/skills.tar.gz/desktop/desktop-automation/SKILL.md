---
name: desktop-automation
description: Best practices and safety patterns for using computer-use and desktop automation.
---

# Desktop Automation Best Practices

This skill captures learnings and pitfalls for driving the user's desktop via tools like `computer_use`.

## Safety & Style Guidelines
- **User Preference:** The user expects autonomous operation but prioritizes not having their active work interrupted.
- **Do Not Disrupt:** Never close windows, log out, or perform destructive actions unless explicitly requested. Always verify the element label in a SOM capture before clicking, especially near window controls.
- **Communication:** If the AI is struggling to interact with a specific app (e.g., Chrome/Browser), stop and explain why rather than repeatedly sending potentially destructive commands.

## Pitfalls & Troubleshooting
- **Opening a file/editor for the user from the agent shell (Windows/git-bash)** — when the user must edit a file (e.g. paste a secret into `.env`) and `computer_use` is unavailable or `start` silently fails:
  - `cmd //c start "" notepad "C:\path"` can return exit 0 with **no process spawned** — never trust it; verify with `wmic process where "Name='notepad.exe'" get ProcessId`.
  - Bare `notepad.exe "path"` in the terminal tool **blocks** (GUI app holds the console) and the timeout kills the tree — never run it foreground.
  - Literal `&` backgrounding is rejected by the terminal tool. **The reliable fallback: `explorer.exe "C:\path\to\file"`** — opens the file with its default association (`.env` → Notepad) and returns immediately.
  - PowerShell via bash: **single-quote the whole `-Command '...'`** — double quotes make bash expand `$_` (e.g. `{$_.MainWindowTitle}` becomes `{3.MainWindowTitle}` → "term not recognized" spam).
  - `tasklist //FI "IMAGENAME eq X"` silently fails in git-bash (double-slash option, same as `schtasks //Query`) — use `wmic process where "Name='X'" get ...` instead.
  - `explorer.exe` can spawn duplicate windows for the same file — dedupe: `powershell -NoProfile -Command 'Get-Process notepad | Select-Object -First 1 | Stop-Process -Force'`, then confirm one remains via `Get-Process notepad | Select-Object Id,MainWindowTitle` (title shows `<file> - Notepad`).
- **Background Interaction Failures:** Background input (like `type` or keyboard shortcuts) often fails for specific window classes (e.g., `Chrome_WidgetWin_1`). 
  - *Fix:* Bring the window to front (`focus_app` or user-assisted) or explicitly request a foreground-mode action if the tool supports it.
- **Element Mapping Errors:** UI elements in SOM/AX captures can shift. Always perform a fresh `capture` immediately before a `click` or `type` action to ensure indices are valid.
- **Identifying Targets:** If an app is not found, use `list_apps` to verify the exact string expected by `cua-driver` before trying to target it with `capture` or `focus_app`.
- **`computer_use` capture returns 0×0 / empty elements while `hermes computer-use doctor` reports ALL OK** (verified 2026-08-13): the cua-driver MCP session is a zombie. Doctor only health-checks the driver binary, not the live MCP session. Confirm by grepping the Hermes agent log (`~/AppData/Local/hermes/logs/agent.log`) for `session 'hermes-<id>' has ended; tool call '<...>' was rejected. Call start_session with this id to revive it`. Fix = a fresh cua-driver session (restart the gateway or kill+respawn cua-driver). Note: `Stop-Process`/`taskkill /F /IM cua-driver.exe` may be access-denied and the process survives — and the user may explicitly forbid a gateway restart while other processes are live; then fall back to a manual action on the user's machine instead of forcing it.
- **Browser vs. Desktop:** Do not use desktop automation for web browsing tasks that `browser_*` tools can handle reliably. Only reach for desktop automation for native apps (Figma, Outlook, file explorers, etc.).
