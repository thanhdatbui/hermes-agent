---
name: youtube-download-botcheck-camoufox
description: Fix yt-dlp bị YouTube bot-check ("Sign in to confirm you're not a bot" / HTTP 403 / NA) khi tải video — dùng Camoufox lấy cookies phiên thật. Áp dụng cho download_by_niche.py (Tiktok-video farm) và mọi tải YouTube.
---

# YouTube download qua bot-check (Camoufox cookies)

## 🛑 STOP GATE (bắt buộc — chi tiết: skill taadaa-farm-ops-rules)
Máy live + script chạy/lỗi → KHÔNG tự sửa code, KHÔNG tự chạy lại, KHÔNG tự probe/tay khi chưa được user yêu cầu.
Lỗi → screencap → gửi ẢNH THẬT (MEDIA:<path> dòng riêng, KHÔNG bọc markdown, KHÔNG gửi đường dẫn text) → DỪng chờ user hướng dẫn.
User hướng dẫn bước nào → encode bước đó vào script + test → mới chạy lại. Nghi ngờ → HỎI.

## Trigger
yt-dlp trả "Sign in to confirm you're not a bot", HTTP 403 rải rác, hoặc "NA" khi probe/tải YouTube.

## Root cause
YouTube chặn theo dấu hiệu **CLIENT** (thiếu browser fingerprint thật + không giải được JS challenge), không chỉ IP. Proxy di động đổi IP KHÔNG hết; chỉ cookies phiên / browser thật mới qua được.

## Fix: Camoufox cookies (đã kiểm chứng 17/08/2026)
1. Cài: `python -m pip install "camoufox[geoip]"` + `python -m camoufox fetch` (venv-core024 đã có sẵn)
2. Mở `https://www.youtube.com` headless bằng Camoufox (script mẫu: `D:\CodexRuntime\tiktok-video\test-camoufox-cookies-20260816.py`) → export cookies Netscape → `youtube-cookies-netscape.txt`
3. yt-dlp chạy với `--cookies-file <file>` → qua bot-check (test: video Numb OK, channel flat OK)
4. **Cookies hết hạn ~vài giờ** → refresh lại bằng Camoufox khi download bắt đầu "Sign in" trở lại

## Tích hợp download_by_niche.py
- Flag `--cookies-file <path>` → `options["cookies"]`
- Flag `--proxy-pool <xlsx>` → xoay proxy mỗi video (format `host:port:user:pass` từ PROXYgandienthoai.xlsx → `http://user@host:port`; 76 proxy, ~số lớn active)
- Flag `--continue-on-insufficient` → skip folder thiếu nguồn, không dừng batch

## Alternative (CHƯA hoàn chỉnh — ưu tiên cookies)
`scripts/browser_download.py`: Camoufox mở video → bắt response `googlevideo.com/videoplayback` → tải bằng `page.context.request.get()`. ⚠️ URL bắt được là SABR segments (cần Range headers) — tải trực tiếp ra `sabr.malformed_config` (31B). Dùng cookies cho yt-dlp là đường chắc ăn.

## Discovery notes (source_pool_builder.py)
- `--auto-discover` KHÔNG tự qualify: phải thêm `--qualify-videos` mới ghi `qualified_video_count` (0/176 sources khi thiếu flag — nguồn rác lọt pool)
- Tỉ lệ thực: YouTube 120 / IG 55 / TikTok 5 — TikTok extractor broken trong yt-dlp 2026.07.04, IG bị 403 → `PLATFORMS = ("youtube",)`; qualify xong 70 sources ≥45 video (67 YT)
- `max_folders_per_channel=1` → ~70 folder hoàn thành tối đa
- `youtube_profile` regex phải là `@[\w.-]+` (handle Unicode tiếng Việt có dấu bị chặn bởi `[A-Za-z0-9._-]+`)
- Bỏ `@vtv24` (kênh nhà nước — user không muốn dùng)

## Pitfalls
- Chrome/Edge cookies KHÔNG đọc được (Chromium App-Bound/DPAPI — yt-dlp issue #7271); Firefox profile có nhưng không có YouTube session → dùng Camoufox
- deno JS runtime: `pip install deno` + `--js-runtimes "deno:<venv>/Scripts/deno.exe"` + `--extractor-args "youtube:jsc=deno"` — vẫn fail "n challenge solving failed" nếu thiếu solver; cookies là chìa khóa
- Probe hàng loạt (1 request/video liên tục) vẫn bị chặn dù có cookies — cookies tươi + request lẻ thì OK; chạy dài cần refresh cookies giữa chừng
- MobiProxy panel giới hạn kết nối đồng thời: test 8 worker song song → 407 auth fail dù proxy sống (uptime 92h) — chạy parallel 1