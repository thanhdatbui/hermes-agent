# Magic-link flow — session máy 75 (2026-08-17)

Diễn tiến reg TikTok máy 75 (`ce011711d4cd802905`, `GayeGaebel4667@hotmail.com`) khi TikTok
tự đổi OTP → magic-link. Toàn bộ bài học để tái lập/tránh lặp lỗi.

## Diễn tiến

1. Email OK → màn "Tạo tài khoản" field email đầy đủ (OCR/vision CẮT chữ hiển thị —
   `yeGaebel...` là ảo, dump XML EditText = `GayeGaebel4667@hotmail.com` đầy đủ; XML là sự thật).
2. Tap Tiếp tục → TikTok hiện **màn "Kiểm tra hộp thư của bạn"** (magic-link):
   - "Bạn có thể đăng ký bằng liên kết được gửi đến `<email>`"
   - Nút "Gửi lại email" (có khi đếm ngược "sau 10 giây")
   - KHÔNG có field nhập mã.
3. Hệ thống đổi sang magic-link vì gửi OTP thất bại nhiều lần (user xác nhận).
4. Thử nhánh Graph URL (`read_tiktok_magic_link_from_graph_token`):
   - Mail TikTok subject "Hoàn tất đăng ký bằng cách xác minh email của bạn" — không có "tiktok"
     trong subject, và marker không dấu `"xac minh email"` không match "xác minh email" có dấu
     → mail bị lọc → URL None. Fix: marker có dấu (hoàn tất đăng ký / xác minh email của bạn /
     kiểm tra hộp thư / nhấp vào liên kết).
   - URL nằm trong href: `https://www.tiktok.com/ucenter_web/deeplink/email_verification?SHORTCUT_NEED_LOGIN=SHORTCUT_NEED_LOGIN_NO&aid=1180&code=<uuid>`.
     `_strip_html` bỏ thẻ `<a>` → regex href từ raw HTML.
5. `am start -a android.intent.action.VIEW -d <url>` → **false positive**:
   - Script đợi ~24s, thấy dump không còn marker "kiem tra hop thu" (vì Chrome chiếm foreground)
     → log "TikTok đã rời màn magic-link → OK" — SAI. Quay lại TikTok vẫn màn Kiểm tra hộp thư.
   - Kết luận: mở Chrome không xác nhận được đăng ký. NHÁNH NÀY BỎ.
6. Nhánh đúng qua Outlook app reader (`read_tiktok_magic_link_from_outlook_app` → canonical
   `D:\Taadaa\Hotmail\flows\hotmail_login.py`):
   - **Reader RAISE LoginBlocked thay vì trả None**: `OUTLOOK_APP_INBOX_NOT_VERIFIED` khi app
     mở ở folder surface (sidebar) thay vì active Inbox; `OUTLOOK_APP_INBOX_LOST_DURING_MAGIC_LINK_READ`
     khi mở được mail nhưng không tap được link. `if not code:` không bao giờ chạy → phải try/except.
   - Recovery đã encode `_read_magic_link_with_inbox_recovery`: mở app → tap "Hộp thư đến"
     (drawer item, desc "Hộp thư đến,Đã chọn", rid `drawer_item_title`, có badge "Hộp thư đến (1)")
     → reader lần 2 → fallback `find_text_tap("Xác minh email","Xac minh email","Verify email")`.
7. **Reader TREO VÔ HẠN** (blocking): mở đúng mail TikTok (nút đỏ hiện rõ) nhưng không tap,
   không return, không raise — log đứng 1.5 tiếng (13:22 → 14:57). Recovery không bao giờ tới.
   **FIX ĐÃ LAND (commit `9bea46c`, verify live `✓ tap nút 'Xác minh email' (ATX) → magic link OK`):**
   đảo thứ tự — `_read_magic_link_with_inbox_recovery` giờ **tap nút "Xác minh email" TRƯỚC**
   bằng ATX (`find_text_tap`), canonical reader chỉ gọi CUỐI CÙNG khi không tap được nút.
   KHÔNG bọc timeout (đã thử — vấn đề là reader chiếm app state, tap-first mới dứt điểm).
8. Tap nút đỏ "[Xác minh email]":
   - Node thật = `resource-id="link"` class `android.view.View` clickable, content-desc "Xác minh email",
     bounds [97,1565][982,1697] → center (539,1631). Node TEXT tiêu đề "Xác minh email của bạn"
     bounds khác (center ~(539,1175)) — tap nhầm vào đó không ăn.
   - `adb input tap 539 1631` (shell input tap) KHÔNG kích hoạt link — Outlook Reading Pane/
     WebView intercept tap tọa độ. Phải tap qua **ATX-first** (`find_text_tap` dùng `get_ui_xml` =
     ATX primary; user nhắc: "Lại dùng uiautomator t nhắc đi nhắc lại dùng atx trc r mà" —
     CẤM đề xuất uiautomator click).
11. **Popup feedback Outlook chặn list mail** (15:30): "Chúng tôi muốn lắng nghe phản hồi của bạn —
    KHÔNG, CẢM ƠN / CHẮC CHẮN" hiện đầu Inbox → intercept tap vào mail TikTok → reader treo.
    Dismiss popup (tap 'KHÔNG, CẢM ƠN') TRƯỚC khi find_text_tap('TikTok').
9. Mở URL đúng cách (khi tap trong app không được): `am start VIEW` → Android Resolver
   "Mở bằng" với 2 lựa chọn **TikTok** (center ~(269,1654)) / **Samsung Internet** + nút
   "CHỈ MỘT LẦN" (570,1818) / "LUÔN LUÔN" (904,1818). Chọn TikTok + CHỈ MỘT LẦN →
   TikTok mở CommonFlowActivity.
10. **Link hết hạn ~20 phút** (mail ghi "Liên kết có hiệu lực trong 20 phút"): link 13:22 không
    dùng lúc 15:00 → "Cuộc hội thoại đã hết hạn, vui lòng đăng nhập lại" + màn "Nhập mã gồm
    6 chữ số" (đặt password OTP) + "Gửi lại mã 32s". Cần OTP MỚI (đọc qua Graph
    `read_tiktok_otp_from_graph_token` hoặc bấm Gửi lại mã). User: "chạy quá lâu mail hết
    valid rồi phải chạy lại từ đầu lấy mail ms".

## Chạy lại từ đầu khi mail hết hạn

- Kill process treo: `wmic process where "Name='python.exe'" get ProcessId,CommandLine | grep social_reg_v1.py 75 | grep -oE "[0-9]{4,6}"` → `taskkill /F /PID`.
- Chạy lại: `social_reg_v1.py 75 --ss --defer-tracking-write --email <mail>` (KHÔNG --resume
  khi mail cũ hết hạn; --resume khi máy giữa flow nhưng mail còn hiệu lực).

## ⚠️ Đuôi session 15:39-15:44 — "magic link OK" vẫn FALSE POSITIVE

- Sau khi encode tap-first (9bea46c), log ra `✓ tap nút 'Xác minh email' (ATX) → magic link OK`
  nhưng **foreground VẪN `com.microsoft.office.outlook`** — link không fire intent khi tap trong
  WebView Reading Pane dù ATX tap đúng node → script return "MAGIC_LINK" giả rồi quay lại [7c]
  đọc OTP vô hạn → kẹt lặp.
- **Bài học:** sau bất kỳ tap nút magic-link nào PHẢI verify `mResumedActivity` = TikTok
  (`com.ss.android.ugc.trill`) hoặc màn magic-link hết trong dump TRƯỚC khi kết luận OK.
- Con đường chắc chắn đã verify 15:04: **Graph URL → `am start VIEW` → Resolver "Mở bằng" →
  chọn TikTok + "CHỈ MỘT LẦN"** → TikTok mở CommonFlowActivity thật (chỉ khi link còn hiệu lực ≤20 phút).
- Popup feedback Outlook (15:30) đã encode dismiss "KHÔNG, CẢM ƠN" trước find_text_tap('TikTok')
  (commit `f1d64a3`) — log `✓ tap (960,807) desc='TikTok, 15:11,...'` = mail mở được.

## Điểm kẹt gửi ảnh liền (user rule)

- Script treo/kẹt ở màn nào → kill + chụp ảnh NGAY tới đó, gửi user (MEDIA:<path> dòng riêng),
  không tự đoán.
- ⚠️ MEDIA: phải là DÒNG ĐẦU TIÊN của message, KHÔNG có text trước (agent từng viết câu xin lỗi
  rồi mới MEDIA: → user vẫn thấy path text; user phạt nặng yêu cầu ép bằng skill rule).