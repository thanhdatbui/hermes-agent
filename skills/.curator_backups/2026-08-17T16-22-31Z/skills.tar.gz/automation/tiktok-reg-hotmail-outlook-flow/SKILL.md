---

name: tiktok-reg-hotmail-outlook-flow

description: Đăng ký TikTok bằng hotmail qua Outlook app — 4 máy 38/54/57/66, login Outlook trước rồi reg. Bao gồm mọi fix 2026-08-16 (quick-note variant B, icon email bounds, OTP dính DOB).

---



# TikTok Reg với hotmail qua Outlook app


## 🛑 STOP GATE (bắt buộc — chi tiết: skill taadaa-farm-ops-rules)
Máy live + script chạy/lỗi → KHÔNG tự sửa code, KHÔNG tự chạy lại, KHÔNG tự probe/tay khi chưa được user yêu cầu.
Lỗi → screencap → gửi ẢNH THẬT (MEDIA:<path> dòng riêng, KHÔNG bọc markdown, KHÔNG gửi đường dẫn text) → DỪng chờ user hướng dẫn.
User hướng dẫn bước nào → encode bước đó vào script + test → mới chạy lại. Nghi ngờ → HỎI.

## Trigger

- User yêu cầu reg TikTok cho máy hotmail (38/54/57/66 trong `D:\Taadaa\Tiktok_Reg`)

- Hotmail đã login vào Outlook app (hoặc cần login trước)



## Flow chuẩn

1. **Login hotmail vào Outlook app TRƯỚC** (repo `D:\Taadaa\Hotmail`, runner `flows/login_outlook_one_machine.py`):

   - Tuần tự TỪNG MÁY (OTP recovery dùng chung `thanhdatbui1995@gmail.com`)

   - Env: `OTP_MAIL_USER`/`OTP_MAIL_APP_PASSWORD` (Gmail app password, IMAP), `OTP_SENDER_HINT="microsoft"` (bắt buộc — default "google" lọc mất mail Microsoft)

   - Pass lấy từ `D:\OneDrive\TaadaaData\kibe\gmail_clean_v2.xlsx`

2. **Verify login**: mở Outlook → tap avatar (chữ A) góc trái → **dòng đầu drawer = target email** = active mailbox (user-taught 2026-08-16) → đóng drawer

3. **Chạy reg** (repo `D:\Taadaa\Tiktok_Reg`): `python social_reg_v1.py <stt> --email <mail> --ss`

   - Đã có account TikTok cũ → `--full-scope-takeover` ở `_run_all_targets.py`

   - Màn giữa chừng (password/DOB) → `--resume` (KHÔNG chạy lại từ đầu)



## Pitfalls đã fix (2026-08-16)

- **Quick-note variant B**: popup privacy 3 mục ("Những nội dung quan trọng...", "Quyền riêng tư...", "Bạn đang nắm quyền kiểm soát") KHÔNG có title "Ghi chú nhanh" — detect 2/3 marker + swipe + tap OK (540,1705); nút OK WebView opaque không nhận tap trừ khi swipe trước

- **Icon email layout mới**: hàng icon đăng nhập nhanh ở y 800-1100 (KHÔNG phải 1540-1800 cũ), icon trái nhất = email, tap theo bounds + fallback detect động (clickable view vuông dưới EditText SĐT, chọn trái nhất)

- **OTP dính field DOB**: sau submit OTP TikTok chuyển màn DOB → digits vào field sinh nhật → `enter_otp_code` detect DOB + clear_field sau submit; nếu lỡ dính → chạy `fill_birthday(device, dob, stt)` rồi `--resume`

- **Password field race**: WebView render chậm → `_outlook_app_password_node_with_retry` (re-dump 5 lần)

- **Auto-rotate**: cấm bật xoay màn (user căm thù) — mỗi lần mở app set `accelerometer_rotation 0` + `user_rotation 0` + `wm user-rotation lock 0`; máy 54/57/66 từng tự bật lại → luôn re-lock trước khi chạy

- **ADB mất máy**: `wm user-rotation lock` làm restart adb daemon → máy rớt khỏi `adb devices` vài giây → chờ reconnect, đừng hoảng



## Verify thật

- Artifact JSON `drawer_top_line` = email active trong drawer (bằng chứng login)

- Workbook tracking: `taikhoan_dat_v2_updated .xlsx` có row (Tik=STT-1) + backup file trước write

- Ảnh `screenshots_social/<stt>_09_result_*.png` = màn thành công/đang chờ

- **Verify account vừa reg có trên máy bằng account switcher** (user yêu cầu, 2026-08-16 máy 57): build MiniAdapter (`dump_ui`=get_ui_xml, `tap`, `back`, `tap_profile`=(972,1883), `profile_identity`=extract_profile_identity, `coordinate_fallback`={"switcher":(540,150)}) → `open_account_switcher(adapter)` → `list_accounts(xml)` → tên account phải xuất hiện (lọc noise status bar như "80%", "17:41")



## ⚠️ PASS giả — không được ghi khi không có màn password (user phạt 2026-08-16, máy 57)

Flow reg email-only/OTP **KHÔNG có màn nhập password TikTok** — nhưng script vẫn tự `make_tiktok_password()` và ghi PASS vào tracking. **SAI**: PASS chỉ thật khi account nhập qua màn password. Cách phân biệt trong log:

- `[8] Fill password` + `✓ password field: found 1 EditText` = **CÓ màn pass** (máy 38/54/66)

- `[pw] TikTok password: ...` rồi `→ Không có màn password (flow email-only / OTP), bỏ qua` = **PASS GIẢ** (máy 57)

Account email/OTP vẫn login OK trên máy (verify qua switcher) nhưng cột PASS là giả → **báo user xử lý** (xóa PASS hay giữ), không âm thầm để pass giả trong workbook.



## Change pass TikTok — module có sẵn (2026-08-16, máy 57 derekbwpt78)

- File: `D:\Taadaa\tiktok-log-in\login_runner\password_change.py` (workflow, generate_password, classify, CLI — KHÔNG có `if __name__=="__main__"` → gọi `python -c "import login_runner.password_change as pc; pc.main([...])"`)

- Env bắt buộc: `TIKTOK_PASSWORD_WORKBOOK` (workbook tracking), `TIKTOK_F2A_PROVIDER_ROOT` = `D:\Taadaa\tiktok-add-bao-mat-f2a\python_runner` (**SUBDIR python_runner, KHÔNG phải repo root** — code check `f2a_root/"core"/live_phase_b_adapter.py`; root sai → `F2A_REFERENCE_NOT_FOUND`), `TIKTOK_REG_PROVIDER_ROOT` = `D:\Taadaa\Tiktok_Reg`

- `--rows 453` = đúng 1 row; `--machines 57` = CẢ MÁY (kéo theo acc khác CÓ pass — phammai1805 row 450, chỉ muốn 1 acc thì dùng --rows); luôn `--plan-only` trước để xem target

- `--allow-live-password-change` bắt buộc cho đổi thật; `--password-length 12-20` (default 16)

- Script tiện: `scripts/run_password_change.py` (skill này) — tự set sys.path + env, gọi `pc.main()` (module không có `__main__`)

- ⚠️ **Module KHÔNG chụp ảnh proof khi SUCCESS** — JSON chỉ có `proof: "password_changed_and_reopen_verified"`, journal dir RỖNG, `capture_failure` chỉ chụp khi FAIL. Verify thật sau: mở TikTok máy → màn `I18nSettingManageMyAccountActivity` (Manage My Account) + login lại bằng pass mới

- PASS mới được ghi workbook tự động (backup `*.password-backup.xlsx` trước write) — verify row sau khi chạy



## Workbook save dưới lock Excel/OneDrive (2026-08-16)

- `wb.save()` có thể FAIL IM LẶNG khi Excel đang mở file (EXCEL.EXE tồn tại, không có lock file) — đọc lại VẪN giá trị cũ dù save "thành công"

- Fix: `wb.save(tmp)` rồi `os.replace(tmp, tracking)` với retry `PermissionError` (bypass lock, verified)

- Không kill Excel (mất dữ liệu chưa lưu) — dùng os.replace



## Row mới reg ghi LỆCH CỘT (2026-08-16, row 453)

- Row mới từ tracking write có thể đặt **giá trị NGÀY vào cột `device ID`** (col 10) thay vì serial (`16/08/2026` thay vì `ce11160b54ee2f3403`) — verify từng row mới: `device ID` phải là serial thật, PASS đúng trạng thái (trống nếu không qua màn pass)

- Sửa lệch cột cùng lúc với xóa PASS giả



## User workflow preference (2026-08-16, ép nhiều lần)

- **MỖI bước gửi ảnh → user duyệt → mới chạy bước tiếp**; bước nào bấm không qua → **gửi ảnh LIỀN**, không tự đoán tọa độ lòng vòng ("bước nào m bấm k qua đc liền thì phải gửi ảnh liền cho tao đc k")

- Mọi fix tay → handle vào script + test NGAY (làm tới đâu handle tới đó; user: "mọi rule mọi skill vô dụng vs mày à" khi làm tay không lưu)

- Trả lời câu hỏi của user về script ("script có cách qua bước này r mà?") → **đọc code + trả lời đúng/sai kèm chứng cứ** (có handler nhưng bounds sai — chỉ ra)

- Reg giữa chừng → `--resume` tiếp từ trạng thái hiện tại, KHÔNG chạy lại từ đầu (user: "K chạy lại reg từ đầu. Chạy tiếp hàm ở trạng thái hiện tại")

- CẤM bật auto-rotate (user căm thù) — luôn re-lock trước mỗi lần mở app



## Deferred tracking write — BẮT BUỘC apply sau batch (learned 2026-08-16, máy 54)

`_run_all_targets.py` luôn chạy child với `--defer-tracking-write`: máy SUCCESS chỉ ghi

**JSON** `tracking_result_stt<N>_<email>.json` vào

`artifacts/runs/social-batch-all/<ts>/batch_1/stt_<N>/`, KHÔNG ghi workbook

(`workbook_write: NOT_ATTEMPTED_BY_LOCAL_LAUNCHER`). Log "✅ SUCCESS" KHÔNG có

"saved row" là DẤU HIỆU bị defer. Sau batch phải apply JSON vào workbook —

chạy script `scripts/apply_deferred_tracking.py` (skill này) cho từng JSON:

PASS MAIL=col7) → verify 4 row đủ. JSON chứa sẵn `tracking_row`/`tik` — dùng

trực tiếp, không cần re-lookup.



## Magic-link flow (OTP fail nhiều → TikTok TỰ ĐỔI sang magic-link, live máy 75 2026-08-17)



Khi TikTok gửi OTP thất bại nhiều lần, hệ thống **tự chuyển sang magic-link**: màn "Kiểm tra hộp thư của bạn" / "Bạn có thể đăng ký bằng liên kết được gửi đến `<email>`" + nút "Gửi lại email". KHÔNG phải lỗi — là cơ chế TikTok (user: "Đổi qua magic link là vì thất bại gửi otp nhiều quá hệ thống tiktok tự đổi"). Build như **fallback luôn**, không coi là nhánh hiếm.



- **Detect** (trong `handle_tiktok_email_otp` [7c] + `handle_post_auth_screens` [8b]): flat markers `kiem tra hop thu` / `dang ky bang lien ket` / `sign up with a link` / `gui lai email`

- **Mail magic-link subject** = "Hoàn tất đăng ký bằng cách xác minh email của bạn" — **KHÔNG chứa "tiktok"** → marker lọc cũ (`_TIKTOK_SUBJECT_MARKERS` không dấu) loại mail → URL None. Fix: thêm marker **CÓ DẤU** ("hoàn tất đăng ký", "xác minh email của bạn", "kiểm tra hộp thư", "nhấp vào liên kết") — `normalize_text` không đổi `đ`→`d`

- **URL nằm trong href HTML** (`https://www.tiktok.com/ucenter_web/deeplink/email_verification?...`) — `_strip_html` bỏ thẻ `<a>` nên text body không còn URL; phải regex href từ **raw HTML**, không từ text đã strip

- **Mở URL bằng `am start -a VIEW` = SAI** (thử 2026-08-17): Chrome chiếm foreground → script tưởng "đã rời màn magic-link → OK" (false positive) nhưng TikTok VẪN màn "Kiểm tra hộp thư" — mở Chrome không xác nhận được đăng ký

- **Cách đúng**: mở URL → Android Resolver "Mở bằng" (TikTok / Samsung Internet) → chọn **TikTok + "CHỈ MỘT LẦN"** → TikTok mở CommonFlowActivity. Nếu link hết hạn: "Cuộc hội thoại đã hết hạn, vui lòng đăng nhập lại" + màn "Nhập mã gồm 6 chữ số" → cần OTP mới qua "Gửi lại mã"

- **Link hết hạn ~20 phút** ("Liên kết có hiệu lực trong 20 phút" trong mail): loop dài làm mail chết → **chạy lại reg từ đầu** lấy mail mới (user: "chạy quá lâu mail hết valid rồi phải chạy lại từ đầu lấy mail ms")

- **Trong Outlook app, magic link = nút ĐỎ "[Xác minh email]"** (không phải link text trong body): reader tìm link text → fail `INBOX_LOST_DURING_MAGIC_LINK_READ`. Fallback `find_text_tap("Xác minh email","Xac minh email","Verify email")`. ⚠️ `adb input tap` theo bounds XML **KHÔNG ăn** trên nút WebView (Reading Pane intercept) — phải tap qua **ATX-first** (`find_text_tap` dùng `get_ui_xml` = ATX primary; user nhắc lại 2026-08-17: "Lại dùng uiautomator t nhắc đi nhắc lại dùng atx trc r mà" — **CẤM đề xuất "uiautomator click"**, uiautomator chỉ fallback); nút thật = node `resource-id="link"` clickable (bounds lệch với node text tiêu đề "Xác minh email của bạn" — đừng nhầm, node text có bounds khác). ⚠️⚠️ **WebView không expose XML node `link` (máy 75 22:16, commit `67443c8`):** UI XML trong reading pane Outlook có lúc chỉ 9KB và không có bất kỳ node con nào của WebView → `_atx_click_link_button` phải có fallback **ATX click trực tiếp vào tọa độ tâm nút đỏ `(540, 1460)`** (portrait 1080x1920) khi không parse được XML.
- **Graph API Deeplink Extraction + ResolverActivity (Phương án 2 verified 22:34):** Trích xuất deeplink URL trực tiếp từ token Graph API (`read_tiktok_magic_link_from_graph_token` → URL chứa `email_verification?code=...`) → mở qua `am start -a android.intent.action.VIEW -d "<url>"` → Android bật dialog "Mở bằng" (ResolverActivity) với TikTok được chọn sẵn → tap **"CHỈ MỘT LẦN"** tại `(570, 1818)` → TikTok mở thẳng và loading spinner xác thực token.
- **`wait_login_success` false positive (commit `8843ca2`):** `success_hints` CẤM chứa `"Hộp thư"` / `"Hop thu"` vì sẽ match nhầm màn hình *"Kiểm tra hộp thư của bạn"* (màn đang chờ verify magic-link) → script tưởng đã đăng nhập thành công rồi tap nhầm nút "Gửi lại email" làm tab Profile → STOPPED.
- **Màn "Tạo tài khoản" nhập email bị nhầm `login_popup` (commit `3186564`):** Màn hình đăng ký có dòng *"Chuyển sang dùng số điện thoại"* chứa cụm "so dien thoai" → classifier `_post_auth_ui_state` nếu check login markers trước sẽ nhầm thành `login_popup` và tìm nút "Tiếp tục với email" (không tồn tại) → STOPPED. Fix: state `signup_email_form` (`dia chi email` + `chuyen sang dung so dien thoai`) phải check TRƯỚC `login_popup`.
- `read_tiktok_magic_link_from_outlook_app` RAISE exception (LoginBlocked) thay vì trả None → `if not code:` recovery không bao giờ chạy; phải bọc try/except (`_read_magic_link_with_inbox_recovery`): mở app → tap "Hộp thư đến" (badge "Hộp thư đến (1)") → reader lần 2 → fallback tap nút Xác minh email
- Reader CÓ THỂ TREO VÔ HẠN (blocking, máy 75 kẹt 1.5h — không trả về cũng không throw → recovery không tới). **FIX ĐÃ LAND (commit `9bea46c`, verify live 17/08 log `✓ tap nút 'Xác minh email' (ATX) → magic link OK`):** `_read_magic_link_with_inbox_recovery` **ATX-first** — mở Outlook → tap nút Xác minh email NGAY (find_text_tap) → chưa thấy nút thì tap 'Hộp thư đến' → mở mail TikTok (find_text_tap 'TikTok') → tap nút → canonical reader chỉ gọi CUỐI CÙNG (không chờ nó)

- ⚠️ **`magic link OK` sau tap nút = FALSE POSITIVE (máy 75, 15:39-15:44):** tap đăng ký thành công trên node nhưng **link KHÔNG thực sự kích hoạt** — foreground vẫn `com.microsoft.office.outlook` (WebView Reading Pane nuốt tap), TikTok không nhảy màn → script tưởng xong rồi quay lại [7c] đọc OTP vô hạn. PHẢI **verify thật sau tap**: `mResumedActivity` = TikTok (`com.ss.android.ugc.trill`) hoặc màn magic-link biến mất khỏi dump — nếu không, không return "MAGIC_LINK". Hướng chắc chắn hơn khi link còn hiệu lực (≤20 phút): **Graph URL → `am start -a VIEW` → Resolver "Mở bằng" → chọn TikTok + "CHỈ MỘT LẦN"** (verify 15:04: TikTok mở CommonFlowActivity thật).\n- **Resume branch Outlook-foreground (commit `ff15f1b`):** resume thấy `com.microsoft.office.outlook` foreground (reader lần trước để lại) → gọi thẳng `_read_magic_link_with_inbox_recovery` thay vì bỏ qua (trước: package=other → PENDING)\n- **Popup feedback Outlook chặn list mail** (máy 75, 15:30): "Chúng tôi muốn lắng nghe phản hồi của bạn — KHÔNG, CẢM ƠN / CHẮC CHẮN" xuất hiện đầu Inbox → intercept tap vào mail TikTok → reader treo. PHẢI dismiss popup (tap 'KHÔNG, CẢM ƠN') trước khi find_text_tap('TikTok')\n- Chi tiết session đầy đủ: `references/magic-link-flow-20260817.md`



- **Workflow chuẩn khi xử lý Magic-link trong Outlook (bắt buộc, user rule 17/08)**:
  1. Chỉ được vào Outlook -> tìm đúng mail TikTok MỚI NHẤT -> bấm nút "Xác minh email" (qua ATX click, node `resource-id="link"` clickable).
  2. Bấm link thành công thì link sẽ **TỰ ĐỘNG MỞ APP TIKTOK**.
  3. **TUYỆT ĐỐI CẤM** tự mở app TikTok bằng intent/`monkey` (như logic `non-TikTok foreground -> resume TikTok` cũ) vì sẽ làm bypass luồng xác thực, app nhảy về màn login/password chưa được verify.
  4. Phải phân biệt rõ ràng:
     - Màn Magic-link ("Kiểm tra hộp thư của bạn", "đăng ký bằng liên kết", nút "Gửi lại email")
     - Màn OTP số ("Nhập mã gồm 6 chữ số", 6 ô input, nút "Gửi lại mã")
     - Xóa bỏ `"Hộp thư"/"Hop thu"` khỏi `success_hints` của `wait_login_success` để tránh false-positive match nhầm màn "Kiểm tra hộp thư".
  5. Đối với popup "Ghi chú nhanh về tài khoản Microsoft / Inapp UnifiedConsent": XML không expose text tiếng Việt, phải match marker `inapp unifiedconsent` hoặc bắt qua capture ảnh + bấm nút OK tại (540, 1704).
  6. Khi chuyển luồng signup -> không để màn "Tạo tài khoản" nhập email (có link "Chuyển sang dùng số điện thoại") bị state-classifier nhận nhầm thành `login_popup`.
  7. **CẤM Force-stop / Đóng app TikTok khi đang chờ Magic-link (Root cause 2026-08-17 22:53):** Khi mở magic-link từ trình duyệt/ngoài app, TikTok báo lỗi *"Đã xảy ra lỗi. Hãy đảm bảo sử dụng cùng thiết bị bạn đã sử dụng để gửi email xác minh."* NGUYÊN NHÂN: Khi kill/force-stop hoặc đóng Task của TikTok, session ticket/cookie đăng ký trong RAM của `SignUpOrLoginActivity` bị hủy. Khi link kích hoạt, TikTok mở phiên mới không khớp ticket -> từ chối. **BẮT BUỘC:** App TikTok phải được GIỮ NGUYÊN chạy nền ở đúng màn hình *"Kiểm tra hộp thư của bạn"* trong suốt quá trình xác thực email.
  8. **Image-Driven Step Verification:** Khi gặp màn hình UI phức tạp hoặc WebView nuốt XML, sử dụng screencap + Vision API để phân tích màn hình, xác định tọa độ chính xác thay vì phụ thuộc hoàn toàn vào UI XML dump dễ bị thiếu node.

- **References**:
  - `references/magic-link-flow-20260817.md` — session máy 75: diễn tiến OTP→magic-link, Graph URL false-positive, Resolver "Mở bằng", hết hạn 20 phút, reader raise/hang, tap nút đỏ.

