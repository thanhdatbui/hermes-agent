---
name: taadaa-farm-ops-rules
description: Quy tắc vận hành farm Taadaa bắt buộc mọi repo automation — serial-vs-parallel scope và luật handle mọi thao tác tay vào script + skill.
---

# Taadaa Farm Ops Rules (ALL-repo automation)

## 🛑 STOP GATE — ĐỌC TRƯỚC MỌI HÀNH ĐỘNG (user phạt nhiều lần 17/08, BẮT BUỘC)
1. Máy live + script chạy/lỗi → **KHÔNG tự sửa code, KHÔNG tự chạy lại, KHÔNG tự probe, KHÔNG tự thử tay**.
2. Mọi lỗi → screencap → **TỰ ĐỌC ẢNH bằng vision_analyze TRƯỚC khi gửi** (agent có mắt, KHÔNG được \"gửi ảnh cho user xử lý thay\" — user phạt 17/08 tối: \"mày k thể tự đọc hình r hỏi t cách xử lý thay vì chỉ gửi t cái hình k à\") → gửi ảnh thật (`MEDIA:` dòng riêng) + mô tả màn + **đề xuất hướng xử lý dựa trên ảnh đã đọc** → **DỪNG chờ user hướng dẫn**. Báo lỗi PHẢI kèm ảnh đúng lúc kẹt (không gửi ảnh sau khi script đã dừng hẳn và máy đã chuyển màn khác — chụp ngay lúc log dừng).
3. User hướng dẫn bước nào → **ENCODE bước đó vào script + test → mới chạy lại**. Bước chưa hướng dẫn = KHÔNG làm.
4. Nghi ngờ → **HỎI**. Tự làm/sửa khi chưa được yêu cầu = VI PHẠM, dù "chỉ 1 dòng" hay "cho nhanh".
5. **Ảnh màn hình PHẢI hiển thị được**: gửi file ảnh thật `MEDIA:<đường dẫn tuyệt đối>` ở **DÒNG RIÊNG**, KHÔNG bọc markdown (`**`/`` ` ``/`[..]`), kiểm tra file tồn tại trước khi gửi.
6. **CẤM TUYỆT ĐỐI gửi đường dẫn text** (`C:\\Users\\...` hay MEDIA: giữa đoạn văn) thay cho ảnh hiển thị — user chửi lỗi này nhiều lần (session khác 16:02 17/08 vẫn gửi `MEDIA:...` bọc `**` → Telegram nuốt thành text).
7. **CHẨN ĐOÁN ĐƯỢC ≠ ĐƯỢC PHÉP SỬA (vi phạm thật 17/08 tối — user: \"Tao cập nhật policy skill r nhé, kẹt lỗi chỗ nào phải gửi hình báo tao đéo đc tự ý tự sửa đâu\")**: tìm ra root cause (vd log chứng minh tap nick success nhưng notification shade VPN mở đè → verify fail; hoặc detect_add_phone_popup không match bottom-sheet close geometry) **KHÔNG cho phép tự patch code**. Thứ tự đúng: screencap + gửi ảnh + mô tả lỗi (kèm log/XML evidence) → DỪNG chờ user quyết hướng. User CHỈ giao quyền sửa khi hướng dẫn rõ ràng (\"chạy fix đi\" = ủy quyền fix theo HƯỚNG user chốt, vẫn phải test + chạy lại). Phân biệt: user nói \"sao k chọn đc profile?\" = câu HỎI chẩn đoán, không phải lệnh sửa — trả lời bằng evidence (ảnh + log), không tự patch 2 file rồi mới báo.

Quy tắc chung áp dụng cho MỌI repo automation (Tiktok_Reg, Hotmail, add mail khoi phuc, tiktok-video, automation-core, gan-proxy, feed/follow...), không riêng repo nào.

**Inventory 10 repo automation (chốt 2026-08-17, user: "9 repo consumer h lên 10"):** Tiktok_Reg, Hotmail, Tiktok-video, tiktok-log-in, tiktok-follow, tiktok-add-bao-mat-f2a, tiktok-luot nuoi acc, gan-proxy, register gmail + automation-core (lõi). Các repo khác có AGENTS.md (AI-Tools, Hermes, "open claw", "site ban hang clone"...) KHÔNG phải farm repo — đừng đụng khi sweep rule. Khi append rule all-repo: kiểm tra `[ -d "$d/.git" ]` + có AGENTS.md/PROJECT_RULES.md; repo chỉ có AGENTS.md (vd automation-core) phải `git add` từng file riêng (add 2 path khi 1 path thiếu → abort cả, xem `rule-file-append`).

## 1. Tuần tự vs song song (user rule 2026-08-16)

| Phạm vi | Chế độ |
|---|---|
| **Hotmail login** (repo `D:\Taadaa\Hotmail`) + **add mail khôi phục** (repo `D:\Taadaa\add mail khoi phuc`) | **TỪNG MÁY MỘT (tuần tự)** — bắt buộc |
| Mọi repo khác / mọi bước khác (detect, verify máy, đọc source, batch reg, feed...) | **Song song bình thường** |

**Lý do tuần tự bắt buộc:** recovery mailbox `thanhdatbui1995@gmail.com` dùng CHUNG cho mọi máy — Microsoft gửi OTP vào cùng 1 inbox. Chạy 2 máy song song → script đọc nhầm mã máy này nhập vào máy kia (OTP leak). Vì vậy:
- Start máy N → đợi OTP → nhập → verify inbox → CHỈ SAU ĐÓ mới start máy N+1.
- Không bao giờ chạy `login_outlook_app` / `read_otp_mail.py` cho 2 máy cùng lúc.
- Các máy đang chờ không bị treo — chúng chỉ chờ tuần tự ở bước login/add-mail; mọi thứ khác của chúng vẫn chạy song song.

**NGOẠI LỆ 2026-08-17 (hotmail loại 2 + Graph API):** mailbox mua từ boxtaikhoan dạng `mail|pass|refresh_token|client_id` đọc OTP qua **Graph API từ PC** (`hotmail_provider.read_tiktok_otp_from_graph_token`, Tiktok_Reg commit `8752c7b`, bật bằng env `HOTMAIL_TOKEN_LIST`) — mỗi mailbox có token RIÊNG, không dùng chung recovery inbox → đọc **SONG SONG bình thường**, không tuần tự. Tuần tự bắt buộc chỉ còn áp cho shared recovery mailbox / Outlook-app reader (giữ nguyên). Chi tiết: skill `tiktok-registration-ops` → `references/token-otp-graph-reader-20260817.md`.

## 2. Luật handle mọi thao tác tay (user rule 2026-08-16)

> "Bất kỳ thao tác tay nào khi làm việc (tap tay, fix tay, workaround) PHẢI lưu ngay vào skill cấp độ ALL repo automation — handle script lại trước khi báo xong."

Quy trình bắt buộc khi phát hiện màn hình/selector/flow mới hoặc làm tay thành công:
1. **Code hóa ngay** vào canonical script của repo tương ứng (handler + regression test + COMPAT entry nếu repo yêu cầu).
2. **Lưu skill** — skill liên quan repo (vd `hotmail-outlook-automation`, `tiktok-registration-ops`) HOẶC skill all-repo này nếu rule chung.
3. Chỉ sau đó mới coi bước đó "xong" và báo cáo.

Cấm: làm tay xong rồi quên, làm tay rồi báo "máy tự qua", workaround không encode.

## 3. NO-MANUAL-TAP (hard rule, thêm 2026-08-16 sau khi vi phạm lần nữa; CHỐT 2026-08-17)

**CẤM TUYỆT ĐỐI tap/swipe/keyevent bằng tay trên máy thật để "debug nhanh".** Khi gặp màn hình UI mới:
1. DỪNG — không tap gì bằng tay.
2. Chụp ảnh + dump XML (read-only).
3. Viết helper + test cho màn đó trong script.
4. CHẠY SCRIPT để thao tác — nếu script fail, sửa script, chạy lại.
5. Chỉ dùng tay khi thao tác đó đã được encode 100% trong script (script chạy thay tay).

**MỆNH ĐỀ CHỐT 2026-08-17 (user phạt "cái đm script bị lỗi mày fix hay mày đang tự kỉ ngồi làm tay"):**
- **CHỈ TỰ LÀM TAY KHI USER YÊU CẦU** — mọi thao tác adb tay (tap/gõ/broadcast/swipe) ngoài script trên máy thật = VI PHẠM, kể cả "test nhanh" hay "xem thử". User: "chỉ có thể tự làm khi t yêu cầu".
- **Script CHẠY ĐẾN HẾT** — không dừng giữa chừng để "kiểm tra" hay "sửa nhanh" rồi chạy lại vòng vòng. Gặp fail → để script tự chụp ảnh lỗi (guard dưới) → gửi user → DỪNG chờ hướng dẫn.
- **Script guard FAIL_STOPPED (Tiktok_Reg commit `d510afb`):** `except RuntimeError` → tự `screenshot(device, "FAIL_STOPPED_<stt>")` trước `sys.exit(1)` — agent đọc ảnh đó gửi user, KHÔNG tự bấm máy. Áp dụng pattern này cho mọi repo live automation.
- **KHI USER HƯỚNG DẪN = SCRIPT ĐANG LỖI → SỬA SCRIPT NGAY (user nhấn mạnh 2026-08-17):** user gửi ảnh + hướng dẫn ("bấm resend lấy OTP mới nhập lại", "vuốt cho qua"... ) nghĩa là script kẹt ở bước đó → ENCODE hướng dẫn vào canonical script (helper + regression test) TRƯỚC, rồi mới chạy script lại. TUYỆT ĐỐI KHÔNG chạy lại `--resume` hy vọng tự qua — nếu script xử lý đúng thì user đã không phải hướng dẫn. User: "khi t hướng dẫn nghĩa là script bị kẹt lỗi cần phải sửa".
- **USER-CHỤP-ẢNH-DRIVEN (user chốt 2026-08-17, "t chụp tới đâu thì code lại làm theo đúng ý t"):** user chụp ảnh màn hình hướng dẫn tới bước nào → agent code script làm ĐÚNG ý user bước đó → **qua được bước tiếp theo mới coi là handle script xong**; bước nào script không tự qua được → DỪNG, chụp ảnh gửi user chờ hướng dẫn tiếp. Không code vượt trước ý user, không tự chế bước user chưa duyệt.
- Khi user hướng dẫn xong → **encode hướng dẫn vào script** (helper + test) → chạy script, KHÔNG chạy tay theo lời user rồi bỏ.

Vi phạm pattern: "tap tay cho nhanh rồi code sau" = vi phạm rule dù sau đó có code. Thứ tự bắt buộc: CODE TRƯỚC, TAP QUA SCRIPT.

## 4. SEND-SCREENSHOT-ON-FAIL + từng bước duyệt (user rule 2026-08-16, thêm sau vi phạm)

**GỬI ẢNH = GỬI FILE ẢNH HIỂN THỊ (user phạt nhiều lần 2026-08-17, lần cuối yêu cầu "cập nhật skill rule để ép tuân thủ"):** mọi ảnh màn hình gửi user qua Telegram PHẢI là file ảnh thật dạng `MEDIA:<đường dẫn tuyệt đối>` — quy tắc TUYỆT ĐỐI:
1. **MEDIA: phải là DÒNG ĐẦU TIÊN CỦA MESSAGE — KHÔNG CÓ TEXT TRƯỚC** (không "Xin lỗi...", không mô tả, không tiêu đề trước MEDIA:). Vi phạm thật 17/08: agent viết câu xin lỗi trước rồi MEDIA: dòng sau → user VẪN thấy path text thay vì ảnh. Mô tả ảnh đặt SAU dòng MEDIA: hoặc ở message kế tiếp.\n2. **DÙNG BACKSLASH (đã đảo ngược 17/08 chiều, verify THÀNH CÔNG)**: `MEDIA:C:\\Users\\Kibe\\tmp\\m75_stuck.png` — cùng file, backslash hiện ảnh thật (user reply ảnh `file_198.jpg`); **forward slash `MEDIA:C:/...` hiện thành path text** (user phạt "gửi đường dẫn đéo phải file" 2 lần liên tiếp khi agent dùng forward slash 17/08). Trước đó skill ghi ngược (forward slash) là SAI — đã đính chính.
3. Trước khi gửi kiểm tra file tồn tại (`ls -la`) — file .png mới screencap, không gửi folder.
4. KHÔNG bao giờ viết "ảnh ở C:\..." thay cho MEDIA:; KHÔNG nhúng MEDIA: giữa đoạn văn.
5. Nếu đã đúng format (dòng đầu + **BACKSLASH** + file tồn tại) mà user vẫn báo thấy path → BÁO user là lỗi hệ thống render + HỎI cách nhận ảnh, KHÔNG lặp lại format cũ thêm lần nữa.
Ví dụ đúng (toàn bộ message = chỉ 1 dòng MEDIA:, BACKSLASH như đã verify 17/08 chiều):
```
MEDIA:C:\Users\Kibe\tmp\m75_stuck.png
```
7. **SCRIPT TREO (process còn sống nhưng log đứng yên ≥2-3 phút) = LỖI → KILL process ngay + chụp ảnh + gửi user** (user nhắc nhiều lần 17/08: "kẹt ở đâu dừng gửi ảnh tới đó", "chạy kẹt ở đâu dừng gửi ảnh tới đó"). KHÔNG chờ thêm, KHÔNG tự mò sửa tiếp. Đừng để máy kẹt 1.5h như máy 75 (canonical reader `read_tiktok_magic_link_from_outlook_app` TREO VÔ HẠN blocking — helper `_read_magic_link_with_inbox_recovery` đảo thứ tự: tap nút magic link TRƯỚC, reader chỉ gọi cuối).
8. **Tự giác tuân thủ KHÔNG cần user nhắc** (user chốt cuối session 17/08: "hiểu là t vừa nhắc ms hiểu đúng k chứ t k nhắc mày định phá r đúng k"): rule đã có sẵn trong memory/skill thì phải chấp hành TỪ ĐẦU, nhắc lại lần 2 = đã vi phạm 1 lần. Script live chạy → im lặng theo dõi; script dừng/lỗi → ảnh + báo → chờ hướng dẫn; KHÔNG tự patch script giữa chừng dù "thấy vấn đề" hay "nghĩ mình biết fix".
9. **CẤM "sửa" selector/marker đã được verify live chỉ vì suy luận trên giấy** (vi phạm THẬT 17/08 tối — commit `5bd7d4a` đổi QuickNote marker `đ→d` vì tưởng NFD strip được `đ`, làm REGRESS modal kẹt OK vô hạn dù skill máy 66 đã ghi gotcha ngược lại). Khi skill/notes cũ ghi 1 điều đã verify live mà suy luận của mình ra kết quả NGƯỢC LẠI → nghi ngờ suy luận của mình, KHÔNG sửa code theo suy luận; hỏi user hoặc test trên máy không-live trước. Marker tiếng Việt có `đ` (U+0111) LUÔN giữ `đ` sau normalize NFD.
10. **IMAGE-DRIVEN WORKFLOW — ảnh là nguồn phân tích CHÍNH, XML chỉ phụ (user chốt 17/08 tối: "Ý là dùng ảnh để phân tích chứ code vẫn phải viết handle từng bước thử nghiệm qua đc thì ms lưu sai thì revert lại. Cái skill này là cơ bản khi làm automation hình như mày đéo có đúng k")**: XML dump trên surface WebView/Compose (vd Outlook OneAuth QuickNote) CÓ THỂ CHỈ expose label activity ("Inapp UnifiedConsent") — text nội dung KHÔNG ra node → dựa XML toàn nhận SAI màn (máy 75 17/08: dump chỉ thấy `['Inapp UnifiedConsent','60%','19:16']` trong khi ảnh là QuickNote đầy đủ). Vòng lặp đúng cho mọi bước UI: (1) screencap → vision_analyze đọc ảnh (màn gì, nút ở tọa độ nào) → (2) gửi ảnh + mô tả + đề xuất → user duyệt → (3) ENCODE handler vào script (tọa độ/selector từ ẢNH, không từ XML trống) → (4) chạy test → **QUA được mới commit, FAIL thì REVERT** — không giữ code chưa verify. Kết hợp XML (khi có text node) + ảnh xác nhận chéo; ảnh là nguồn sự thật khi 2 nguồn mâu thuẫn. ⚠️ **MỌI ảnh capture dọc đường đều gửi user kiểm tra tiến độ (user 17/08: "Chụp ảnh tới đâu cũng gửi vào đây cho t kiểm tra tiến độ")** — KHÔNG chỉ gửi ảnh lỗi cuối; ảnh giữa chừng (màn vừa đổi sau mỗi tap) cũng phải gửi kèm mô tả màn hiện tại để user bám tiến độ. Khi user hỏi "trước màn này là màn gì? có chụp k?" → trace log timestamp + các ảnh script tự chụp (`screenshots_social/75_*.png`) để dựng chuỗi màn, gửi TẤT CẢ ảnh liên quan (không chỉ ảnh mới nhất).

User phản ứng rất mạnh khi agent tự đoán tọa độ/tự lòng vòng thay vì hỏi. Hai mệnh đề bắt buộc cho live device work (Hotmail/Outlook, reg, feed...):

1. **Bước nào bấm không qua được → GỬI ẢNH LIỀN** — không tự thử tọa độ lòng vòng. Ảnh = `screencap` + gửi MEDIA: kèm mô tả: màn gì, bước nào đang kẹt, đã thử gì. User nhìn ảnh là biết ngay (user am hiểu UI, nhìn 1 phát ra tọa độ đúng).
2. **Bước quan trọng → chờ user duyệt rồi mới chạy tiếp** — khi user yêu cầu "từng bước một", chạy 1 bước → gửi ảnh → dừng chờ "được/chạy tiếp" → mới làm bước sau. KHÔNG tự ý chạy tiếp chuỗi.
3. **CẤM bật auto-rotate / xoay màn** (user: "t căm thù cái đó vl") — xem NO-ROTATION GUARD trong `hotmail-outlook-automation`.

Pattern sai bị phạt: tap tay đoán nhiều tọa độ liên tiếp mà không gửi ảnh; lòng vòng 5-10 bước không hỏi; để máy rơi vào trạng thái xoay ngang.

Bổ sung 2026-08-16 (user phạt "mày cứ tự sửa gặp lỗi chỗ nào script k qua đc ms đc gọi tao"):
- **KHÔNG tự sửa script giữa live run.** Script đã build/duyệt thì chạy nguyên trạng; lỗi mới phát sinh trên máy → gửi ảnh + báo user, user hướng dẫn cách đúng, SAU ĐÓ mới handle vào script (code + test + skill). Không tự "sửa nhanh cho qua" rồi chạy tiếp.
- **Fail giữa chừng → resume từ màn hiện tại** (`--resume` nếu script hỗ trợ, vd `social_reg_v1.py <stt> --resume --email <mail>`), KHÔNG chạy lại từ đầu — chạy lại từ đầu phá state đã đi qua (OTP đã dùng, màn đã qua) và tốn thời gian.
- Máy kẹt ở màn giữa flow (vd màn đặt password TikTok sau DOB) → gọi đúng hàm xử lý bước đó (`fill_birthday`/`fill_password_and_login`...) ở trạng thái hiện tại, không reset.
- **Batch reg chạy SONG SONG bình thường** (chỉ login/add-mail hotmail mới tuần tự) — sau khi login hotmail xong hết, chạy `_run_all_targets.py --full-scope-takeover` một lần; máy nào FAILED thì xem log riêng từng STT (`/d/Taadaa/runtime/kibe/artifacts/runs/social-batch-all/<ts>/batch_1/stt_<n>/stdout.log`) rồi mới gọi user nếu cần.

## 3. Rule Lock — lock/unlock CHỈ khi user ra lệnh (user rule 2026-08-16, áp dụng ALL repo D:\Taadaa)

> "T ra lệnh ms đc lock hoặc unlock. Còn cấm auto lock, chỉ đc auto unlock khi success"

Ba mệnh đề bắt buộc ở MỌI repo automation (automation-core, Tiktok-video, Tiktok_Reg,
tiktok-log-in, register gmail, tiktok-follow, gan-proxy, tiktok-add-bao-mat-f2a, feed...):

1. **Lock/Unlock CHỈ khi user ra lệnh** — không bao giờ tự động.
2. **CẤM auto lock** — mọi `acquire_device_lock` mặc định `user_authorized=False`
   (no-op lease, KHÔNG tạo lock file; không lock tồn tại → chạy không lock).
3. **Auto-unlock CHỈ khi success** — fail/manual-review/abnormal exit GIỮ lock
   (status `handoff`) chặn re-run; chỉ success (DONE) mới release. Cơ chế có sẵn:
   success → `_release_leases()`; không DONE → `_hold_leases_for_recovery()`.

Cách user bật lock cho 1 batch: set env `CODEX_DEVICE_LOCK_DIR` (default
`C:\Users\Kibe\.codex\device-locks`) hoặc param `-LockRoot` → runner pass
`--lock-root` → nhưng vì `user_authorized=False` nên vẫn KHÔNG tạo lock mới — nó
chỉ tôn trọng lock user đã tạo (từ chối nếu bị khóa). Lock thật chỉ tồn tại khi
user chủ động tạo (vd qua script release/acquire tay hoặc `DEVICE_LOCK_ENABLED=1`
cho bản Tiktok_Reg cũ).

**Bổ sung 16/08 (máy 4 mất data + user phạt):** trong `tiktok-luot nuoi acc`
multi-machine feed, toàn bộ cơ chế device-lock/prior-evidence đã bị **XOÁ HẸT**
(agent không được tự ý thêm lại `device_lock_paths` import hay hàm prior-evidence
— `NameError: device_lock_paths` khi chạy thật là do code cũ dùng hàm không
import; user chọn xoá cả cơ chế thay vì fix). Hệ quả: máy fail lần trước tự chạy
lại mỗi lần cron, không còn `recovery_lock_handoff.json` skip. Chi tiết ở
`tiktok-feed-session` references/2026-08-16-swipe-recovery-3session.md.

Quét "all repo đã nhận rule chưa" (đã chạy 2026-08-16): xem recipe đầy đủ ở
skill `automation-core-consumer` mục Device Lock Policy (phân loại wrapper-vs-bản
riêng, grep `user_authorized`, commit `5891817` Tiktok_Reg default True→False,
`6fa3d13` tiktok-add-bao-mat-f2a +user_authorized=False ×4).

**16/08 tối — user CHỐT đổi rule lock (đã plan-audit, đang implement):** lock = **mutex thuần** cho scheduler run-lock — chạy thì lock, xong gỡ hết (success/fail/block/crash đều gỡ). Tránh lock chết ăn lần chạy sau. Bảo vệ "1 máy 1 script 1 lúc" vẫn nguyên trong lúc chạy. Nguồn lock-death THẬT = scheduler-level lock (`automation-core scheduler/base.py:298` default `user_authorized=True`); consumer repos đã `user_authorized=False` (unlocked). Triển khai: kwarg `release_on_terminal` (default **False** opt-in) + CHỈ scheduler truyền True; recovery FAILED_LOCKED retention GIỮ NGUYÊN; retry hôm sau = intentional. Chi tiết thiết kế + test map: skill `automation-core-development` Phase 5 + `references/release-on-terminal-lock-2026-08-16.md`.

**IMPLEMENTED 2026-08-16** (commits `ded3e9b`/`c000af7`/`c12519d` trên branch `codex/release-always-lock`): scheduler run lock giờ tự gỡ trên MỌI outcome kể cả FAILED_LOCKED — state.json giữ `failed-locked` làm report trail, máy fail sẽ retry slot kế tiếp (retry daily vô hạn là intentional; muốn ngừng thì gỡ device khỏi roster). Lock do operator tạo (CLI lock open/inspect/list) và recovery FAILED_LOCKED retention KHÔNG đổi. Full suite 574 pass + 1 pre-existing fail.

## 5. VPN GATE — máy mapped bắt buộc VPN, không VPN = KHÔNG chạy (user chốt 2026-08-17)

> User (17/08): "Tóm lại k bật vpn thì k đc chạy, phải reboot để cho gan proxy thử bật vpn cho
> máy đó (reboot 1-2 lần tránh loop lỗi do gan proxy) r ms cho chạy"

**Rule farm-wide (mọi repo automation dưới `D:\Taadaa`):**
1. Máy **có trong proxy-mapping workbook host** → BẮT BUỘC VPN (`tun0` UP) trước khi chạy bất kỳ
   flow nào (feed/follow/login/reg/2FA...). Không VPN = không chạy.
2. VPN fail khi đang chạy → **recovery ladder** (đã có trong `automation_core.device_recovery`):
   GanProxy **reassign** → chờ watcher bật VPN → fail thì **soft-reboot 1 lần** (reboot 1-2 lần,
   tránh loop lỗi GanProxy lặp mãi) → verify lại VPN → vẫn fail mới **BLOCK** (máy không chạy).
3. **Mapping workbook PHẢI resolve theo host config** — `DEFAULT_PROXY_MAPPING` KHÔNG được
   hardcode `D:\OneDrive\TaadaaData\kibe\PROXYgandienthoai.xlsx` (bug 17/08: admin host 200+
   resolve mapping kibe → serial admin không có trong mapping → `required=False` → **bỏ qua check
   VPN → máy không VPN vẫn chạy**). Dùng `automation_core.preflight.resolve_proxy_mapping_path()`
   (theo `TAADAA_HOST_CONFIG` workbook_root) + **fail-closed** (thiếu file mapping host → raise,
   không fallback kibe, không exempt nhầm).
- Core: `automation_core 0.4.46+` có `resolve_proxy_mapping_path()`;
  consumer: `require_vichanger_connected(..., recover=True)` gọi `recover_missing_android_vpn`.
- Commit pattern đã dùng 17/08: `fix(vpn): host-aware proxy-mapping resolution (fail-closed)` —
  áp cho core + từng consumer repo (tiktok-luot nuoi acc, tiktok-log-in, add-bao-mat,
  add mail khoi phuc, register gmail, Hotmail, gan-proxy). Scan hết repo:
  `grep -rln "PROXYgandienthoai.xlsx" --include=*.py .` (loại venv/site-packages/.git).
- CHÚ Ý: `resolve_proxy_mapping_path` trong core KHÔNG thể import taadaa_host (core không biết
  consumer) — nó tự parse `TAADAA_HOST_CONFIG` YAML đơn giản (đọc key `workbook_root`) giống
  `taadaa_host._load_yaml_simple`, fail-closed nếu thiếu host config/file.

## 6. CẤM tự ý sửa code/flag/lệnh ngoài scope (user rule 16/08 — phạt nặng 2 lần trong 1 session)
> "T đéo hề yêu cầu mày làm device lock" / "script nó đã hoàn chỉnh chỉ việc làm lại cái cron" / "đéo mượn mày tự chế prepare"

Ba lỗi pattern bị phạt trong session canary máy 4/6 (16/08) — CẤM lặp lại:

1. **CẤM tự sửa code để "fix lỗi" khi chạy thật** — canary chạy gặp `NameError: device_lock_paths` → agent tự thêm import vào `core/device_lock.py` + `multi_machine_feed_session.py` mà KHÔNG hỏi. User: "t đéo hề yêu cầu mày làm device lock". Kể cả "fix 1 dòng import" cũng phải HỎI TRƯỚC — vì user có thể chọn hướng khác (ở đây: xoá hết cơ chế lock).
2. **CẤM tự thêm flag/đổi lệnh chạy** — agent tự thêm `--prepare-tiktok` vào lệnh canary (script chuẩn đã có bước prepare qua automation-core). Chạy canary PHẢI giống hệt lệnh đã chạy OK trước đó, chỉ thêm flag khi user yêu cầu.
- **CẤM tự chạy lệnh phá hoại trên máy thật** — `pm clear --cache-only` / `pm clear` (xem reference feed — CẤM TUYỆT ĐỐI, làm mất data nick).
- **CẤM force-stop / close recent app đang trong luồng xác thực magic-link / OAuth token** (Finding 17/08 máy 75): force-stop app TikTok khi đang chờ magic link làm hủy session RAM nội bộ -> mở link lên bị lỗi bảo mật thiết bị *"Hãy đảm bảo sử dụng cùng thiết bị bạn đã sử dụng để gửi email xác minh."*
- **CẤM tự ý XÓA dữ liệu/output/file render** (16/08 — user phạt "Lại tự ý xoá mà đéo hỏi mày giỡn mặt hả") — agent xóa 40 mp4 đã render của folder 363 mà KHÔNG hỏi → mất công render lại. **batch_render.py tự SKIP video đã có output** (`task.output.exists() && !overwrite → skip`) — gặp folder dang dở: chạy LẠI là nó tự skip phần xong, KHÔNG cần xóa gì. Mọi hành động xóa (mp4, avatar, folder, data) phải hỏi user trước.

Nguyên tắc chung: **code/script/lệnh nào user chưa yêu cầu sửa → mặc định KHÔNG sửa.** Lỗi chạy thật → gửi ảnh/log + báo user + hỏi hướng xử lý (fix hay xoá hay bỏ qua) → CHỈ làm sau khi user quyết. Không "sửa nhanh cho chạy tiếp".

## 7. ATX-primary là chuẩn đọc UI toàn farm (16/08)

- **`capture_ui_xml` (automation_core.ui, atx-agent port 7912) là PRIMARY** đọc UI trên máy yếu — shell `uiautomator dump`/`dumpsys window` chỉ là fallback (xem skill `atx-agent-primary-ui-xml`).
- **`dumpsys window mCurrentFocus` KHÔNG đáng tin để quyết "kẹt splash"**: TikTok giữ splash activity window trong khi feed đã render → `get_focused_activity` phải ATX-primary (đọc package từ XML) rồi mới dumpsys. Luôn đối chiếu screencap thật trước khi kết luận màn hình.
- **Popup TikTok phân loại:** cấp quyền/add số điện thoại → dismiss ở automation-core (`tiktok_popup.py`, `tiktok/benign_popup.py`); CTA mua hàng ("Mua ngay") → pass ở repo consumer (`feed_swipe_smoke.py` shop_cta_close). Tên `gemphonefarm_blind_popup` là tên cũ — để im.
- **Tap nút popup chính xác:** screencap có thể scale khác màn thật (720×1280 vs 1080×1920) → tọa độ vision scale SAI. Dùng `capture_ui_xml` (ATX) parse `bounds` node theo text → tap trung tâm bounds (verified 16/08 popup contacts máy 6). Chi tiết: `tiktok-feed-session` references/2026-08-16-swipe-recovery-3session.md.
- **Popup contacts permission text đa dạng:** text thật "Để kết nối với những người bạn biết trên TikTok, hãy cho phép truy cập vào danh bạ..." KHÔNG chứa marker cũ `"cho phép tiktok truy cập vào danh bạ"` (thiếu "tiktok") → core rule miss. Marker linh hoạt: `("cho phép truy cập vào danh bạ", "kết nối với những người bạn biết")`.

## 8. CẤU TRÚC FOLDER TikN.xlsx (16/08 — agent lú 2 lần, user phạt "mày bị lú quá")

> "Folder video chính là tương đương folder videotiktok nuoi acc. Còn video gốc = video goc trong folder"

- **`Folder Video` (cột) = folder OUTPUT** — nằm trong `D:\TIKTOK-videonuoinick` (kết quả render).
- **`video gốc` (cột) = folder NGUỒN** — nằm trong `D:\video goc` (video download để render + tạo avatar).
- **Mỗi Tik (Tik1/Tik2/Tik3) có DẢI output RIÊNG trong TV** — số folder có thể TRÙNG giữa các Tik (vd Tik3 máy 1-20 → Folder Video 3..155 nhìn giống Tik1/Tik2). ĐÓ KHÔNG PHẢI CONFLICT, không đè dữ liệu — mỗi Tik là dải riêng. Luôn đọc cặp (Folder Video ↔ video gốc) từ chính workbook, KHÔNG suy luận từ số.
- Tik3 máy N: Folder Video = 8N−5, video gốc = 160+N.
- `D:\video goc` folder ≥305 có thể KHÔNG có video (chỉ avatar.jpg) — đó là folder OUTPUT Tik3; video thật của chúng nằm trong TV.
- Hashtag/Keyword của TikN phải lấy từ nguồn (sheet "Hashtag theo Folder" theo folder nguồn), KHÔNG bê từ Tik khác — đã verify Tik3 80/80 khớp nguồn.
- Đã commit vào PROJECT_RULES.md (Tiktok-video) `72cc9a7` + memory.

## 9. Pipeline render Tik3/TikN (16/08 — `scripts/tik3_multi_batch.py`)

- **Lệnh chuẩn:** `python -m tik3_multi_batch --workbook <TikN.xlsx> --start-output <folder đầu> --start-source <nguồn đầu> --count <N> --min-videos 45 --parallel 1 --allow-existing-output --resume-complete --execute` (chạy từ `D:\Taadaa\Tiktok-video` + `PYTHONPATH=scripts`).
- **`--min-videos`:** folder nguồn phải ≥45 video mới render (folder đã chuẩn bị từ khâu tải → không cần bận tâm).
- **`--resume-complete`:** folder output đã đủ 45 mp4 → chỉ ghi workbook, KHÔNG render lại.
- **`--allow-existing-output`:** folder có mp4 dang dở (<45) → batch_render tự SKIP video đã có, chỉ render phần thiếu. **Bắt buộc dùng khi folder còn file** — không dùng thì script chặn ("Output folder da co N mp4, khong ghi de").
- **`--parallel 1`:** user yêu cầu render chạy worker 1 thôi.
- **Báo cáo:** user yêu cầu "xong 10 folder thì báo 1 lần" — chạy `--count 10` mỗi lần, xong batch mới báo, không spam giữa chừng.
- Script cần cột `sttvideo` nhưng Tik3.xlsx có `Folder Video` → đã thêm fallback trong `find_headers` (nếu thiếu sttvideo thì dùng folder video).
- `source_map_workbook` KHÔNG dùng được cho Tik3 (map theo output−1 nhưng dải folder không liên tục do +8/máy) — cứ để script tự tăng source từ `--start-source`.
- Render copy avatar từ video goc → output ("COPY avatar: avatar.jpg"). Tạo avatar mới ở video goc TRƯỚC render để output tự nhận avatar mới; avatar output đã render thì tạo lại bằng `avatar-tv-fallback` (gọi make_representative_avatar trực tiếp trên TV folder).

**Download video gốc — THỨ TỰ CHỐT 16/08 (user đảo quyết định giữa session):** discovery song song tải BỊ user chặn — "V cứ discovery trc tải sau t sợ discovery nhanh quá bị chặn k". Thứ tự bắt buộc: **discovery xong (đủ 480 sources, ~80 niche) → mới chạy download**. Cơ chế tăng dần "làm tới đâu down tới đó" VẪN hợp lệ khi user xác nhận lại muốn chạy sớm (không mặc định tự chạy song song): `source_pool_builder.py --auto-discover --resume-discovery` ghi checkpoint `<rt>/sources.partial.json` SAU MỖI NICHE (đã đủ 80 niche sau ~10/80). Extract `sources` list → `sources.json` → chạy `download_by_niche.py --start-folder <folder thiếu đầu> --total-folders 480 --sources sources.json --state-db state.db`; `state.db` nhớ folder đã xử lý → chạy lại khi discovery bổ sung sẽ tự skip. Giai đoạn đầu download im lặng (tải whisper model/probe source, có thể 3-5 phút không output) — kiểm tra process + whisper_models/ thay vì kill vội.

**Download chi tiết (16/08 — đã verify chạy thật):**
- **`--min-videos 45` là chuẩn user** (đã giảm từ 50; docs/download-manager.md còn ghi ">=50" là CŨ — đừng theo). Script default 42. User: "folder nguồn đã đủ video từ khâu tải nên cứ render/không cần bận tâm min".
- **Dependencies bắt buộc trong venv:** `ddgs` (autodiscover TikTok/IG), `faster-whisper` (audio gate tiếng Việt — model "small" tự tải lần đầu ~460MB vào `<rt>/whisper_models/`), `instaloader` (IG followers). Thiếu → cài: `pip install -U ddgs faster-whisper instaloader`.
- **YouTube 403 rải rác (HTTP Error 403: Forbidden) = bot-check theo IP**, không phải lỗi code — folder chỉ đạt ~41/50 video → INSUFFICIENT_POOL. yt-dlp retry sau có thể qua (transient).
- **PITFALL state.db giữ platform cũ (16/08):** folder fail `INSUFFICIENT_POOL` để lại row trong state.db với `platform=instagram` (hoặc platform cũ). Sửa `sources.json` (bỏ IG) rồi chạy lại mà chỉ reset `status='pending'` → script dòng `platform = folder_row["platform"] if ... in PLATFORMS` dùng LẠI platform cũ → fail y hệt. Reset SẠCH: `UPDATE folders SET status='pending', platform='pending', source_channel=NULL, video_count=0 WHERE folder_num=<N>`.
- **Dẹp nguồn theo quyết định user:** IG bị 403 (Instagram chặn API, không phải lỗi yt-dlp — bản 2026.07.04 là mới nhất) → lọc `platform != 'instagram'` khỏi sources; kênh nhà nước (vd @vtv24) → user yêu cầu bỏ, lọc theo URL.
- **Cookies browser:** Chrome/Edge KHÔNG đọc được (Chromium App-Bound/DPAPI — yt-dlp issue #7271). Firefox đọc được nhưng cần profile có log-in YouTube (default-release này không có youtube cookies → vô dụng).
- **yt-dlp 2026.07.04 = bản mới nhất (PyPI + official); TikTok extractor bị "marked as broken":** `tiktok.com/search?q=` → `Unsupported URL`, `tiktok.com/tag/` → `No working app info` — chỉ tải được TikTok channel URL đã biết (3 sources hoạt động). IG 403 cố định là Instagram chặn API (không có bản fix) → user: "k có thì dẹp". YouTube 403 = transient rate-limit, retry sau qua.
- **Auto-discover thiên YouTube nặng:** ddgs tìm YT ra nhiều (120), TikTok/IG ít (3/16) — tỉ lệ 1:40. PLATFORM_TARGET 50:50 nhưng discovery thực tế lệch; user: "K quan trọng miễn đủ nguồn là đc". Nếu dẹp 1 platform phải sửa CẢ `PLATFORMS`/`PLATFORM_TARGET` trong download_by_niche.py (không chỉ sources.json) vì `choose_platform` chọn theo ratio — IG chưa đạt target sẽ bị chọn dù không có source.
- **PLATFORM_TARGET bản CUỐI (16/08 đêm, commit `241424f`):** `PLATFORMS=("youtube",)`, `PLATFORM_TARGET={"youtube": 1.0}` — **TikTok dẹp hẳn khỏi PLATFORMS**. Lý do: kể cả target 0.15, TikTok có ratio 0 (chưa đạt 15%) vẫn được `choose_platform` (chọn theo ratio count/target) lựa cho tới khi đủ chỉ tiêu → mọi folder gán TikTok fail vì chỉ 3-5 TikTok sources (yt-dlp TikTok extractor broken). YouTube 67 kênh qualified = nguồn chạy thật.
- **`--continue-on-insufficient` (flag MỚI, commit `241424f`):** mặc định INSUFFICIENT_POOL → `run_folder` return False → toàn batch `return 2` DỪNG HẲN. Flag này skip folder thiếu nguồn và chạy tiếp folder kế — đúng ý user "kênh nào đủ điều kiện thì down luôn". Bắt buộc thêm vào mọi lệnh download batch dài.
- **Discovery PHẢI chạy `--qualify-videos` (user: "Tưởng discovery nó đã kiểm tra kênh đủ điều kiện r chứ"):** `--auto-discover` thiếu flag này ghi source KHÔNG có `qualified_video_count` (0/176!) → kênh 4-video lọt pool → download fail đủ loại niche. Bước qualify chuẩn: copy `sources.partial.json` → JSONL manifest → `source_pool_builder --source-manifest <jsonl> --qualify-videos --qualification-parallel 4 --min-videos 45 --max-videos 65 --max-candidates-per-source 200 --min-sources-per-platform 0 --output sources.qualified.json`. **`--min-sources-per-platform 0` BẮT BUỘC** (nếu không → exit 2 `INSUFFICIENT_SOURCE_POOL: thieu platform ['instagram']` dù đã dẹp IG). Kết quả 70/70 sources qualified ≥45 video (YT 67 + TT 3) → **download CHỈ nhận `sources.qualified.json`**.
- **`qualify_videos` probe từng video qua YouTube → chậm + rate-limit** ("not available" hàng loạt = chặn tạm, không phải video chết) — chạy nền kiên nhẫn. **Sau khi sửa code phải KILL + restart loop** (process giữ module cũ — patch không có hiệu lực trên process đang chạy).
- **Chạy song song discovery+qualify+download (user quyết định cuối "Sao k làm song song"):** loop scripts `qualify-loop-20260816.py` / `download-loop-20260816.py` tại `D:\CodexRuntime\tiktok-video\` — copy partial → qualify/download → sleep 120s → lặp tới khi discovery xong; state.db skip folder đã xử lý nên nhiều vòng an toàn. Không tăng worker (spam IP).
- **INSUFFICIENT_POOL `best_candidates` nhỏ (vd 4) = NGUỒN NICHE CHƯA ĐỦ, không phải bug** — folder 299 (dongluc) fail vì niche chỉ có 1 channel YouTube nhỏ (4 video pass) dù đã sửa hết logic. Chẩn đoán: best_candidates nhỏ + sources_checked thấp → chờ discovery thêm sources rồi chạy lại, đừng sửa script tiếp (vòng lặp vô ích). Folder có nguồn lớn (vd 298/khcc → @vtv24) pass 65/65 cùng lúc đó.
- **CẤM tăng worker download/discovery** — user từ chối 2 lần vì sợ spam IP: "Tăng lên rủi ro spam ip à thế thì thôi" / "Download cũng k đc tăng worker sợ dính spam ip à". Giữ default: discovery `--audience-parallel 4`, download `--parallel 1`, render `--parallel 1`.
- **Thứ tự CHỐT CUỐI (16/08 đêm, user đảo quyết định 3 lần trong session — mệnh đề cuối thắng):** discovery + qualify + download **CHẠY SONG SONG** ("Ủa phải discovery xong ms down à, tưởng làm tới đâu down tới đó" → "Sao k làm song song"). KHÔNG chờ discovery xong. Cơ chế: checkpoint `sources.partial.json` ghi sau mỗi niche → qualify-loop refresh qualified.json → download-loop tải (cả 2 loop ở `D:\CodexRuntime\tiktok-video\`); state.db skip folder đã xử lý. User từng chặn song song vì sợ bị chặn IP, sau đó đổi ý — nếu phân vân, HỎI user, đừng tự chốt.
**Proxy pool DÙNG ĐƯỢC cho download (user đảo 16/08 đêm: "đụ mẹ nuôi tiktok liên quan cặc gì youtube")** — IP mobile farm proxy cho download YouTube KHÔNG đụng farming TikTok. File: `D:\OneDrive\TaadaaData\kibe\PROXYgandienthoai.xlsx` (76 proxy, cột 'proXy'). **PITFALL format:** xlsx ghi `host:port:user:pass` (vd `test.taadaa.click:5101:mobi1:admin@1`) — URL đúng là `http://user:pass@host:port` = `http://mobi1:admin@1@test.taadaa.click:5101`; prefix `http://` thẳng vào raw → "Failed to resolve '1'". `next_proxy()` trong download_by_niche.py đã xử lý format này. **PITFALL test song song:** proxy panel giới hạn kết nối đồng thời — test 8 worker → 407 auth giả (proxy vẫn sống, user chụp dashboard MobiProxy status xanh). Test proxy PHẢI đơn lẻ. **PITFALL video test:** dùng video nước ngoài phổ biến (Rick Astley) → "other"/NA vì IP di động VN bị chặn — test bằng video/channel VN (vd `@vuadaubepvietnam`) mới đại diện.
- **Camoufox cookies = GIẢI PHÁP bot-check YouTube cuối cùng (16/08 đêm, commit `810cf96`, VERIFIED tải thật):** "Sign in to confirm you're not a bot" là chặn theo CLIENT (thiếu fingerprint + không giải JS challenge) — đổi IP/proxy KHÔNG hết. Fix: `pip install camoufox[geoip]` + `python -m camoufox fetch` → mở `https://www.youtube.com` headless (fingerprint thật) → export cookies Netscape → `download_by_niche.py --cookies-file youtube-cookies-netscape.txt` (cookies tươi qua được; video Numb + channel flat OK). **Cookies sống vài giờ** — download bắt đầu fail "Sign in" lại → chạy lại script Camoufox lấy cookies mới. Chi tiết + script: `references/youtube-botcheck-camoufox-cookies.md`.
- **Dead-end đã thử (đừng mất công lại):** deno + `--js-runtimes` + `youtube:jsc=deno` vẫn "n challenge solving failed" (thiếu solver đầy đủ); Chrome/Edge cookies bị App-Bound chặn; Firefox đọc được nhưng profile không có YouTube session; **Camoufox bắt googlevideo URL trực tiếp = dead end** (`sabr.malformed_config` — SABR segment cần Range headers đặc biệt, tải qua requests/ffmpeg fail; module `scripts/browser_download.py` đã viết nhưng đường ăn chắc là cookies→yt-dlp).
- **`target_counts` trong `source_pool_builder.py` cứng 50/25/25 — phải sửa cùng lúc dẹp platform (commit `3f2ad84`):** nếu không, discovery dừng khi YT đạt target 120 dù cần 480. Sửa → `{"tiktok":0,"instagram":0,"youtube":total}` + `--min-sources-per-platform 0`. Kết quả: 514 sources (454 YT).
- **`youtube_profile` regex handle Unicode (commit `241424f`):** `@[A-Za-z0-9._-]+` fail với handle tiếng Việt có dấu (`@KhámPháBếpViệt` → None → manifest dòng 1 "source phai la URL profile/channel public"). Sửa thành `@[\w.-]+`.
- **PITFALL patch fuzzy làm lệch indent file dài** (download_by_niche.py/source_pool_builder.py trúng nhiều lần 16/08): khi block >20 dòng thay bằng python script sửa theo index dòng thay vì patch fuzzy — verify `py_compile` sau mỗi lần.

**Báo cáo batch dài (16/08 preference):** "gặp lỗi thì báo còn k cứ silent đi" — chạy nền im lặng, CHỈ nhắn khi lỗi thật / cần user / milestone được yêu cầu (vd "xong 10 folder báo 1 lần"). Dùng `notify_on_complete` cho mọi batch dài, không poll progress spam giữa chừng.

## 10. Rule avatar folder (16/08 — user: "đưa rule này lên ưu tiên cao nhất")

1. **Người** (face detect Haar) → 2. **Động vật** (YOLO theo niche animal: yeuthucung/xemeo/chocanh/thucung) → 3. **Frame sáng** crop 512×512. **Avatar kênh thật KHÔNG dùng nữa** (bỏ khỏi bước 1 trong `make_avatar_for_folder`; commit `662ff58`).
- `_make_avatar.py` dùng `subject_type="auto"` + `subject_model=yolov8n.pt` (commit `0b2fc7d`) — auto cho phép người → động vật → fallback.
- **CẤM đụng avatar đã tạo** — user: "những cái đã sửa r thì đừng đụng tới nữa" (chỉ áp rule mới cho folder CHƯA tạo).
- `D:\video goc` folder ≥298 thường KHÔNG có video (chỉ avatar.jpg cũ) → tạo avatar bằng TV-fallback scripts (`avatar-tv-fallback-20260816.py` gọi make_representative_avatar lên TV folder).

## 11. User yêu cầu "áp rule mọi session mọi repo" — chèn 3 tầng (2026-08-17)

Khi user nói "làm sao bất kỳ session nào bất kỳ repo nào từ h phải nhận đúng rule/skill t yêu cầu" (sau khi phạt nhiều lần vì agent không tuân thủ STOP GATE), KHÔNG chỉ patch skill — phải chèn 3 tầng:

1. **Cấp repo (bắt buộc, mạnh nhất)**: chèn block rule (STOP GATE) vào **AGENTS.md + PROJECT_RULES.md của MỌI farm repo** (10 repo: Tiktok_Reg, Hotmail, Tiktok-video, tiktok-log-in, tiktok-follow, tiktok-add-bao-mat-f2a, tiktok-luot nuoi acc, gan-proxy, register gmail, automation-core). AGENTS.md được Hermes/Codex/Claude đọc ở cwd → mọi session mở trong repo đều nhận rule, KHÔNG phụ thuộc skill library. Dùng skill `rule-file-append` (EOL-preserving + baseline + backup + verify). Chèn SAU heading đầu, giữ EOL từng file.
2. **Cấp skill**: chèn STOP GATE vào skill liên quan + skill all-repo (`taadaa-farm-ops-rules`) — agent load skill đúng là có rule.
3. **Cấp memory**: dòng STOP GATE rút gọn trong memory → nhét thẳng vào context mỗi lượt.
4. **CẦN THÊM "BẮT BUỘC LOAD SKILL" vào AGENTS.md** (đã làm 17/08): khối `## 🧑💻 BẮT BUỘC LOAD SKILL` liệt kê skill repo nào phải load trước khi làm việc — đảm bảo session không chỉ có rule mà còn biết phải nạp skill chứa selector/flow/canary.
5. **Commit + push từng repo** (user duyệt "commit đi"): commit message tiếng Việt, push mọi repo có upstream; repo non-fast-forward (`tiktok-luot nuoi acc`) → stash WIP workstream khác + rebase + resolve conflict + pop stash (xem `git-worktree-merge-reconciliation` §30).
6. **Inject-verify**: mở session Hermes mới trong repo (`hermes chat -q "STOP GATE điều 5,6 nói gì?"`) — agent trả lời đúng block = rule đã vào system prompt. (Lưu ý: session mới có thể quét toàn `/d/Taadaa` chậm — prompt phải bảo đọc AGENTS.md ở cwd.)

## 12. Cấu trúc thư mục gốc D:\Taadaa & Cơ chế đồng bộ đa máy (Kibe ↔ Admin qua OneDrive Junction)

Thư mục gốc `D:\Taadaa` là thư mục cha chứa toàn bộ hạ tầng farm Taadaa:
- **Các repo con:** `automation-core`, `Hotmail`, `register gmail`, `Tiktok_Reg`, `tiktok-add-bao-mat-f2a`, `tiktok-follow`, `tiktok-log-in`, `tiktok-luot nuoi acc`, `Tiktok-video`, `add mail khoi phuc`, `open claw`, `site ban hang clone`, `AI-Tools`, `Hermes`, `gan-proxy`.
- **Hạ tầng dùng chung:**
  - `machine-config/`: chứa `kibe.yaml` (dải 1–80) và `admin.yaml` (dải 200–999).
  - `python-envs/automation/`: venv Python dùng chung cho mọi repo consumer.
  - `runtime/<host>/`: chứa runtime state, lock mutex, screenshots lỗi (tuyệt đối không để trong repo Git).
  - `tools/`: các script điều phối chung (`taadaa_host.py`).
  - `BACKUP_ALL/`: nơi gom các file rác, file tạm, worktrees cũ (giữ root `D:\Taadaa` sạch sẽ).

**Cơ chế đồng bộ Realtime máy Kibe ↔ Admin (`D:\OneDrive\Taadaa_Sync_Shared`):**
1. Trên máy Kibe: `D:\OneDrive\Taadaa_Sync_Shared` dùng Windows Directory Junction (`mklink /J`) trỏ thẳng vào `D:\Taadaa\machine-config` và `D:\Taadaa\tools` + chứa các file rules gốc (`AGENTS.md`, `HANDOFF.md`, `HERMES_SUBAGENT_RULES.md`).
2. Trên máy Admin (chỉ cần chạy 1 lần):
   - Mở OneDrive: `D:\OneDrive\Taadaa_Sync_Shared\link_shared_to_admin.bat` → tự động tạo Junction Link 2 chiều vào `D:\Taadaa` của Admin và set `TAADAA_HOST_CONFIG="D:\Taadaa\machine-config\admin.yaml"`.
   - Chạy `clone_all_repos.bat` → tự động clone 15 repo với đúng branch chuẩn về `D:\Taadaa`.
3. Bất kỳ thay đổi nào về rule, config, tool trên Kibe sẽ được OneDrive sync tức thì sang Admin. Code repo cập nhật độc lập qua `git pull`.
- Chi tiết hướng dẫn & script bootstrap: `references/multi-host-onedrive-junction-sync.md`.

## Pitfalls

- OTP dùng chung = KHÔNG BAO GIỜ song song login/add-mail; cảnh báo này nằm cả trong skill `hotmail-outlook-automation`.
- `read_otp_mail.py` đọc mã MỚI NHẤT trong mailbox — mã cũ của máy trước chưa dùng sẽ làm sai máy sau.
- IMAP hotmail basic auth đã chết (Microsoft tắt) — OTP recovery chỉ đọc được từ Gmail recovery mailbox qua app password.
