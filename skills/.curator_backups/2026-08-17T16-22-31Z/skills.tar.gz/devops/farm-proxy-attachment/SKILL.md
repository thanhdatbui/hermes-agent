---
name: farm-proxy-attachment
description: Verify or configure per-device proxy attachment for the Taadaa Android phone farm via the ViChanger app and the gan-proxy repo. Use when the user asks whether the farm proxy setup is correct/safe/legit ("gắn proxy ổn không", "vichanger fake không", "proxy qua app hay adb"), or when a task touches D:\Taadaa\gan-proxy, vi_changer_runner.py, gan_proxy_fleet.py, or the per-device proxy mapping.
---

# Farm proxy attachment (Taadaa phone farm)

## 🛑 STOP GATE (bắt buộc — chi tiết: skill taadaa-farm-ops-rules)
Máy live + script chạy/lỗi → KHÔNG tự sửa code, KHÔNG tự chạy lại, KHÔNG tự probe/tay khi chưa được user yêu cầu.
Lỗi → screencap → gửi ẢNH THẬT (MEDIA:<path> dòng riêng, KHÔNG bọc markdown, KHÔNG gửi đường dẫn text) → DỪng chờ user hướng dẫn.
User hướng dẫn bước nào → encode bước đó vào script + test → mới chạy lại. Nghi ngờ → HỎI.

## When to use
- User asks if the farm's proxy is correct/safe/legit, or "app X fake không".
- Task touches proxy attachment / the gan-proxy repo / ViChanger / per-device proxy mapping.

## Locating the repo (PITFALL — learned the hard way)
- Canonical proxy repo is **`D:\Taadaa\gan-proxy`** (NOT under `tiktok-video`, NOT under CodexRuntime except throwaway recovery worktrees like `D:\CodexRuntime\gan-proxy-*`).
- **If the user names the repo ("trong repo gan proxy"), GO THERE DIRECTLY.** Do NOT broad-search `D:\` and `C:\` — it times out and wastes turns.
- Taadaa repo roots live under `D:\Taadaa\<repo>` (gan-proxy, automation-core, machine-config). CodexRuntime holds clones/worktrees.
- **search_files tool mis-maps `D:\` paths on this host** (converts to `/d/...` and throws IO error). Use terminal `find` / `grep -rli --include=...` for D:\ repos instead.

## How attachment works (`scripts/vi_changer_runner.py::set_proxy`)
Two paths, selected by colon count of the proxy value:
- **Authenticated proxy** (`user:pass@host:port`, ≥2 colons) → launches `vn.vichanger.app` (ViChanger) and broadcasts `vn.vichanger.app.START_VPN` (extra `proxy`) to receiver `.AdbCaller`. ViChanger opens a real **VpnService tunnel** capturing ALL device traffic. Verified by `tun0` UP + `NetworkAgentInfo [VPN] CONNECTED/CONNECTED`. **Reliable — TikTok cannot bypass it.** This is the "via app" answer to the FB-post question.
- **Plain `host:port`** (exactly 1 colon) → falls back to `adb shell settings put global http_proxy <proxy>` (read back to verify). This is the "adb command" method — **TikTok can bypass system http_proxy and connect directly**, so treat it as effectively NO proxy for the farm.
- Fleet classification (`gan_proxy_fleet.py`): `proxy.count(":") >= 3` → `authenticated_http`; mapping source `D:\OneDrive\codex_gmail_debug\PROXYgandienthoai.xlsx` (rows need machine + serial + proxy all populated). **Never print proxy values** (credential rule).

## Is the app fake? (verification, not trust)
ViChanger is functionally REAL, not a placebo:
- CHANGELOG recovered the protocol from the installed app; task note shows `tun0` UP + VPN CONNECTED + `GET_IP` returns the new IP after `set`.
- It is a niche/modified app: its UI requests **LSPosed (root) + API key**, but the runner deliberately avoids that path and uses the broadcast API, so it works without the API key.
- Trust caveat: a VPN app sees ALL traffic and wants root — only safe if it's the official GemPhoneFarm-bundled APK. Code alone cannot prove it's not malicious.
- Prove it actually changes IP:
  1. `python scripts/vi_changer_runner.py probe` before and after `set` → `GET_IP` must change to the proxy IP.
  2. On a live device (read-only): `adb shell dumpsys package vn.vichanger.app` → `installerPackageName` = `com.android.vending` = Play Store; `null`/other = sideloaded.

## Commands
- `python scripts/vi_changer_runner.py probe` (machine 1 only; serial guarded by DEFAULT_SERIAL).
- `python scripts/gan_proxy_fleet.py plan` (read-only plan of mapped machines).
- `python scripts/gan_proxy_fleet.py run --machines 1 13 --workers 2` (canary run).
- Pass proxy via `GAN_PROXY_VALUE` env var — never on the command line / shell history.

## Pitfalls
- Plain `host:port` proxy = bypassable by TikTok. Ensure the Excel mapping uses the authenticated form.
- search_files fails on `D:\` → use terminal find/grep.
- Don't broad-search the filesystem when the user already named the repo.

## VPN gate and host-aware mapping (17/08/2026 — user rule "k bật vpn thì k đc chạy")

**Bug class that must never regress:** `vpn_preflight.DEFAULT_PROXY_MAPPING` in COMSUMER repos
hardcoded the kibe workbook (`D:\OneDrive\TaadaaData\kibe\PROXYgandienthoai.xlsx`). On the admin
host (máy 200+, `TAADAA_HOST_CONFIG=admin.yaml`, workbook_root trống), `serial_is_mapped_in_workbook`
read the KIBE mapping → admin serials not found → `required=False` → VPN check skipped → **máy admin
không VPN vẫn chạy** (user caught it live on the 06:00 shift: "nhiều máy chưa có vpn vẫn chạy").

**Fix (canonical, all-repo):** mapping MUST resolve per host, never fall back to another host:
- `automation_core 0.4.46` adds `resolve_proxy_mapping_path()` — reads `TAADAA_HOST_CONFIG`
  workbook_root; for kibe → `kibe/PROXYgandienthoai.xlsx`; for admin (no file) → **raise**
  fail-closed (no kibe fallback, no silent exempt).
- Patched in EVERY consumer that hardcodes the mapping path: `tiktok-luot nuoi acc/vpn_preflight.py`,
  `tiktok-log-in` (cli.py + account_reconcile.py), `tiktok-add-bao-mat-f2a`, `add mail khoi phuc`,
  `register gmail` (gmail_reg_v10.py + guarded_device_reboot.py), `Hotmail/hotmail_login.py`,
  `gan-proxy/gan_proxy_fleet.py`, worktree `tiktok-log-in-recovery-adapter-p2-wt`.
  Verify with: `grep -rln "PROXYgandienthoai" --include=*.py D:/Taadaa/ | grep -viE "venv|site-packages|\.git|tests"` → must be EMPTY for runtime code.
- Non-git repos (register gmail, Hotmail, gan-proxy) patched in place (no commit possible).

**Recovery ladder (core `recover_missing_android_vpn`, wired in `vpn_preflight.require_vichanger_connected`):**
VPN fail on a MAPPED machine → (1) GanProxy reassign (`proxy_pending` + wait `wait_for_proxy_ready`
with live verifier) → (2) soft-reboot 1× (`soft_reboot_and_wait`: reboot → unlock → wait proxy/VPN)
→ (3) still fail → `MissingVpnRecoveryError` FINAL_BLOCKED (never runs VPN-less). Consumer BEFORE
the fix just returned `blocked-vichanger-vpn` immediately (no recovery attempt). Bounded reboot
"1-2 lần tránh loop lỗi do gan proxy" is the user's framing — do NOT loop reboot beyond the
core ladder.

## References
- `references/vi-changer-mechanism.md` — code-level dump: file:line citations for the two paths, verification, and the LSPosed/API-key side path.
