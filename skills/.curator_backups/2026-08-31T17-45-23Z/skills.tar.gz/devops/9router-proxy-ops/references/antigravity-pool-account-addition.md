# Antigravity pool account addition

Use this when a Google Antigravity account is already authenticated in OmniRoute but a Gemini combo does not yet include it.

## Safe sequence

1. Read the live management state from `/api/providers` and `/api/combos`; identify the exact connection ID by account name and verify `provider=antigravity`, `isActive=true`, and `testStatus=active`.
2. Inspect the existing active Gemini pool targets and connection settings. Treat the live pool as the baseline. Do not copy values from a template if live values have changed.
3. Align only the new connection's pool-relevant settings with that baseline, typically `maxConcurrent` and `rateLimitProtection`. Use the management API's partial update and rate-limit toggle endpoints; never touch OAuth credentials, proxy assignment, or unrelated provider fields.
4. Update the existing combo by preserving its current `strategy`, `config`, and all existing model targets. Append one target using the same upstream model and provider, the new connection ID, and the next pool label (`pool-4`, etc.). Do not create a replacement combo or change the client-facing combo name.
5. Read back provider and combo state. Confirm the new target is present, active, and has the intended settings.
6. Send one fresh, minimal non-cached generation through the combo. Accept the change only if the request returns HTTP 200 with usable completion text and a usage/completion signal.

## Evidence to report

- New connection: sanitized account label, active/test status, `maxConcurrent`, rate-limit protection.
- Combo: name, strategy, preserved runtime config, target count, new pool label, model family.
- Canary: exact live listener, HTTP status, resolved model if exposed, completion text, usage fields.
- Mutations not performed: OAuth reset, account disable/delete, proxy changes, blind restart.

## Pitfalls

- A newly added provider connection can be active yet absent from every combo.
- A 429/quota event on existing targets does not automatically mean a newly added account is in the routing pool.
- `connection-test=200` and visible quota prove connectivity/control-plane health, not generation authorization or combo membership.
- Do not use an ad-hoc `/v1/chat/completions` probe as a substitute for the required management/API path when the task is to modify routing; use it only as the final single canary after readback.
- Do not report success from the write response alone; verify with fresh GETs and one canary.
