# GPMLogin Local API & CDP Automation Pattern

Automating antidetect browser profiles in GPMLogin without `computer_use` (no mouse/keyboard hijacking, runs completely in the background).

## Architecture & Server Port
* GPMLogin runs a local HTTP server at `http://127.0.0.1:9495/api/v1` (no API key required).
* If port `9495` is occupied, it binds to a random port in `8000–10000` and writes the active port to `http.port` inside the app data directory.

## Core Endpoints
1. **Create Profile:** `POST /api/v1/profiles/create`
   * Body: `{"name": "ProfileName", "raw_proxy": "http://user:pass@ip:port", "group_id": "all"}`
   * Returns: `data.id` (Profile UUID). Fingerprint parameters (Canvas, WebGL, Audio, UA) are auto-randomized by GPM.
2. **Start Profile (Launch Browser):** `GET /api/v1/profiles/start/{id}`
   * Query params (optional): `skip_proxy_check=true`, `remote_debugging_port=<port>`, `window_size="800,600"`
   * Returns:
     * `data.remote_debugging_port`
     * `data.websocket_debugging_url` (e.g. `ws://127.0.0.1:40444/devtools/browser/...`)
3. **Stop Profile (Close Browser):** `GET /api/v1/profiles/stop/{id}`
   * Closes the profile's browser and persists session/cookies to disk.
4. **List Profiles:** `GET /api/v1/profiles?page=1&page_size=30`
5. **Get Profile Detail:** `GET /api/v1/profiles/{id}`

## Automation Flow (Python + Playwright via CDP)

```python
import requests
import time
from playwright.sync_api import sync_playwright

GPM_API_BASE = "http://127.0.0.1:9495/api/v1"

def create_gpm_profile(name: str, proxy: str = "") -> str:
    payload = {"name": name, "raw_proxy": proxy}
    res = requests.post(f"{GPM_API_BASE}/profiles/create", json=payload).json()
    if not res.get("success"):
        raise RuntimeError(f"Failed to create profile: {res.get('message')}")
    return res["data"]["id"]

def start_gpm_profile(profile_id: str) -> str:
    res = requests.get(f"{GPM_API_BASE}/profiles/start/{profile_id}").json()
    if not res.get("success"):
        raise RuntimeError(f"Failed to start profile: {res.get('message')}")
    return res["data"]["websocket_debugging_url"]

def stop_gpm_profile(profile_id: str):
    requests.get(f"{GPM_API_BASE}/profiles/stop/{profile_id}")

def drive_profile_cdp(ws_url: str, task_fn):
    with sync_playwright() as p:
        browser = p.chromium.connect_over_cdp(ws_url)
        context = browser.contexts[0]
        page = context.pages[0] if context.pages else context.new_page()
        task_fn(page)
        browser.close()
```

## Antigravity / Google Login Operational Rules
* **No `computer_use` Needed:** Use Playwright/Puppeteer over CDP directly to interact with DOM selectors (`input[type="email"]`, `#identifierNext`, `input[type="password"]`, `#passwordNext`).
* **Proxy Allocation:** Maximum 5 accounts per static residential/datacenter proxy IP.
* **Timing & Rate Limits:** Add 5–15s delay between account logins/auth calls to avoid triggering Google OAuth rate limits.
* **Checkpoint Handling:** Detect `VALIDATION_REQUIRED` / Recovery Email prompts during sign-in; log failing profiles separately to avoid halting the batch run.
