---

name: farm-proxy-attachment

description: Verify or configure per-device proxy attachment for the Taadaa Android phone farm via the ViChanger app and the gan-proxy repo. Use when the user asks whether the farm proxy setup is correct/safe/legit ("gắn proxy ổn không", "vichanger fake không", "proxy qua app hay adb"), or when a task touches D:\Taadaa\gan-proxy, vi_changer_runner.py, gan_proxy_fleet.py, or the per-device proxy mapping.

---



# Farm proxy attachment (Taadaa phone farm)


## 🛑 STOP GATE (bắt buộc — chi tiết: skill taadaa-farm-ops-rules)
Máy live + script chạy/lỗi → KHÔNG tự sửa code, KHÔNG tự chạy lại, KHÔNG tự probe/tay khi chưa được user yêu cầu.
Lỗi → screencap → gửi ẢNH THẬT (MEDIA:<path> dòng riêng, KHÔNG bọc markdown, KHÔNG gửi đường dẫn text) → DỪng chờ user hướng dẫn.
User hướng dẫn bước nào → encode bước đó vào script + test → mới chạy lại. Nghi ngờ → HỎI.

## When to use

- User asks if the farm's proxy is correct/safe/legit, or "app X fake không".

- Task touches proxy attachment / the gan-proxy repo / ViChanger / per-device proxy mapping.



## Locating the repo (PITFALL — learned the hard way)

- Canonical proxy repo is **`D:\Taadaa\gan-proxy`** (NOT under `tiktok-video`, NOT under CodexRuntime except throwaway recovery worktrees like `D:\CodexRuntime\gan-proxy-*`).

- **If the user names the repo ("trong repo gan proxy"), GO THERE DIRECTLY.** Do NOT broad-search `D:\` and `C:\` — it times out and wastes turns.

- Taadaa repo roots live under `D:\Taadaa\<repo>` (gan-proxy, automation-core, machine-config). CodexRuntime holds clones/worktrees.

- **search_files tool mis-maps `D:\` paths on this host** (converts to `/d/...` and throws IO error). Use terminal `find` / `grep -rli --include=...` for D:\ repos instead.



## Terminology gate: ISP multi-session vs upstream proxy

When the user says **"bắt gói đa phiên"** in the Vietnamese ISP/farm context, do not assume it means a pool of authenticated upstream proxies. It commonly means one ISP line provisioned with multiple PPPoE sessions/public IPv4 addresses (for example, 12, 30, or 32 sessions/IPs). The router terminates the sessions and policy-routes fixed device groups to fixed sessions. This is an ISP multi-session design, not proxy generation.

Before evaluating it, confirm the ISP actually provides independent public IPv4 addresses per session; do not infer this from the package name alone. Also separate:

- **Public-IP capacity:** `N` sessions/IPs can serve approximately `floor(N / phones_per_IP)` phone groups.
- **Bandwidth capacity:** all sessions on one physical line still share the line's total bandwidth; multi-session does not multiply a 1 Gbps line into N Gbps.
- **Identity stability:** keep device-to-session mapping sticky; if a session dies, fail closed for that group rather than silently moving it to another IP.

For the user's farm planning convention, use **2 phones per public IP** unless they specify otherwise. Thus 160 phones require about 80 public IPv4 sessions. Examples: 30 + 32 sessions = 62 IPs (124 phones at 2/IP); 30 + 32 + 32 = 94 IPs (capacity for 188 phones). Do not recalculate using 1 phone/IP or assume one IP per account when the user says each phone runs multiple accounts.

If the user asks whether ISP multi-session is "a proxy", answer precisely: it provides multiple routable public egress IPs through the ISP/router, but it is not the same as an authenticated proxy service or per-device VPN tunnel. Verify the routing and public IP from the actual device/egress before calling it ready.

## How attachment works (`scripts/vi_changer_runner.py::set_proxy`)

Two paths, selected by colon count of the proxy value:

- **Authenticated proxy** (`user:pass@host:port`, ≥2 colons) → launches `vn.vichanger.app` (ViChanger) and broadcasts `vn.vichanger.app.START_VPN` (extra `proxy`) to receiver `.AdbCaller`. ViChanger opens a real **VpnService tunnel** capturing ALL device traffic. Verified by `tun0` UP + `NetworkAgentInfo [VPN] CONNECTED/CONNECTED`. **Reliable — TikTok cannot bypass it.** This is the "via app" answer to the FB-post question.

- **Plain `host:port`** (exactly 1 colon) → falls back to `adb shell settings put global http_proxy <proxy>` (read back to verify). This is the "adb command" method — **TikTok can bypass system http_proxy and connect directly**, so treat it as effectively NO proxy for the farm.

- Fleet classification (`gan_proxy_fleet.py`): `proxy.count(":") >= 3` → `authenticated_http`; mapping source `D:\OneDrive\TaadaaData\kibe\PROXYgandienthoai.xlsx` (rows need machine + serial + proxy all populated). **Never print proxy values** (credential rule).



## Is the app fake? (verification, not trust)

ViChanger is functionally REAL, not a placebo:

- CHANGELOG recovered the protocol from the installed app; task note shows `tun0` UP + VPN CONNECTED + `GET_IP` returns the new IP after `set`.

- It is a niche/modified app: its UI requests **LSPosed (root) + API key**, but the runner deliberately avoids that path and uses the broadcast API, so it works without the API key.

- Trust caveat: a VPN app sees ALL traffic and wants root — only safe if it's the official GemPhoneFarm-bundled APK. Code alone cannot prove it's not malicious.

- Prove it actually changes IP:

  1. `python scripts/vi_changer_runner.py probe` before and after `set` → `GET_IP` must change to the proxy IP.

  2. On a live device (read-only): `adb shell dumpsys package vn.vichanger.app` → `installerPackageName` = `com.android.vending` = Play Store; `null`/other = sideloaded.



## Commands

- `python scripts/vi_changer_runner.py probe` (machine 1 only; serial guarded by DEFAULT_SERIAL).

- `python scripts/gan_proxy_fleet.py plan` (read-only plan of mapped machines).

- `python scripts/gan_proxy_fleet.py run --machines 1 13 --workers 2` (canary run).

- Pass proxy via `GAN_PROXY_VALUE` env var — never on the command line / shell history.



## Pitfalls

- Plain `host:port` proxy = bypassable by TikTok. Ensure the Excel mapping uses the authenticated form.

- search_files fails on `D:\` → use terminal find/grep.

- Don't broad-search the filesystem when the user already named the repo.



## VPN gate and host-aware mapping (17/08/2026 — user rule "k bật vpn thì k đc chạy")



**Bug class that must never regress:** `vpn_preflight.DEFAULT_PROXY_MAPPING` in COMSUMER repos

hardcoded the kibe workbook (`D:\OneDrive\TaadaaData\kibe\PROXYgandienthoai.xlsx`). On the admin

host (máy 200+, `TAADAA_HOST_CONFIG=admin.yaml`, workbook_root trống), `serial_is_mapped_in_workbook`

read the KIBE mapping → admin serials not found → `required=False` → VPN check skipped → **máy admin

không VPN vẫn chạy** (user caught it live on the 06:00 shift: "nhiều máy chưa có vpn vẫn chạy").



**Fix (canonical, all-repo):** mapping MUST resolve per host, never fall back to another host:

- `automation_core 0.4.46` adds `resolve_proxy_mapping_path()` — reads `TAADAA_HOST_CONFIG`

  workbook_root; for kibe → `kibe/PROXYgandienthoai.xlsx`; for admin (no file) → **raise**

  fail-closed (no kibe fallback, no silent exempt).

- Patched in EVERY consumer that hardcodes the mapping path: `tiktok-luot nuoi acc/vpn_preflight.py`,

  `tiktok-log-in` (cli.py + account_reconcile.py), `tiktok-add-bao-mat-f2a`, `add mail khoi phuc`,

  `register gmail` (gmail_reg_v10.py + guarded_device_reboot.py), `Hotmail/hotmail_login.py`,

  `gan-proxy/gan_proxy_fleet.py`, worktree `tiktok-log-in-recovery-adapter-p2-wt`.

  Verify with: `grep -rln "PROXYgandienthoai" --include=*.py D:/Taadaa/ | grep -viE "venv|site-packages|\.git|tests"` → must be EMPTY for runtime code.

- Non-git repos (register gmail, Hotmail, gan-proxy) patched in place (no commit possible).



**Live IP Verification (20/08/2026 — commit `c5036cb` in `automation-core`):**
- Chỉ kiểm tra `tun0 UP` và `dumpsys connectivity` là KHÔNG ĐỦ vì khi upstream proxy chết, `tun0` ở local vẫn `UP`, TikTok tự động fallback ra Direct Wi-Fi IP gây lộ footprint toàn farm.
- `check_android_vpn` và `require_android_vpn` bổ sung `verify_live_ip=True`: bắt buộc gửi broadcast `vn.vichanger.app.GET_IP` tới `vn.vichanger.app/.AdbCaller`.
- Điều kiện PASS: `result=200` và `data="<IP>"` hợp lệ; nếu `result=0` (proxy chết) $\rightarrow$ BLOCK ngay lập tức (fail-closed), tuyệt đối không cho mở TikTok.
- **Phân biệt `result=0` vs `broadcast exception: adb command timed out`**:
  - `result=0`: Upstream proxy sập / chết port / xác thực lỗi $\rightarrow$ kiểm tra port proxy ngoài bằng `curl -I -m 10 http://host:port` (phải trả 407/200, không timeout).
  - `broadcast exception: adb command timed out`: ADB hoặc tiến trình `vn.vichanger.app` trên máy bị nghẽn tạm thời dẫn đến quá thời gian chờ lệnh broadcast. `tun0` và kết nối VPN vẫn đang giữ; kiểm tra lại bằng lệnh broadcast thủ công `am broadcast -a vn.vichanger.app.GET_IP -n vn.vichanger.app/.AdbCaller` nếu trả `result=200` thì VPN và proxy vẫn bình thường.
- **TUYỆT ĐỐI KHÔNG BỎ GATE NÀY:** Khi user hỏi *"có nên bỏ kiểm tra trên máy / chỉ check bên ngoài"* khi thấy nhiều máy báo `MissingVpnRecoveryError`: Phải giải thích rõ việc kiểm tra `GET_IP` trên máy là chốt chặn cuối cùng ngăn Android fallback về direct Wi-Fi. Khi nhiều máy dừng phiên cùng lúc, kiểm tra phân nhóm host mapping (`PROXYgandienthoai.xlsx`) bằng `curl -x` và `am broadcast ... GET_IP` để xác định chính xác cụm proxy nào đang sập (ví dụ: `mirotik1.taadaa.click` hoặc `khoalee.duckdns.org` mất mạng/chết port) thay vì tắt gate bảo vệ.
**Quy trình chẩn đoán khi nhiều máy báo MissingVpnRecoveryError / TimeoutError proxy readiness:**
  1. Đọc mapping `D:\\OneDrive\\TaadaaData\\kibe\\PROXYgandienthoai.xlsx` nhóm theo host (`test.taadaa.click`, `mirotik1.taadaa.click`, `khoalee.duckdns.org`).
  2. Test `curl -x http://user:pass@host:port https://api.ipify.org` bên ngoài để xác định port nào timeout/502.
  3. Bắn broadcast trực tiếp: `adb -s <serial> shell am broadcast -a vn.vichanger.app.GET_IP -n vn.vichanger.app/.AdbCaller`.
  4. Nếu `result=0`: Báo cáo danh sách cổng chết cho user kiểm tra box/sim thay vì sửa code hay bypass gate.

**Cách check proxy đúng cho nhiều máy cùng lúc (học từ 2026-08-23):**
- `tun0 UP` + `ping 8.8.8.8 OK` + thiếu `default route qua tun0` **KHÔNG CÓ NGHĨA là proxy die** — ViChanger không push default route kiểu OpenVPN, routing của nó hoạt động qua VpnService tunnel. Cấm kết luận proxy hỏng dựa trên `ip route` hay `wget/curl` trên shell Android.
- `wget` / `curl` / `python3 urllib` trên shell Android cũng **không lấy được public IP** vì ViChanger intercept traffic ở tầng VpnService của Android apps, không hook command line shell.
- **Cách đúng duy nhất:** broadcast với `-n vn.vichanger.app/.AdbCaller` và đọc `result=200` + `data="<IP>"`:
  ```python
  import subprocess, re
  r = subprocess.run([adb, "-s", serial, "shell", "am", "broadcast",
      "-a", "vn.vichanger.app.GET_IP",
      "-n", "vn.vichanger.app/.AdbCaller"],
      capture_output=True, text=True, timeout=10)
  match = re.search(r'data="([^"]+)"', r.stdout)
  ok = "result=200" in r.stdout and match
  ip = match.group(1) if match else ""
  ```
- `result=0` (không có `.AdbCaller` hoặc broadcast không có `-n`) → không có IP → sai kết quả. Luôn dùng `-n vn.vichanger.app/.AdbCaller`.
- **Phát hiện lộ IP gốc (Direct IP Leak):** Luôn so sánh IP lấy từ ViChanger với Host Public IP (`https://api.ipify.org`). Nếu trùng (ví dụ các port `mirotik1.taadaa.click:1000x` trỏ về router nội bộ không qua 4G/Dcom), máy đang dùng direct IP farm. TikTok có thể cho reg 1 acc nhưng sau đó rate-limit toàn bộ các máy khác cùng IP.
- **Tự động gắn lại proxy qua Watcher sau reboot:** Khi reboot máy, watcher `gan_proxy_fleet.py watch` (chạy ngầm trên PC) sẽ tự động bắt sự kiện thiết bị online và gán lại proxy theo `PROXYgandienthoai.xlsx`.
- **Cảnh báo Serial Drift:** KHÔNG lấy serial từ log cũ hoặc manifest tạm. Luôn tra cứu serial chuẩn từ file `D:\OneDrive\Tiktok\Tik1.xlsx` (hoặc `PROXYgandienthoai.xlsx`), vì một số file tracking/manifest tạm (như `taikhoan_run_safe.xlsx`) có thể bị ghi đè ngày tháng vào cột serial (ví dụ `23/08/2026`). Dùng `Tik1.xlsx` sheet `TaiKhoan` làm single source of truth cho `STT ↔ Serial ADB`.
- **Môi trường Python khi chạy probe/script:** Trên host Windows này, các thư viện `openpyxl`/`requests` nằm trong virtualenv `D:\Taadaa\python-envs\automation\Scripts\python.exe`. Khi gọi bằng subprocess/terminal, cần `env -u PYTHONPATH -u PYTHONHOME` để tránh xung đột binary/C-extension với venv của Hermes CLI.
- **Tiêu chuẩn nhịp độ Reg TikTok an toàn:** Mỗi ngày chỉ reg **tối đa 1 acc / máy / ngày** (trên proxy sạch 4G/Dcom xoay IP). Không dùng IP direct của farm để reg hàng loạt tránh bị TikTok quét dải IP.



**Recovery ladder (core `recover_missing_android_vpn`, wired in `vpn_preflight.require_vichanger_connected`):**

VPN fail on a MAPPED machine → (1) GanProxy reassign (`proxy_pending` + wait `wait_for_proxy_ready` 60s) → (2) **Stage-2 Direct Proxy Reconnect** (đọc mapping `PROXYgandienthoai.xlsx` → gọi `vi_changer_runner.set_proxy` trực tiếp tại chỗ → verify `verify_live_ip=True`) → (3) soft-reboot 1× (`soft_reboot_and_wait`: reboot → unlock → wait proxy/VPN) → (4) still fail → `MissingVpnRecoveryError` FINAL_BLOCKED (never runs VPN-less). Chi tiết: `references/stage2-direct-proxy-reconnect-and-live-ip-20260824.md`. Bounded reboot "1-2 lần tránh loop lỗi do gan proxy" is the user's framing — do NOT loop reboot beyond the core ladder.



## References

- `references/vichanger-lsposed-warning-and-adbcaller-protocol-20260824.md` — Cảnh báo LSPosed/API Key vô hại trên ViChanger, quy trình gán proxy qua AdbCaller và cách verify Live IP.
- `references/mobiproxy-web-ops-and-auth-troubleshooting.md` — MobiProxy Web UI (test.taadaa.click), xử lý lỗi 407 Proxy Authentication Required và quy trình chuẩn hóa `host:port`.
- `references/proxy-upstream-death-and-live-ip-gate-20260820.md` — Lỗ hổng Proxy sập nhưng `tun0 UP` ảo + TikTok fallback Direct IP leak & cơ chế xác thực Live IP (`GET_IP` broadcast != Direct IP).
- `references/vi-changer-mechanism.md` — code-level dump: file:line citations for the two paths, verification, and the LSPosed/API-key side path.
- `references/9router-antigravity-and-mobiproxy-sync.md` — Chi tiết quy trình xử lý khi Box MobiProxy đổi IP WAN / sập mạng & tự động phục hồi Proxy Pools trên 9Router.
- `references/proxy-special-chars-url-encoding.md` — Chuẩn hóa URL encode/unquote idempotent cho proxy có ký tự đặc biệt (`#`, `@`, `!`, `:`) tránh lỗi 407 và fragment cắt cụt URL.

