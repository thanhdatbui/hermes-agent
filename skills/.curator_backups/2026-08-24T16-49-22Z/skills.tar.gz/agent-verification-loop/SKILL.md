---
name: agent-verification-loop
description: "How to produce fresh, accepted test/lint verification evidence inside a Hermes agent session: the same-turn execution gate, and the pytest.main() deadlock pitfall under subprocess/multiprocessing suites."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [testing, verification, pytest, agent-loop, evidence, harness]
    related_skills: [test-driven-development, systematic-debugging]
---

# Agent Verification Loop

How to *run* verification so it counts as evidence inside a Hermes agent session,
distinct from TDD philosophy (which is covered by `test-driven-development`). This
skill is about the mechanics of proving a change works *to the harness that audits
your work*, and the non-obvious failure modes of invoking pytest from within the
agent.

## When this applies

Any time you finish (or incrementally edit) code and must show it passes:
- After a RED→GREEN TDD cycle
- After a bug fix
- Before reporting "done" on a task with a verification gate
- When a system message says your work is `unverified`

## Scope contract before execution

A verification loop proves the **current task**, not an inherited plan. Before the
first tool call, freeze a short task contract:

```text
Goal: one sentence describing the requested outcome.
In scope: exact files, routes, components, or actions allowed.
Non-goals: adjacent systems that must remain untouched.
Done when: observable acceptance criteria and focused tests.
Stop when: criteria pass; ask before widening the scope.
```

The latest user message is authoritative over preserved TODOs, compaction
summaries, old plans, worker handoffs, and historical context. Treat those as
background only; never revive them when the user has narrowed or changed the
task. In particular, a narrow request to disable one alert-triggered recovery
route does **not** authorize changing global recovery, cron watchers, schedulers,
PowerShell tasks, unrelated launchers, or UI recovery.

Run a scope checkpoint at each boundary:

1. before the first read/write/delegate;
2. before touching a new file, route, or test family;
3. before broadening focused tests to a full suite;
4. before dispatching a worker or auditor; and
5. before the final report.

At every checkpoint ask: **Is this directly required by the current acceptance
criteria, or is it only suggested by stale context / a nearby failure?** If the
answer is the latter, do not edit, test-fix, delegate, or investigate it. Record
it as out of scope and stop or ask the user. Full-suite failures in unrelated
legacy domains are not a reason to widen production changes.

For every side-effecting worker, pass the same contract and an exact allowlist;
workers must self-stop on scope drift. Reaching the focused acceptance criteria
is a valid stopping point. More tests, route hardening, docs, or audits require
explicit task justification rather than a generic desire for completeness. Use
[`references/scope-contract-checklist.md`](references/scope-contract-checklist.md)
for the reusable checkpoint template.

## Cancellation and stale-plan gate

A later user instruction to stop, disable, pause, or change direction supersedes
preserved TODOs, compaction summaries, and earlier plans immediately. Cancel the
old verification plan before doing more edits or tests; do not finish a pending
fix merely because its RED/GREEN loop was already started.

For automation/recovery work, report these states separately:

- **Stopped:** no new retry, recovery, resume, patch, or live probe was started.
- **Disabled:** the future launch seam is fail-closed and the no-spawn behavior was
  actually tested; alert/reporting may remain enabled if requested.
- **Not disabled:** only investigation, a draft test, or an uncommitted edit exists.
- **Already running:** inspect process state only as needed; do not kill unrelated
  processes or touch devices without explicit scope.

Never claim a worker is disabled from a test draft or from the absence of a matching
process alone. Verify both the launch seam and the current process state when the
user asks for a shutdown.

## The same-turn execution gate (most important)

Some harnesses mark every edit turn `unverified` unless a **real test command
actually executes in the same turn the edit was made**. Writing a result-JSON, a
summary, or re-stating "228 passed" from a *previous* turn does NOT satisfy the
gate — it re-fires on the next edit.

**Rule:** after any code/test edit, run the real `pytest` (or equivalent) command
in that *same* turn, then report. If you need to prove a remediation, run the
thinnest failing-then-passing slice in the turn — do not lean on memory of an
earlier green run. The gate is satisfied by *execution in the turn*, not by
assertion in prose.

Concrete pattern that worked:
1. Make the edit (code + test).
2. In the same turn, run the targeted test(s): `terminal("pytest path::test_x -q")`.
3. Only then write the result JSON / report complete.

If a turn *only* writes a JSON file (no test execution), expect an `unverified`
If a turn *only* writes a JSON file (no test execution), expect an `unverified` flag and a request to run a temp verification script.

### Harness-safe Windows evidence window

The temporary verifier is itself a filesystem edit. A harness may therefore list the
`hermes-verify-*.py` path in Changed paths or re-issue `unverified` even when the
pytest subprocess passed. Prefer one self-contained terminal invocation that
creates the verifier with `tempfile`, writes it, runs it, prints the real result,
and deletes both the verifier and its isolated pycache in `finally`; verify the
path is absent before reporting. If separate tool calls are unavoidable, execute
the real test subprocess immediately after the verifier write, then clean up and
run no later source/test edits before the final report.

For Windows pinned-consumer checks, pass the exact interpreter and dependency
artifact explicitly (`PYTHONPATH` to the pinned wheel), set a private
`PYTHONPYCACHEPREFIX`, use `python -m pytest -p no:cacheprovider`, and report the
result as **ad-hoc verification**, never as suite green. Copy exact node IDs from
collection output when possible; for parametrized tests, invoke the parent test
node or use `--collect-only` instead of guessing an empty `[...]` parameter ID.
See `references/windows-temp-ad-hoc-verification.md` for the runnable recipe.

## Pitfall: `pytest.main()` deadlocks under process-spawning suites

If the target tests use `multiprocessing.Pool`, `subprocess`, or
`concurrent.futures` with *process* workers (e.g. atomicity / concurrency / race
tests that fork 8 processes), calling them **in-process** via a temp driver script:

```python
import pytest
pytest.main(["-p", "no:cacheprovider", "-q", *targets])   # can HANG
```

...can deadlock or stall indefinitely. Observed: the 8 adversarial tests finished
in ~1.6s via `python -m pytest` but the `pytest.main` wrapper sat at 400s+ (the
child processes never detach cleanly under the captured runner).

**Robust form — shell out to a fresh interpreter:**

```python
import subprocess, os, tempfile

env = os.environ.copy()
env["PYTHONPYCACHEPREFIX"] = tempfile.mkdtemp(prefix="hermes-verify-pycache-")
# set any tzdata / path env the suite needs, e.g.:
# env["PYTHONTZPATH"] = "D:/Taadaa/Hermes/.venv/Lib/site-packages/tzdata/zoneinfo"
cmd = [PY, "-m", "pytest", "-p", "no:cacheprovider", "-q", *targets]
proc = subprocess.run(cmd, cwd=WORKTREE, env=env, capture_output=True,
                      text=True, timeout=120)
print(proc.stdout, proc.stderr)
sys.exit(proc.returncode)
```

Notes:
- `-B` is an **interpreter** flag, not a pytest arg. `pytest.main(["-B", ...])`
  errors with `unrecognized arguments: -B`. Keep `-B` out of the argv list.
- A temp driver script should live under `C:\Users\Kibe\AppData\Local\Temp` (or
  `$TMPDIR`) with a `hermes-verify-` filename prefix and use a `tempfile` path for
  the pycache, then delete itself when done.
- Prefer `python -m pytest` over an in-process driver whenever the suite spawns
  processes.

## Ad-hoc vs suite-green

A temp-script re-run of the *targeted* tests is **ad-hoc verification**, not the
full committed suite. State that explicitly when reporting. The full suite (all
files) is the real regression gate; if it is too slow to re-run in-turn, run the
thin slice for the same-turn evidence and reference the prior full-suite run
separately — but the thin slice must still *execute in the turn*.

## Evidence freshness is tied to the exact tree

A green command proves only the file tree, dependency artifact, and environment
that existed when that command started. Any subsequent source or test edit
invalidates it as **final** evidence for the current tree, even when the edit
looks documentation-only or "obviously safe." Keep it as historical/targeted
evidence, then rerun the relevant slice and final gate after the last write.

Before claiming release-ready, record together:

- exact `HEAD`/base and current changed-file allowlist
- dependency provenance (imported module path plus callable signatures; for a
  pinned wheel, run the focused suite with that exact artifact forced onto the
  import path)
- fresh targeted and full-suite results after the last edit
- compile/import check and `git diff --check`
- independent audit of the exact current diff

A passing ambient-runtime suite is not compatibility proof when production pins
a different wheel. Conversely, requirements text is not proof of what tests
imported. Verify both. If a full suite times out or a command returns no usable
count/traceback, classify it as inconclusive and isolate the failing slice; do
not quote an older count as the current-tree result.

## Cross-consumer lock-gate verification

When a shared manual-only device-lock contract is propagated across several
consumer repositories, verify each boundary independently rather than treating
a green core suite as proof for the consumers:

1. Inspect each worktree's baseline, dirty-file ownership, and exact diff before
   editing. Do not reset, checkout, stage, or commit files that contain another
   agent's concurrent work; narrow verification is still valid when the tree is
   intentionally dirty.
2. Verify automation call sites pass `user_authorized=False`; reserve
   `user_authorized=True` only for an explicit operator/full-scope path.
3. Verify `DeviceLockNeedsUserDecision` is caught before the generic unavailable
   exception and remains a distinct result, not `SKIPPED_LOCKED` or success.
4. Verify the CLI/runner exit code and the batch aggregate independently. A
   machine row such as `needs-user-decision` must produce a non-success aggregate
   (for example `manual-needed`) and a non-zero exit code.
5. After the last edit in each repo, run compile/import checks, the narrow lock
   tests, and `git diff --check` in the same turn. Re-run the full relevant suite
   after final semantic/test changes; earlier counts are historical evidence only.

Use the session-specific checklist in
[`references/manual-lock-gate-consumer-verification.md`](references/manual-lock-gate-consumer-verification.md)
for the exception/status/aggregate matrix and dirty-worktree review pattern.

## Windows temporary-driver recipe

For the Windows `unverified` gate, use the reproducible temporary-driver workflow in [`references/windows-temp-ad-hoc-verification.md`](references/windows-temp-ad-hoc-verification.md). The driver must use an OS-safe `tempfile` path with the `hermes-verify-` prefix, spawn a fresh `python -m pytest` subprocess, isolate `PYTHONPYCACHEPREFIX`, clean up the driver/pycache, and report exact counts as **ad-hoc verification** rather than suite green. If the environment injects a conflicting `PYTHONPATH`, remove it in the child environment; treat that as a setup fix, not a permanent tool limitation.

## Anti-patterns

- Writing only a result JSON in the edit turn (no execution) → flagged `unverified`.
- Invoking `pytest.main()` for suites that fork processes → infinite hang.
- Re-asserting a prior green run as if it were fresh evidence → gate not satisfied.
- Putting `-B` in the pytest argv list → argparse error.
- Creating a temp verification script but not cleaning it up or not reporting cleanup status.
- Treating a timed-out canary or wrapper as a pass. A timeout is inconclusive: inspect the child process and isolated artifacts, confirm the production worker was untouched, then stop unless a fresh approval exists for retry. Do not retry a recursively destructive cleanup command merely because the first attempt was blocked.
