# Night Chained Reg Gmail ➔ Reg TikTok Pipeline

Tài liệu kỹ thuật và quy trình vận hành chuỗi tự động ban đêm (00:00) kết hợp giữa 2 repo `register gmail` và `Tiktok_Reg`.

## 1. Cấu Trúc Khởi Chạy & Lịch Hermes Cron
- **Cron Job ID:** `38ea60c09825` (`night-chain-reg-gmail-tiktok`)
- **Lịch chạy:** `0 0 * * *` (00:00 nửa đêm hàng ngày)
- **Kênh nhận báo cáo (Deliver):** `telegram:-5139245637` (Nhóm **Gmai reg**)
- **Launcher:** `C:\Users\Kibe\AppData\Local\hermes\scripts\night_chain_reg_pipeline_launcher.py`
- **Pipeline Thực Thi:** `D:\Taadaa\Tiktok_Reg\scripts\run_night_chain_pipeline.py`

## 2. Luồng Thực Thi Chi Tiết
1. **00:00 - Khởi động Phase 1 (Reg Gmail):**
   - Gọi canonical launcher `D:\Taadaa\register gmail\run_all.ps1 -fullScopeTakeover`.
   - Kế thừa toàn bộ cấu hình: Cooldown 5 ngày, max 15 máy/batch, kiểm tra VPN preflight trên từng máy.
   - Mail tạo thành công được ghi trực tiếp vào `D:\OneDrive\TaadaaData\kibe\gmail_clean_v2.xlsx`.
2. **Phase 2 (Bridge & Reg TikTok):**
   - Sau khi batch Gmail kết thúc (hoặc timeout 90 phút), nghỉ 10s để file Excel flush hoàn toàn.
   - Gọi canonical launcher `D:\Taadaa\Tiktok_Reg\_run_all_targets.py --full-scope-takeover`.
   - `_detect_clean.py` tự động so khớp `gmail_clean_v2.xlsx` với `taikhoan_dat_v2_updated .xlsx` để lọc ra danh sách máy còn thiếu nick (< 6 acc) và gán mail mới.
   - Chạy đăng ký TikTok, bắt OTP qua Graph API/Gmail và ghi nhận vào workbook.
3. **Báo cáo tổng kết:**
   - Khi chuỗi kết thúc, pipeline tổng hợp exit code và trích xuất summary từ stdout của cả 2 batch.
   - In ra stdout chuẩn để Hermes Cron đẩy đúng 1 tin nhắn tóm tắt về nhóm Telegram **Gmai reg**.

## 3. Các Pitfalls Đã Giải Quyết (2026-08-19)
1. **Hermes `no_agent: true` output capture:**
   - Trong launcher Python, bắt buộc dùng `subprocess.run(..., capture_output=True)` và `sys.stdout.write(completed.stdout)` để flush output về stdout của tiến trình cha. Nếu không, Hermes sẽ đánh giá là silent/empty và không gửi tin nhắn về Telegram.
2. **PowerShell inline Python quoting:**
   - Trong `run_all.ps1` và `run_parallel.ps1`, tránh dùng multi-line here-string `@' ... '@` cho `python -c` khi có dấu ngoặc kép hoặc `RuntimeError("...")` vì PowerShell phân tích sai cú pháp dấu ngoặc. Chuyển sang chuỗi 1 dòng inline với `sys.exit('...')`.
3. **Lệch cột Serial trên `taikhoan_dat_v2_updated .xlsx`:**
   - Cột 10 (device ID) bị ghi nhầm ngày tạo `2026-08-18 18:27:39` và đẩy serial sang cột 11 (hoặc dòng bị `None`) sẽ khiến `_detect_clean.py` chặn toàn bộ tiến trình với `TARGET_INVENTORY_CONFLICT` hoặc `TARGET_INVENTORY_MISSING_SERIAL`. Luôn kiểm tra và sync lại `taikhoan_run_safe.xlsx` qua `taikhoan_sync_cron_launcher.py`.
4. **Assignment Manifest Roster:**
   - File `C:\Users\Kibe\AppData\Local\automation-core\assignments\register-gmail.json` bắt buộc phải chứa đầy đủ 80 máy (`machine:1` đến `machine:80`). Thiếu máy sẽ bị `assert_assigned` chặn với lỗi `TARGET_OUTSIDE_ASSIGNMENT`.
5. **UnicodeDecodeError khi capture output tiến trình con trên Windows (2026-08-23):**
   - Lỗi: `Exception in thread Thread-1 (_readerthread): UnicodeDecodeError: 'utf-8' codec can't decode byte 0xa0 in position ...: invalid start byte`.
   - Nguyên nhân: `subprocess.run(..., capture_output=True, text=True)` trên Windows mặc định decode UTF-8 thuần. Khi PowerShell/ADB in byte ANSI/CP1258/CP1252/Shift-JIS hoặc non-breaking space (`0xa0`), thread đọc pipe của Python bị crash.
   - Fix: Bắt buộc truyền `encoding="utf-8", errors="replace"` trong `subprocess.run()` (hoặc capture raw bytes và decode với `errors="replace"`) cho mọi script runner bọc PowerShell/ADB.
6. **Quy tắc màn hình khi lỗi:**
   - Chỉ khi SUCCESS mới tự động dọn dẹp về Home. Khi FAIL/Kẹt lỗi, giữ nguyên hiện trường trên thiết bị để người vận hành kiểm tra vào ban ngày.
   - **Tuyệt đối KHÔNG tự động lock máy** khi gặp sự cố, chỉ lock khi có lệnh trực tiếp từ user.
