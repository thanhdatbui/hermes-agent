---

name: taadaa-farm-batch-ops

description: "Re-run / resume farm batch jobs (TikTok upload, Tik3 render, reg, nuoi acc) using the EXACT canonical command that worked before. Resume semantics, no reinventing entrypoints, no restart-from-scratch."

version: 1.0.0

author: Hermes Agent

tags: [tiktok, farm, batch, render, upload, resume, kibe]

---



# Taadaa Farm Batch Ops


## 🛑 STOP GATE (bắt buộc — chi tiết: skill taadaa-farm-ops-rules)
Máy live + script chạy/lỗi → KHÔNG tự sửa code, KHÔNG tự chạy lại, KHÔNG tự probe/tay khi chưa được user yêu cầu.
Lỗi → screencap → gửi ẢNH THẬT (MEDIA:<path> dòng riêng, KHÔNG bọc markdown, KHÔNG gửi đường dẫn text) → DỪng chờ user hướng dẫn.
User hướng dẫn bước nào → encode bước đó vào script + test → mới chạy lại. Nghi ngờ → HỎI.

Re-running or resuming a farm batch job on the kibe/admin farm (Tiktok-video,

Tiktok_Reg, tiktok-luot nuoi acc repos).



## When to use

- User says "chạy tiếp", "resume", "y như bữa", "chạy lại cho tik3/tik2", or asks to

  continue a render/upload/reg batch that was run before.

- After a machine reset / crash interrupted a long batch and you must pick it back up.



## Core rule (from user, non-negotiable)

**Run the EXACT command that worked before. Do NOT substitute a different script or

entrypoint.** If the prior success used `run_tik3_random_render.ps1`, use that — do NOT

call `tik3_multi_batch.py` or any other module even if it looks equivalent. Different

entrypoints read different config/mapping and fail.



UPDATE 2026-08-16: `tik3_multi_batch.py` WAS fixed in-repo (find_headers now falls back

to the `Folder Video` column when no `sttvideo` column exists), so it IS a valid

entrypoint for Tik3 render now — but only when launched with the proven flag set:

`--min-videos 45 --parallel 1 --allow-existing-output --resume-complete --execute`

(start-output/start-source from the workbook row). See `references/tik3-render-avatar-20260816.md`.



This is the same as the standing farm rule: reuse the canonical script; never write a

new runner. If the canonical script lacks support, FIX+TEST that script — don't replace it.



## Steps

1. `session_search` for the exact prior command (query the launcher name + flags, e.g.

   `run_tik3_random_render StartMachine AutoRun`). Copy it verbatim — including

   `-Parallel`, `-Slot`, `-AutoRun`, working dir.

2. To RESUME (continue partial work, not restart): add ONLY flags that already exist in

   the original launcher (e.g. `-ResumeVerifyExisting`, `-OnlyExistingOutput`). Do not add

   new logic or a different script.

3. Launch as background process (`terminal` background=true, notify_on_complete=true).

4. Poll the first ~20s of log to confirm resume behavior (see Pitfalls).



## Pitfalls

- **Never delete rendered output files. EVER.** batch_render.py auto-skips outputs that

  already exist (`skipped: N.mp4 ... output da ton tai`). If a folder has 40/45 files,

  RE-RUN the render — it skips the 40 and renders only the missing 5. Deleting the 40 to

  "start clean" forces re-rendering from scratch (wasted hours + user anger 2026-08-16:

  "Lại tự ý xoá mà đéo hỏi"). The only safe partial-render flags are

  `--allow-existing-output --resume-complete` (allow-existing lets batch_render skip

  existing; resume-complete records workbook for already-complete folders).

- **Don't restart from scratch.** "Running the launcher again" is usually a RESUME:

  canonical launchers auto-skip existing valid outputs. Verify by reading the log — lines

  like `skipped: 3.mp4 -> 3.mp4 (output da ton tai)` or `(output da duoc ffprobe xac

  nhan)` mean safe resume, NOT overwrite.

- **Don't kill a process that is resuming.** If you launched without `-ResumeVerifyExisting`

  and the log shows "skipped" lines, it is already resuming correctly — do NOT kill it

  thinking it overwrites. Only kill if you launched a genuinely wrong entrypoint. (Burnt:

  killed a correctly-resuming Tik3 process, then had to relaunch.)

- **Don't invent entrypoints.** User feedback was explicit: "bữa chạy đc thì cứ y v mà

  chạy chứ chế cháo clgt" (just run what worked, stop cooking up alternatives).

- **Never delegate a farm batch to a subagent while the canonical launcher is the owner.**

  Delegating "resume Tik3" to a background subagent spawned a second runner that wrote to

  the SAME output folders in parallel (found via `Get-CimInstance` — two `local_tik3_safe_*`

  python chains + the launcher, three pipelines at once). One canonical launcher owns the

  batch; everything else must be killed or never started. If a subagent was already

  dispatched, kill its process tree (`Stop-Process -Id <pid> -Force`, verify 0 remain)

  before resuming the canonical run.

- **Exit 127 on a launcher is NOT proof of a fixed machine/source bug.** A Tik3 launcher

  died at "RUN machine 27" twice; the same machine then resumed fine on the next launch.

  Check whether the process was externally terminated (user reset / kill / parallel-run

  interference) before assuming a deterministic failure. Re-run the SAME resume command and

  watch the log; if it passes the previously-fatal machine, it was transient, not a bug.

- **Reading launcher logs: they may be UTF-16.** `tail` of `launcher.log` can show `\u0000`

  between every char (e.g. `P\u0000L\u0000A\u0000N\u0000`). Decode as UTF-16, not ASCII/UTF-8.

- **Querying processes from git-bash:** inline `powershell.exe -Command "Get-CimInstance ...

  | Where-Object { $_.CommandLine -match ... }"` breaks — bash eats `$_`. Write the query to

  a temp `.ps1` file and run `powershell.exe -File`, or use `Get-CimInstance -Filter`.

- **Find the command before acting.** Never guess the launcher/flags. `session_search` first.



## Tik3 / Tik4 render + avatar — user sequencing rules (2026-08-16, cập nhật 2026-08-19)

- **Order:** (1) finish creating NEW avatars for all Tik3/Tik4 folders FIRST, (2) THEN run render, (3) THEN in parallel: continue render + avatar the remaining source folders.
  Don't start render before avatars are done just because a process "could" run alongside.

- **Worker count: render with `--parallel 1` (worker 1).** Explicit user instruction
  ("Render video chạy work 1 thôi"). Slower but the standing choice.

- **min-videos = 45 (NOT 50) cho RENDER Tik3.** User: "Min 45 thôi t chưa bh set min 50". Với Tik4, ngưỡng min-videos của selector là 30 và target 45 (theo chuẩn pool 30).

- **Tik4 Render Launcher (2026-08-19, cập nhật 2026-08-21):** 
  - **BẮT BUỘC dùng launcher:** `powershell.exe -File run_tik4_random_render.ps1 -StartMachine <X> -EndMachine <Y> -AutoRun -Parallel 1` (đọc `D:\OneDrive\TaadaaData\kibe\Tik4.xlsx`, source dải 241..320, output dải `4, 12, 20... 636`). User yêu cầu render chạy **1 worker** (`-Parallel 1`).
  - ⚠️ **CẤM chạy trực tiếp `tik3_multi_batch.py --workbook tik4.xlsx --source-map-workbook tik3.xlsx`**: Script cũ bị mapping nhầm công thức `source 161..240` (gặp folder 164 thiếu video sẽ crash exit code 2). Luôn dùng `run_tik4_random_render.ps1`.
  - ⚠️ **Pitfall `$selectorCode` ném exception khi source thiếu video (< 30 mp4)**: Nếu một source chưa tải đủ 30 video, `select_videos()` sẽ ném lỗi. Do `$ErrorActionPreference = "Stop"`, PowerShell sẽ dừng cả batch. Phải bọc `$ErrorActionPreference = "Continue"` quanh dòng gọi `$selectorCode`, kiểm tra `$selectExit -ne 0` để in warning và `continue` sang máy tiếp theo mà không làm crash cả batch.

- **Standalone Avatar Upload Launcher (`run_tiktok_upload_avatar.ps1`):**
  - Khởi chạy tải riêng Avatar theo TikN: `echo 'RUN' | powershell.exe -File run_tiktok_upload_avatar.ps1 -Tik <N> -AssignmentManifest <path> -WorkerId <id> -ForceAvatarMachineList "<machines>" -MaxParallel 1 -HostConfigPath "D:\Taadaa\machine-config\kibe.yaml"`.
  - ⚠️ **Quy tắc dọn dẹp sau Up Avatar (2026-08-21)**: Khi hoàn thành tải và xác nhận avatar thành công trên UI, script BẮT BUỘC tự động `am force-stop com.zhiliaoapp.musically; am force-stop com.ss.android.ugc.trill` và đưa máy về màn hình chính (`input keyevent 3`) để giải phóng tài nguyên.
  - ⚠️ **Pitfall AssignmentManifest schema**: `AssignmentManifest.load()` yêu cầu bắt buộc các trường: `schema_version: 1`, `assignment_id: "..."`, `owner_id: "..."`, `resources: ["machine:X"]`, `reviewed_at: "<ISO timestamp>"`. Thiếu `assignment_id` hay `reviewed_at` sẽ raise `AssignmentError: ASSIGNMENT_MANIFEST_INVALID`.
  - ⚠️ **Pitfall MediaStore & Screen Cleaner**: Luôn xóa sạch file ảnh screenshot rác (`/sdcard/_ss.png`, `_ss_social.png`) trước khi mở picker TikTok; kiểm tra `D:\video goc\<Folder Video>\avatar.jpg` đã tồn tại (copy từ `D:\TIKTOK-videonuoinick\<Folder Video>\avatar.jpg` nếu thiếu) trước khi chạy launcher.

- **TikTok Video Upload CLI Entrypoint & Targeted Device Lock (2026-08-23, cập nhật 2026-08-24):**
  - ⚠️ **Module Entrypoint**: Trong repo `tiktok-video`, module thực thi là `scripts.tiktok_workflow` (`python -m scripts.tiktok_workflow --config ... --workflow-workbook ... --machine <N> --no-dry-run`). Không gọi bare `tiktok_workflow` từ root repo vì sẽ fail `No module named tiktok_workflow`.
  - ⚠️ **Bắt buộc Kiểm tra Live Proxy IP (`verify_live_ip=True`)**: Kiểm tra card mạng `tun0` chưa đủ (app ViChanger mở nhưng proxy chết/rớt mạng thì máy dùng Wi-Fi thường). Trong `RESOLVE_DEVICE`, bắt buộc gọi `require_android_vpn(..., verify_live_ip=True)` để broadcast `vn.vichanger.app.GET_IP` lấy IP proxy thật. Nếu mất proxy -> chặn ngay tại preflight (`VPN_REQUIRED_NOT_CONNECTED`), tuyệt đối không mở app TikTok.
  - ⚠️ **Cách khôi phục nhanh ViChanger Proxy**: Khi máy bị sập `tun0`, dùng `vi_changer_runner.set_proxy(adb_path=..., serial=..., proxy=..., timeout=30)` từ `D:\Taadaa\gan-proxy\scripts` để đẩy intent `CONNECT`/`GET_IP` cấp lại proxy live.
  - ⚠️ **Manual Targeted Run & Device Lock Invariant**: Khi chạy batch thủ công (upload video, fix máy, avatar) song song với hệ thống cron 15' đang active, BẮT BUỘC tạo file lock (`~/.codex/device-locks/machine_<N>.lock.json` với `status: "running"`, `user_authorized: true`, `project: "tiktok-video"`, TTL 2h) trên các máy chỉ định trước khi chạy để ngăn cron feed chen ngang gây xung đột UI (màn hình CapCut/Upload vs Profile feed navigation). Đồng thời `cronjob pause` cron feed trong thời gian chạy batch thủ công lớn.

- **TikTok Follow Drop & Trust Cooldown Rules (2026-08-23):**
  - **Hiện tượng nhả follow (Follow Drop):** Khi nick bị TikTok đánh cờ action limit / shadow penalty, việc nghỉ 3 ngày vẫn có thể bị nhả follow do TikTok cần **5 – 7 ngày** để reset trust score.
  - **Quy tắc Cooldown:** Tuyệt đối không test follow hàng ngày vì mỗi lần follow fail/nhả sẽ **reset chu kỳ phạt lại từ đầu**.
  - **Duy trì trong thời gian nghỉ follow:** Bắt buộc duy trì đăng video đều (đạt tối thiểu **≥ 3 – 5 video/nick**) kết hợp nuôi feed thuần túy (xem video, thả tim nhẹ) để tích lũy tín hiệu user thật trước khi test lại 1-2 follow For You.

- **TikTok Feed Session Profile Verification Lag & Target Video Range (2026-08-21, 2026-08-22):**
  - Khi đối soát hồ sơ cuối phiên nuôi (`verify_profile`), nếu vừa bấm vào tab Hồ sơ nhưng TikTok chuyển cảnh chậm, node username `@...` có thể chưa kịp render lên cây UI dẫn đến báo động giả `profile verification mismatch: profile account mismatch`.
  - Fix chuẩn (repo `tiktok-luot nuoi acc`, commit `e337d2f`): Tự động `time.sleep(1.5)` và chụp lại XML lần 2 trước khi kết luận mismatch, tránh ngắt phiên và gọi recovery oan.
  - **Ngân sách thời lượng & Target video (2026-08-22):** Mặc định phiên nuôi chuẩn là `10 - 18 video` (`FEED_SESSION_MIN_TOTAL_VIDEOS = 10`, `FEED_SESSION_MAX_TOTAL_VIDEOS = 18`). Trên S7/S7 Edge (latency 40-50s/video gồm swipe, dump XML ATX port 7912 và 17 popup handlers), cấu hình cũ `15 - 30 video` ngốn tới ~27.5 phút gây lỗi `run plan max_duration_seconds exceeded` khi chạm trần 1500s (25 phút). Trần 18 video đảm bảo phiên hoàn thành trong ~17.5 phút, dư >7.5 phút an toàn. Chi tiết: `references/feed-session-duration-and-timeout-budget.md` trong skill `tiktok-feed-session`.

- **Resume collision & Renumber fix trong `download_by_niche.py` (2026-08-21):**
  - Khi resume một folder đã có file số cũ (`1.mp4..46.mp4`) từ đợt chạy trước đó, `renumber_mp4_files` từng ném `FileExistsError: numeric target is not part of the rename set` làm chết cả batch 16 worker.
  - Fix chuẩn (commit `ee654f6`): `stale_orphan_numeric_mp4s()` tự dọn file số cũ (>24h không có trong DB) trước khi kiểm tra conflict. Chạy lại với `--continue-on-insufficient` để skip folder thiếu nguồn.

- **Quy trình Thay thế & Tái cấp nguồn (Cut & Backfill Re-render) khi làm lại video nick (2026-08-24):**
  - **Dọn nick lỗi:** Khi đổi nội dung do reup nhầm kênh / dính bản quyền: xóa sạch `D:\video goc\<máy>` và `D:\TIKTOK-videonuoinick\<Folder Video>`.
  - **Chuyển folder dự phòng:** Lấy folder nguồn và folder render hoàn tất còn dư: **BẮT BUỘC CUT (dọn sạch folder cho đi)**, tuyệt đối không chỉ copy để tránh trùng lặp nội dung video giữa các folder/máy.
  - **Bù lại folder nguồn vừa cho:**
    1. Kiểm tra folder cho đi chưa từng được nick nào chạy upload trong `Tik1..Tik4.xlsx`.
    2. Reset/đồng bộ thông tin folder trong `D:\CodexRuntime\tiktok-video\state.db` (bảng `folders`, `videos`).
    3. Nạp bộ video nguồn sạch mới (≥ 45 video MP4) + `avatar.jpg` vào `D:\video goc\<folder>`.
    4. Chạy render standalone: `python scripts/random_batch_render.py --input-dir "D:/video goc/<folder>" --output-dir "D:/TIKTOK-videonuoinick/<folder>" --preset "presets/preset_owner.json" --randomize --slot <N> --machine-id <M> --seed-offset 0 --parallel 2 --resume-verify-existing`.
    5. Đảm bảo copy `avatar.jpg` từ `video goc` sang `TIKTOK-videonuoinick` nếu render pipeline chưa sync.

- **S7 ROM gốc khi mất điện / sập nguồn (2026-08-21):**
  - Samsung Galaxy S7 chạy ROM gốc **KHÔNG tự khởi động lại** khi mất điện cấp vào box; máy sẽ rơi vào trạng thái sạc pin tắt màn (LPM) hoặc tắt ngúm → sau khi cúp điện / sập nguồn phải bấm nguồn bật tay từng máy (trừ khi đã mod `/system/bin/lpm`).
  - Tránh cắm chung ổ chia PC + 4 Box S7 (tổng tải >1.000W dễ sụt áp / sập nguồn PC). PC nên cắm riêng ổ tường.

- **Cronjob theo dõi tạm thời (Watchdog) phải dùng `no_agent: true`:**
  - Nếu tạo cron LLM-agent không ghim model (`model=None`), khi profile chuyển model toàn cục (ví dụ `worker` → `ag/gemini-3.7-flash-high`) scheduler sẽ chặn chạy với lỗi `Skipped to prevent unintended spend: global inference config drifted`. Luôn dùng `no_agent: true` + `script` cho các cron theo dõi trạng thái / watchdog.
  - Chu kỳ cron `device-locks-watchdog` phải duy trì `every 15m` (không để `every 120m` vì thời gian phát hiện và cảnh báo lock quá trễ). Script chỉ gửi tin khi `len(locks) > 0` và im lặng khi `len(locks) == 0`.

- **min-videos DOWNLOAD CHỐT 30 (16/08 đêm).** User phân tích: follow kênh chủ yếu từ
  FOLLOW CHÉO farm (~80-90%), tự nhiên chỉ 10-20% → video không quyết định follow; cần
  ~20-30 video đủ "độ dày" chống flag khi follow chéo dồn (kênh 2-3 video nhận 500 follow
  = pattern → shadow-ban). min 45 khó tìm nguồn (454 kênh → 267 qualified; hạ 30 → nhiều
  hơn hẳn). Đã sửa constraint 42→30 ở CẢ `download_by_niche.py` + `source_pool_builder.py`
  ("yeu cau 30 <= min"). Download/qualify dùng `--min-videos 30 --target-videos 60
  --max-videos 65`; qualify lại ra `sources.qualified30.json`. Source folders
  are pre-verified complete (enough videos already downloaded) — don't gate on min-video
  checks; just render.

- **Report cadence: render silently in background; report ONCE when a 10-folder batch

  completes** ("xong 10 folder thì báo 1 lần"). Don't spam progress between batches.

- **Avatar NEW rule (overwrite from Tik3 onward only):** old avatars are wrong content.

  Regenerate via `_make_avatar.py` (calls make_representative_avatar: person → animal →

  bright-frame fallback). Overwrite only folders ≥ Tik3 (Tik3 source = folder 161+);

  SKIP folders 1-160 already used by Tik1/Tik2. `D:\video goc` folders ≥305 may have NO

  video (only avatar.jpg) — those are Tik3 OUTPUT folders whose videos live in

  `D:\TIKTOK-videonuoinick`; generate their avatar direct from the TV folder

  (make_representative_avatar on the TV videos), not from video goc.

- **Avatar rule ƯU TIÊN CAO NHẤT (user đổi 16/08 chiều tối):** người → động vật → frame

  sáng lên ƯU TIÊN CAO NHẤT, **BỎ hẳn avatar kênh thật** khỏi bước 1 (sửa cả

  download_by_niche.py `make_avatar_for_folder` + `_make_avatar.py` subject_type

  `person`→`auto` + yolov8n.pt — commits `662ff58`/`0b2fc7d`). **"Những cái đã sửa r thì

  đừng đụng tới nữa"**: avatar đã tạo (161+ theo rule cũ) GIỮ NGUYÊN — rule mới chỉ áp

  lần chạy sau. KHÔNG chạy lại để "đồng bộ rule" và KHÔNG canary trên folder đã có avatar.

- **Folder structure (don't get confused):** `Folder Video` column = OUTPUT folder in

  `D:\TIKTOK-videonuoinick`; `video gốc` column = SOURCE folder in `D:\video goc`. Each Tik

  (Tik1/Tik2/Tik3) has its OWN output range in TV; numbers overlapping between Tiks is NOT a

  conflict (e.g. Tik3 machines 1-20 → Folder Video 3..155 are correct, not clashing with

  Tik1/Tik2). Tik3 machine N: Folder Video = 8N−5, video gốc = 160+N.



See `references/tik3-render-avatar-20260816.md` for the exact command + avatar scripts.



## Download video gốc (fill to 480 folders) — sequencing + platform state (16/08)

- **Thứ tự CHỐT CUỐI (user đảo quyết định 2 lần trong session):** discovery + download

  **CHẠY SONG SONG** — "Ủa phải discovery xong ms down à, tưởng làm tới đâu down tới đó" +

  "Sao k làm song song". KHÔNG chờ discovery xong mới tải. Cơ chế: `source_pool_builder`

  ghi checkpoint `sources.partial.json` SAU MỖI NICHE → loop script copy partial →

  `sources.json` → chạy download → sleep 120s → lặp (đã có `qualify-loop-20260816.py` /

  `download-loop-20260816.py` tại `D:\CodexRuntime\tiktok-video\`). state.db skip folder

  đã complete nên chạy lại nhiều vòng an toàn.

- **Discovery thiếu nguồn → chạy TIẾP (16/08 đêm):** sau discovery 80/80 chỉ 70 kênh
  qualified (đủ 45) → user "vậy thì discovery tiếp đi?". Đã sửa `target_counts()` trong
  source_pool_builder.py thành YouTube 100% (`{"tiktok":0,"instagram":0,"youtube":total}`)
  + `--min-sources-per-platform 0` (mặc định 1 → fail vì tiktok/IG = 0) → chạy lại
  `--auto-discover --resume-discovery --target-total-sources 480 --min-sources-per-platform 0`
  → 454 YouTube sources (gấp ~4x) → qualify lại → 267 qualified (loại vtv24 còn 267-1).
  Cứ discovery thêm → qualify lại → download hốt nguồn mới (state.db skip đã xong).

  `source_pool_builder --auto-discover` (thiếu `--qualify-videos`) ghi source KHÔNG có

  `qualified_video_count` → kênh 4-video lọt pool → download fail `INSUFFICIENT_POOL`

  đủ loại niche. User: "Tưởng discovery nó đã kiểm tra kênh đủ điều kiện r chứ".

  Đúng quy trình: discovery xong (hoặc song song qua qualify-loop) → chạy

  `source_pool_builder --source-manifest <jsonl> --qualify-videos --qualification-parallel 4

  --min-videos 30 --max-videos 65 --max-candidates-per-source 200 --min-sources-per-platform 0
  --cookies-file <rt>/youtube-cookies-netscape.txt --output sources.qualified30.json`

  → CHỈ tải nguồn đã qualified. qualify probe từng video qua YouTube → chậm + rate-limit

  ("not available" hàng loạt = chặn tạm, không phải video chết) — chạy nền, kiên nhẫn. **`--cookies-file` BẮT BUỘC trong qualify** (flag thêm vào source_pool_builder 16/08 đêm, trước đó `unrecognized arguments: --cookies-file`): qualify không cookies → YouTube probe "not available" ồ ạt + đếm thiếu + chạy cả giờ không xong; có cookies probe đúng + nhanh (454 kênh ~15-20 phút).

- **Worker/spam-IP (user đổi ý 3 lần, CHỐT CUỐI 16/08 đêm, cập nhật scale 2026-08-24):** "tăng worker lên làm" →
  ip à thế thì thôi" → "Download cũng k đc tăng worker sợ dính spam ip à" → cuối cùng
  **"tăng thêm worker dùng proxy khác trong pool proxy đc k" = ĐƯỢC**. CHỐT: **worker ↑
  OK nếu kèm `--proxy-pool` xoay** (mỗi thread 1 proxy khác IP → không spam cùng IP). Đã
  chạy `--parallel 4 --proxy-pool <xlsx> --cookies-file`. KHÔNG tăng worker khi KHÔNG có
  proxy xoay.
- **Khả năng scale Worker & Tối ưu bộ lọc Download (2026-08-24):**
  - **Scale Worker:** Máy Kibe (Dual Intel Xeon E5-2680 v4, 56 threads, 64GB RAM) đáp ứng chạy `--parallel 32` workers song song (`ThreadPoolExecutor` I/O-bound + audio check). Resume an toàn qua `state.db` + ledger.
  - **Nới lỏng bộ lọc tiếng Việt:** Nguồn trong `sources.combined_yt_tt.json` đã được qualify từ trước → `candidate_passes_language_source_gate` luôn trả `True` để nhận cả video không dấu / nhạc trend, tránh làm hụt pool video < 30.
  - **Nới lỏng Whisper & Ngưỡng điểm:** Mặc định cho điểm đỗ (0.75) cho video từ nguồn Việt, chỉ loại bỏ khi Whisper xác nhận 100% tiếng nước ngoài (`audio_lang_not_vi`). Giúp tránh gần 70% video bị kẹt ở hàng đợi `review` (`language_score_below_threshold`).
- **1 folder = 1 kênh duy nhất (user: "1 folder vẫn đủ của 1 kênh chứ k phải lấy tùm lum
  kênh cắm vào 1 folder").** Cơ chế code: run_folder thử từng kênh → kênh đầu đủ ≥min
  video → `source = option; candidates = option_candidates; break` → folder CHỈ nhận
  video kênh đó, KHÔNG trộn. `--parallel N` chỉ song song TRONG folder (N thread cùng
  kênh), giữa folder vẫn tuần tự. **Folder đã complete KHÔNG bao giờ đụng lại** (user:
  "Mấy cái đã down đủ r thì k đụng nhé") — reserve_folder chặn status complete, chạy lại
  chỉ skip.

- Nguồn tải chuẩn: `download_by_niche.py --total-folders 480 --start-folder <thiếu đầu>

  --sources <rt>/sources.qualified30.json --state-db <rt>/state.db --runtime <rt>

  --output-root 'D:\video goc' --niche-mode strict --min-videos 30 --target-videos 60
    --max-videos 65 --parallel 4 --continue-on-insufficient
    --proxy-pool "D:/OneDrive/TaadaaData/kibe/PROXYgandienthoai.xlsx"
    --cookies-file <rt>/youtube-cookies-netscape.txt`
  --max-videos 65 --parallel 1 --continue-on-insufficient`. Folder nguồn đã được chuẩn bị

  đủ video bởi khâu tải — không gate thêm min-video. **`--sources` phải là qualified file**;

  **`--continue-on-insufficient` bắt buộc** (mặc định INSUFFICIENT_POOL dừng cả batch — flag

  này skip folder thiếu nguồn, chạy tiếp, đúng ý user \"kênh nào đủ điều kiện thì down\").\n- **Dẹp nguồn = sửa CẢ `PLATFORMS`/`PLATFORM_TARGET` trong script** (không chỉ sources.json):\n  `choose_platform` chọn theo ratio (count/target) → IG chưa đủ target vẫn bị chọn dù không\n  có source. Đã dẹp IG (403 chặn API, yt-dlp 2026.07.04 mới nhất không fix; TikTok extractor\n  trong yt-dlp bị \"marked as broken\" — không search/tải TikTok qua yt-dlp được).\n  **PLATFORMS = (\"youtube\",), PLATFORM_TARGET = {\"youtube\": 1.0} (chốt cuối, commit\n  `241424f`)** — TikTok dẹp luôn vì kể cả target 0.15 vẫn bị `choose_platform` chọn trước\n  (ratio 0) rồi fail do chỉ 3-5 sources. Loại kênh nhà nước (vd @vtv24) theo user.\n- **Qualify gate (commit `241424f`):** discovery KHÔNG tự check kênh đủ điều kiện trừ khi\n  chạy `--qualify-videos` (thiếu flag → 0/176 sources có `qualified_video_count`). Lệnh\n  qualify: `source_pool_builder --source-manifest <jsonl> --qualify-videos\n  --qualification-parallel 4 --min-videos 45 --max-videos 65 --max-candidates-per-source 200\n  --min-sources-per-platform 0 --output sources.qualified.json` — **`--min-sources-per-platform\n  0` bắt buộc** (không có → exit 2 \"thieu platform ['instagram']\" dù đã dẹp IG). Đã verify:\n  70/70 sources qualified ≥45 video (YT 67 + TT 3). Sau khi sửa code: KILL + restart loop\n  (process giữ module cũ).

- **Cookies (CHỐT 16/08 tối): Camoufox cookies là cách qua bot-check YouTube ĐÃ HOẠT ĐỘNG.**

  Chrome/Edge vẫn KHÔNG đọc được (App-Bound/DPAPI — yt-dlp issue #7271) và Firefox profile

  chưa login thì vô dụng — nhưng dùng `camoufox` (pip install camoufox[geoip] + camoufox

  fetch) mở youtube.com headless → export cookies Netscape → `yt-dlp --cookies-file` qua được

  "Sign in to confirm you're not a bot" (test thật: video Numb ok, channel flat ok). Cookies

  hết hạn sau vài giờ → khi download quay lại "Sign in" là phải refresh cookies bằng Camoufox,

  KHÔNG phải lỗi khác. Đã commit `810cf96` (flag `--cookies-file` + `scripts/browser_download.py`).

- **Proxy pool (`--proxy-pool`)**: file xlsx PROXYgandienthoai (cột `proXy`) format
  `host:port:user:pass` (vd `test.taadaa.click:5101:mobi1:TaadaaMobi#2026!`).
  **BẮT BUỘC URL-encode `user` và `pwd` bằng `urllib.parse.quote(..., safe="")`** trong `format_proxy()`.
  Ký tự đặc biệt `#`, `!` nếu không encode sẽ làm yt-dlp parse URL hỏng dẫn tới `407 Proxy Authentication Required` hoặc `Failed to parse URL`.
  Sau khi fix URL-encode và đã có Global Whisper Model Lock, download `--parallel 16` xoay vòng qua 38 cổng di động an toàn và đạt tốc độ tối đa.

- Chi tiết + transcript + lệnh test nhanh: `references/youtube-botcheck-camoufox-20260816.md`.

- **CRITICAL PITFALL: `faster-whisper` Memory Leak & OOM 0xc0000142 (2026-08-18):**
  - Khi chạy `download_by_niche.py` song song nhiều worker (16-20 parallel), việc gọi `WhisperModel` (`faster-whisper`) trong thread worker để check ngôn ngữ audio bị leak C++/ONNX heap, phình Virtual Memory lên đến **150 GB**.
  - **Hậu quả hệ thống:** Windows cạn kiệt Commit Charge (Out of Virtual Memory) → Hàng loạt tiến trình mới (`adb.exe`, `conhost.exe`) crash khởi động với mã lỗi **`0xc0000142`** (STATUS_DLL_INIT_FAILED); OneDrive sync engine bị kẹt thread ở Kernel filter driver (`cldflt.sys`) tạo thành zombie process không thể taskkill và bắt đăng nhập lại.
  - **Khắc phục khi bị:** Kiểm tra `Get-Process | Sort-Object PrivateMemorySize64 -Descending` → Kill tiến trình python leak RAM ngay lập tức để giải phóng virtual memory. Với OneDrive kẹt kernel mode, các script local đọc/ghi file `D:\OneDrive` vẫn chạy bình thường, khởi động lại PC sau khi xong ca để phục hồi OneDrive sync. Không chạy whisper song song nhiều worker khi chưa gom model/giải phóng bộ nhớ.

- **youtube_profile regex hóc:** handle Unicode tiếng Việt (`@KhámPháBếpViệt`) fail regex cũ

  `@[A-Za-z0-9._-]+` → đã sửa thành `@[\w.-]+` (source_pool_builder.py, đã commit).

- **state.db folder fail giữ platform cũ:** reset sạch

  `UPDATE folders SET status='pending', platform='pending', source_channel=NULL, video_count=0

  WHERE folder_num=<N>` — chỉ set status không đủ (platform cũ 'instagram' vẫn bị

  folder_row["platform"] đọc lại → lại fail IG). Sau khi đổi PLATFORMS cũng phải reset.

- Chi tiết lỗi + commands: `references/tik3-render-avatar-20260816.md` → mục Download.



## Nuoi acc feed batch (tiktok-luot nuoi acc)



Run the feed/nuôi-acc session for a workbook row across all machines. The canonical launcher

is `run_74machines.bat`, but it does `set /p ROW_INDEX=` (interactive prompt) — so from

Hermes you MUST invoke the underlying PowerShell directly (exact recipe + preflight +

verification in `references/nuoi-acc-feed-batch.md`):



```powershell

# From repo root D:\Taadaa\tiktok-luot nuoi acc

$env:PYTHONPATH=""

powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/run-feed-session.ps1 `

  -Row <N> -Preset full `

  -AccountWorkbook "D:\OneDrive\TaadaaData\kibe\taikhoan_run_safe.xlsx" `

  -SkipAccountWorkbookSync -LocalRun `

  -MachineStartStaggerMs "2000,8000" -RandomizeMachineOrder `

  -Python "D:\Taadaa\python-envs\automation\Scripts\python.exe" -Run

```



Key points (match the canonical bat — don't reinvent):

- `-Row <N>` — account row 1-6; user must specify which row (preflight).

- `-Preset full -LocalRun` — discover machines from the workbook row, bypass the

  assignment-manifest/worker gate. Do NOT combine `-LocalRun` with `-Machines`.

- `-SkipAccountWorkbookSync` — workbook already synced; avoids re-sync from a (possibly

  moved) tracking workbook. Without it, bare `run-feed-session.ps1` tries to sync from

  `TIKTOK_TRACKING_WORKBOOK` and fails on a stale path.

- `-Python <automation venv>` — EXPLICIT. The ps1 defaults to `python` on PATH, which in the

  Hermes terminal resolves to the hermes venv (Python 3.11, wrong version). Always pass

  `D:\Taadaa\python-envs\automation\Scripts\python.exe`.

- `PYTHONPATH` MUST be cleared (`$env:PYTHONPATH=""`) — the Hermes terminal's PYTHONPATH

  shadows PIL under the 3.12 automation venv (`ImportError: cannot import name '_imaging'`).

  See `consumer-scheduler-orchestration` P9.

- ALWAYS preview first (drop `-Run`): confirm the row resolved to the expected machine list

  (e.g. 1-80 for kibe) before running live.



Launch as `terminal` background=true, notify_on_complete=true; poll the first ~30s to confirm

it printed `[HOST] host=kibe machines=1-80 ...` (host config loaded), NOT an ImportError.



## Register Gmail & TikTok Chained Night Batch Ops (00:00 Night Cron)

- **Repo liên quan:** `D:\Taadaa\register gmail` + `D:\Taadaa\Tiktok_Reg`
- **Mục tiêu:** Tự động hóa chuỗi chạy ban đêm: 00:00 khởi chạy batch Reg Gmail (`run_all.ps1`) -> Xong Gmail tự động kích hoạt `_run_all_targets.py` để lấy mail mới tạo đăng ký TikTok.
- **Entrypoint Canonical:**
  - Script tổng hợp: `D:\Taadaa\Tiktok_Reg\scripts\run_night_chain_pipeline.py`
  - Launcher Hermes: `C:\Users\Kibe\AppData\Local\hermes\scripts\night_chain_reg_pipeline_launcher.py`
  - Cron Job: `night-chain-reg-gmail-tiktok` (ID: `38ea60c09825`, lịch `0 0 * * *`, deliver `telegram:-5139245637` - nhóm Gmai reg).
- **Quy tắc vận hành & Chốt an toàn:**
  - **Kế thừa cấu hình gốc:** `run_all.ps1` tự động lọc cooldown (mặc định 5 ngày), max 15 máy/batch, kiểm tra VPN preflight trên từng máy.
  - **Tự động bốc target:** `_run_all_targets.py` tự gọi `_detect_clean.py` so khớp mail sạch từ `gmail_clean_v2.xlsx` với các máy chưa đủ 6 acc trên `taikhoan_dat_v2_updated .xlsx`.
  - **Quy tắc thoát app/lỗi:** Chỉ khi SUCCESS mới thoát/về Home; máy bị lỗi kẹt lại giữ nguyên màn hình hiện trường theo đúng thiết kế gốc của script. Ca nuôi acc 06:00 sáng tự có preflight dọn dẹp app trước khi vào phiên.
  - **Khóa máy (Lock):** Tuyệt đối KHÔNG tự động lock máy; chỉ lock khi có lệnh trực tiếp từ user.
  - **Báo cáo kết quả:** Gửi đúng 1 tin nhắn tổng kết duy nhất về nhóm Telegram `Gmai reg` (`-5139245637`).

### Pitfalls & Bài học đã fix (2026-08-19)
- **Hermes `no_agent: true` cron output capture:** File launcher trong `~/.hermes/scripts/` bắt buộc phải `capture_output=True` từ subprocess và flush thẳng ra `sys.stdout` (`sys.stdout.write`) thì Hermes mới nhận diện có output để đẩy tin nhắn về Telegram (nếu subprocess không pipe stdout thì Hermes báo `Status: silent (empty output)`).
- **PowerShell multi-line string escape với Python inline:** Trong file `.ps1`, tránh dùng khối `@' ... '@` nhiều dòng gọi `python -c` khi có dấu ngoặc kép hoặc `raise RuntimeError("...")` vì PowerShell dễ parse sai dấu đóng ngoặc `)` dẫn đến `SyntaxError: '(' was never closed`. Hãy gói thành chuỗi 1 dòng `"import ...; print(...)"` chuẩn (dùng `sys.exit('...')` để an toàn khi chạy Python `-O`/`-OO`).
- **Lệch cột Excel trong `taikhoan_dat_v2_updated .xlsx`:** Cột `device ID` (cột 10) bị ghi đè ngày giờ `2026-08-18 18:27:39` và dồn serial sang cột 11 (hoặc dòng bị thiếu serial `None`) sẽ làm `_detect_clean.py` của `Tiktok_Reg` chặn toàn bộ batch với lỗi `DETECTION_BLOCKED: TARGET_INVENTORY_CONFLICT` hoặc `TARGET_INVENTORY_MISSING_SERIAL`. Fix: sửa đúng cột trên `taikhoan_dat_v2_updated .xlsx` rồi chạy `taikhoan_sync_cron_launcher.py` để sync sang `taikhoan_run_safe.xlsx`.
- **Assignment Manifest 80 máy:** File `register-gmail.json` trong `automation-core/assignments/` phải khai báo đủ `machine:1` đến `machine:80`, nếu thiếu máy nào launcher `run_all.ps1` sẽ fail ở bước preflight `TARGET_OUTSIDE_ASSIGNMENT:machine:X`.
- **`subprocess.run` Windows pipe decode crash (`UnicodeDecodeError: 'utf-8' codec can't decode byte 0xa0`):** Khi bọc `powershell.exe` hoặc ADB qua `subprocess.run(..., capture_output=True, text=True)`, Windows console có thể in ký tự CP1258/CP1252/byte lạ (`0xa0`). BẮT BUỘC thêm `encoding="utf-8", errors="replace"` trong `subprocess.run()` để tránh crash reader thread.

- **Nguồn TikTok song song với YouTube & Direct Fallback (2026-08-22):**
  - Cào danh sách video TikTok bằng `yt-dlp` yêu cầu bắt buộc header `User-Agent` Chrome + `Referer: https://www.tiktok.com/` trong `http_headers`.
  - Khi tải stream MP4 đơn lẻ bị TikTok chặn (`Unexpected response from webpage request`), script tự động kích hoạt `download_tiktok_direct()` qua API TikWM để tải trực tiếp video không watermark, tránh lỗi `download_no_media`.


## references/

- `references/tiktok-upload-live-proxy-ip-and-isolation-20260824.md` — Quy tắc bắt buộc kiểm tra live proxy IP (verify_live_ip=True qua ViChanger GET_IP), cách ly device-lock giữa batch upload và cron feed, và entrypoint chuẩn scripts.tiktok_workflow.
- `references/batch-upload-cron-isolation-rules.md` — Quy tắc bắt buộc tạm dừng cron feed khi kích hoạt manual batch upload để tránh tranh chấp thiết bị và lỗi navigation.
- `references/taadaa-cleanup-retention-protocol.md` — Quy tắc bắt buộc backup trước khi dọn dẹp thư mục D:\Taadaa; danh mục log change pass / reg mail / credentials cấm xóa tuyệt đối.
- `references/tik3-resume.md` — exact prior Tik3 command, launcher skip behavior, the

  wrong-entrypoint failure transcript.

- `references/tik3-render-avatar-20260816.md` — Tik3 render exact command (fixed

  tik3_multi_batch.py flags), avatar NEW-rule scripts, folder-structure facts, lock rule.

- `references/nuoi-acc-feed-batch.md` — exact nuoi acc feed-batch recipe: preflight, the

  PYTHONPATH-cleared launch, scheduler re-enable note, and first-30s verification.

- `references/youtube-botcheck-camoufox-20260816.md` — qua bot-check YouTube: Camoufox →
  export cookies Netscape → `yt-dlp --cookies-file`; proxy-pool format/pitfalls (đảo thứ tự
  user@host, 407 khi parallel, test bằng kênh VN); SABR pitfall của browser_download.
- `references/night-chained-reg-gmail-tiktok-pipeline.md` — Quy trình vận hành & cấu hình chuỗi Cron đêm tự động (00:00) Reg Gmail -> Reg TikTok, xử lý capture output Hermes và fix lỗi PowerShell quoting / Workbook mismatch.

  user@host, 407 khi parallel, test bằng kênh VN); SABR pitfall của browser_download.

