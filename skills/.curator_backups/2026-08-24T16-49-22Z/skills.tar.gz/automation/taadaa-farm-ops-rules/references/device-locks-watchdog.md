# Device Locks Watchdog Operation

Use this reference when operating, inspecting, or debugging the device locks watchdog and reporting mechanism.

## Core Properties
- **Watchdog Script**: `C:\Users\Kibe\AppData\Local\hermes\scripts\watch_device_locks.py`
- **Cron Job ID**: `71c2a1b6268c` (`device-locks-watchdog`, schedule `every 120m`)
- **Lock Storage**: `~/.codex/device-locks/machine_<N>.lock.json` và `serial_<serial>.lock.json`
- **Schema Compatibility**: Phải hỗ trợ đa dạng schema lock từ các repo khác nhau (`machine` hoặc `stt`, `project` hoặc `owner`, `serial` hoặc `device_id`, parse `machine_<N>` từ tên file). Không được phụ thuộc đơn lẻ vào `machine` / `project` để tránh hiển thị `[Máy None]` hay `unknown`.

## Behavior & Trigger Semantics
1. **Silent Watchdog**: When no active lock files (`machine_*.lock.json`) exist in `~/.codex/device-locks/`, the script produces output to console only and stays silent (does not spam empty notifications to Telegram).
2. **Alert on Active Locks**: When one or more locks are detected:
   - Formats a message listing each locked machine, owner project/PID, status, duration, and start time.
   - Highlights locks held over 120 minutes with `⚠️ (QUÁ HẠN > 30P / 2H)`.
   - Sends the report directly to Telegram group `-5518578446` via the bot token found in config/env.
3. **Manual Trigger / On-Demand Check**:
   - To trigger an immediate check and report: execute `python C:\Users\Kibe\AppData\Local\hermes\scripts\watch_device_locks.py` or trigger the cron job `cronjob action='run', job_id='71c2a1b6268c'`.

## Unlock & Remediation Procedures
- **Mở khóa máy đơn lẻ**: Di chuyển cả `machine_<N>.lock.json` và `serial_<serial>.lock.json` tương ứng vào thư mục backup có timestamp `backup_user_unlock_<timestamp>`.
- **Mở khóa toàn bộ ("Unlock all" / "Mở khóa hết")**: Backup và dọn sạch toàn bộ `*.lock.json` trong `~/.codex/device-locks/` vào thư mục `backup_user_unlock_all_<timestamp>`.
- Tuyệt đối giữ đúng mã máy/serial, không để rơi vào tình trạng parse lỗi ra `Máy None`.
