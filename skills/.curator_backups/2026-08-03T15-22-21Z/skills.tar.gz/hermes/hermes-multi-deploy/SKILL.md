---
name: hermes-multi-deploy
description: "Deploy and sync Hermes across multiple machines via Git repo — canonical skills, credential bundles, idempotent setup."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [hermes, deploy, multi-machine, skill-sync, git, windows]
    related_skills: [hermes-agent, codex, claude-code]
---

# Hermes Multi-Machine Deployment

Deploy Hermes to multiple Windows machines sharing one private Git repo. Machine A and Machine B both run Hermes, develop skills independently, and sync via `git pull` + `sync-skills.ps1`.

## Architecture

```
D:\Taadaa\Hermes\                  ← private Git repo
├── skills/                         ← canonical shared skills (source of truth)
├── deploy/
│   ├── setup-admin.ps1             ← first-time bootstrap (one per machine)
│   ├── sync-skills.ps1             ← recurring skill sync
│   ├── README.md
│   ├── hermes-home/                ← bootstrap config, persona, credentials
│   │   ├── config.yaml
│   │   ├── SOUL.md
│   │   ├── .env                    ← unignored via .gitignore !
│   │   └── auth.json               ← unignored via .gitignore !
│   └── codex-home/                 ← Codex CLI state/auth bootstrap
│       ├── .cockpit_codex_auth.json
│       └── .codex-global-state.json
── .gitignore                      ← blocks deploy/hermes-home/skills/ (no snapshot)
── ...hermes-agent source...
```

### Key design decisions

| Decision | Reason |
|----------|--------|
| `skills/` at repo root = canonical | Avoids snapshot divergence between deploy/ and skills/ |
| `deploy/hermes-home/skills/` gitignored | No stale snapshot; sync always pulls from `skills/` |
| `sync-skills.ps1` uses `robocopy /E` | Copies new/updated files without deleting machine-local skills |
| Credential bootstrap via `Copy-BootstrapFile` | Only copies when destination file does not exist → idempotent |
| `.gitignore` negation for credentials | Repo is private; commit credentials directly — no encryption layer |
| No `/MIR` or `/PURGE` in robocopy | Machine-local skills (network, desktop, per-machine) survive sync |

## Setup (first time on a new machine)

```powershell
git clone https://github.com/<user>/hermes-agent D:\Taadaa\Hermes
cd D:\Taadaa\Hermes
Set-ExecutionPolicy -Scope Process Bypass
.\deploy\setup-admin.ps1
```

Script does:
1. Create Python venv + `pip install --editable .`
2. `npm install --global @anthropic-ai/claude-code @openai/codex`
3. Call `sync-skills.ps1` (copies repo `skills/` → `%LOCALAPPDATA%\hermes\skills`)
4. Copy `config.yaml` and `SOUL.md` to Hermes home
5. Copy `.env`, `auth.json`, Codex state **only if destination does not exist**

## Recurring skill sync

```powershell
cd D:\Taadaa\Hermes
git pull origin main
.\deploy\sync-skills.ps1
hermes        # or restart gateway
```

Or inline in a session: `/reload-skills`.

## Two-machine sync workflow

Both machines commit locally. When ready to sync:

```powershell
# Machine A (goes first)
cd D:\Taadaa\Hermes
git pull --rebase origin main
git add skills
git commit -m "feat(skills): update from machine A"
git push origin main
.\deploy\sync-skills.ps1

# Machine B (goes second)
cd D:\Taadaa\Hermes
git pull --rebase origin main
# if conflict → edit file, remove <<<<<<< markers, git add, git rebase --continue
git push origin main
.\deploy\sync-skills.ps1

# Machine A pulls the merge
git pull origin main
.\deploy\sync-skills.ps1
```

### Handling conflicts

When both machines edit the **same file**:

```text
<<<<<<< HEAD
...machine B's version...
=======
...machine A's version...
>>>>>>> origin/main
```

Edit the file, keep the correct content (or merge both), delete the markers:

```powershell
git add <file>
git rebase --continue   # or just git commit after merge
git push origin main
```

### When 90% of the time there is NO conflict

Two machines editing different skill files → Git merges automatically. No manual intervention needed.

### Avoiding accidental `git pull` failures

If Machine B has uncommitted local changes:

```powershell
git stash
git pull --rebase origin main
git stash pop
# resolve conflicts if any
```

Or commit first (even as WIP), then rebase.

## Pitfalls

### 1. `sync-skills.ps1` not found → machine hasn't pulled latest commit

Error:
```
The term '.\deploy\sync-skills.ps1' is not recognized
```

Fix: `git pull` first, then run the script. The script lives in the repo's `deploy/` folder and must be present locally.

### 2. Stale snapshot in `deploy/hermes-home/skills/`

If you still have a snapshot there, Git may re-add it. The `.gitignore` line `deploy/hermes-home/skills/` must be present. If snapshot was previously committed, delete it:

```powershell
git rm -r --cached deploy/hermes-home/skills
git commit -m "remove deploy skills snapshot"
```

### 3. `robocopy /MIR` would DELETE machine-local skills

Never use `/MIR` or `/PURGE` — they delete files in destination not present in source, which wipes per-machine skills. Always use `/E` only.

### 4. `robocopy` exit codes

`robocopy` returns 0–7 for various "success with files copied/no files copied" states. Only exit > 7 is a real error. The script checks `if ($RobocopyExitCode -gt 7)` and throws.

### 5. Credentials in repo

`.gitignore` normally blocks `.env` and `auth.json`. To commit them to a private repo, add explicit negations:

```gitignore
!deploy/hermes-home/.env
!deploy/hermes-home/auth.json
!deploy/codex-home/.cockpit_codex_auth.json
!deploy/codex-home/.codex-global-state.json
```

### 6. Machine-local skills

Keep per-machine skills in `%LOCALAPPDATA%\hermes\skills\` outside of `skills/` in repo. `sync-skills.ps1` uses `robocopy /E` which does not delete them.

Examples of machine-local skills:
- Skills referencing machine-specific paths
- Skills requiring hardware only on one machine
- Experimental/draft skills

### 7. Setup on machine without Python

`setup-admin.ps1` requires Python 3.11+ (`py -3.11`). Install via:

```powershell
winget install --id Python.Python.3.11 -e --source winget
```

### 8. Credential bootstrap is "copy only if absent"

`Copy-BootstrapFile` in `setup-admin.ps1` only copies when the destination file does not exist. If you want to force-refresh credentials, delete the destination file first.

## Two-agent review loop (for Hermes development)

When modifying Hermes itself (not just skills), use this loop:

1. **Codex** → plan (what to change, file paths, migration steps)
2. **Codex** → code (implement within scope, do not touch unrelated dirty files)
3. **Claude** → audit (verify correctness, edge cases, acceptance criteria)

Prompt patterns:
- Codex plan: `"Create an implementation plan only; do not edit files or commit..."`
- Codex code: `"Implement the approved plan. You may edit ONLY: ... Do not touch unrelated dirty files..."`
- Claude audit: `"Audit the implementation. Do not edit files or commit. Check correctness against requirements..."`

## Verification checklist

After setup or sync:

```powershell
hermes --version
hermes doctor
hermes skills list
hermes tools list
claude --version
codex --version
```

## Related files

- `deploy/setup-admin.ps1` — first-time bootstrap
- `deploy/sync-skills.ps1` — recurring skill sync
- `deploy/README.md` — deployment docs
- `tests/test_deployment_scripts.py` — verification tests for script semantics