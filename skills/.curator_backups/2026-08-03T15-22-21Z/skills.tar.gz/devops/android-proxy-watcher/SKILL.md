---
name: android-proxy-watcher
description: Run and debug Android proxy/VPN reconnect watchers with central locks, scheduler supervision, and proof-based verification.
---

# Android Proxy Watcher

Use this skill when a local Android fleet watcher should restore proxy/VPN after boot, reconnect, or ADB recovery; or when a scheduler/task says it is running but a target remains without VPN.

## Required evidence chain

Do not call a watcher healthy merely because a wrapper exits successfully or its process exists. Verify four layers independently:

1. **Scheduler task:** query task state, enabled flag, last result, and task action.
2. **Watcher process tree:** confirm tray/supervisor → launcher → watcher worker command, start times, and expected mapping/runtime arguments.
3. **Target event:** inspect a current-run, target-specific reconnect/startup artifact or result. Confirm the artifact machine and serial match the requested target.
4. **Device proof:** verify the intended VPN interface is UP and Android connectivity exposes a VPN-connected state. Wi-Fi `CONNECTED` / `NOT_VPN` is not success.

A `DONE: result=...` line only identifies an artifact to read; it does not mean the target succeeded.

## Device lock protocol

- Acquire the central machine+serial lock before a manual proxy assignment or reboot.
- Never delete another owner's lock. For a stale `recovery`/`handoff` lock, verify the same-host PID is dead, then use the lock implementation's explicit takeover mechanism.
- A proxy recovery reboot may need to acquire its lock without requiring an already-ready VPN. Use the shared lock API's documented proxy-readiness bypass only for the bounded recovery action; preserve normal readiness gating for normal device work.
- Release the reboot lease only after boot-complete and wake/swipe preparation. The watcher must then acquire its own per-event lease.

## Watcher event behavior

For each startup/reconnect event:

1. Refresh target mapping safely and ensure machine/serial have not changed.
2. Acquire a per-event lock; do not hold device locks while idle.
3. Permit explicit safe takeover for a dead eligible retained lock, relying on the central lock policy to reject live owners.
4. Use a bounded wait for a live owner. On expiry, append `SKIPPED_DEVICE_LOCKED`, do not call proxy/VPN assignment, release/avoid retaining the lease, and return to the reconnect loop.
5. Capture sanitized ready and verified artifacts around proxy assignment.
6. Mark success only after actual VPN proof; otherwise classify the failure, run one evidence-based handler, and preserve the final artifact.

## Debugging a missed reconnect

When the watcher is live but a rebooted target has no VPN:

1. Check whether the current watcher runtime contains a new artifact for the exact target after its boot timestamp.
2. If there is no target artifact, investigate reconnect detection / worker scheduling rather than ViChanger or VPN assignment.
3. If there is a ready artifact but no verified artifact, inspect proxy assignment and VPN proof path.
4. If there is `SKIPPED_DEVICE_LOCKED`, inspect lock owner/state and bounded timeout behavior. Do not retry assignment over an active owner.
5. Keep results for concurrent machines separate; a newer artifact for another machine is not evidence for the target.

## Reconnect debugging reference

For the target-specific evidence ladder, circular readiness-gate prevention, retained-lock policy alignment, resilient per-worker telemetry, and the user preference not to start unrelated TikTok schedules, see `references/watcher-reconnect-debugging.md`.

## Verification checklist

- Targeted watcher lock/event regression tests pass.
- Full consumer watcher suite and compile check pass.
- `git diff --check` passes.
- Restart only the watcher/tray component necessary to load code; do not use a menu/action that starts unrelated account/feed schedulers.
- After a real target reboot, record fresh target-specific watcher evidence plus final `tun0` and Android VPN connectivity proof.

## Pitfalls

- A retained lock from a dead recovery owner can block a watcher startup event indefinitely if the watcher neither requests takeover nor bounds lock wait.
- Killing a watcher child may not make a tray supervisor respawn it immediately; restart the dedicated tray/task process when a new watcher process is needed. Verify new process creation time.
- A watcher can create artifacts for many machines at startup. Always compare artifact timestamps and machine/serial before drawing conclusions.
- Do not expose proxy values, workbook rows, credentials, or raw sensitive logs in reports.
