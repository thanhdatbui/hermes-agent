---
name: tiktok-feed-session
description: Chạy TikTok feed session (nuôi acc) — test, debug, và chạy hàng loạt feed-session-smoke / multi-machine-feed-session với like, follow, swipe.
---

# TikTok Feed Session

Kỹ năng này bao gồm cách chạy, test, và debug các phiên TikTok feed session trong dự án `tiktok-luot nuoi acc`. Áp dụng cho cả `feed-session-smoke` (đơn lẻ) và `multi-machine-feed-session` (hàng loạt).

## Triggers

- User yêu cầu chạy test feed session, nuôi acc TikTok
- User hỏi về like/follow trong script
- Cần chạy thử nghiệm trên vài máy với tỉ lệ like/follow cao
- Gặp lỗi khi chạy feed session

## Các chế độ chạy

### 1. feed-session-smoke (máy đơn)

```bash
python python_runner/run_tiktok.py \
  --mode feed-session-smoke \
  --device "<serial>" \
  --account "<tiktok_username>" \
  --machine <N> \
  --max-swipes <1-15> \
  --allow-navigation-only \
  --allow-feed-swipe \
  --allow-benign-popup-dismiss \
  --allow-like \
  --like-rate '{"for_you":100,"following":100}' \
  --follow-rate '{"for_you":100,"following":100}' \
  --config python_runner/config.example.yaml
```

### 2. multi-machine-feed-session (hàng loạt)

```bash
python python_runner/run_tiktok.py \
  --mode multi-machine-feed-session \
  --machines "1,2,3" \
  --account-workbook "<path_to_safe_xlsx>" \
  --account-row-index <N> \
  --max-workers <N> \
  --recovery-test-swipes 3 \
  --allow-navigation-only \
  --allow-feed-swipe \
  --allow-benign-popup-dismiss \
  --prepare-tiktok \
  --allow-like \
  --like-rate '{"for_you":100,"following":100}' \
  --follow-rate '{"for_you":100,"following":100}' \
  --config python_runner/config.example.yaml
```

## Cờ quan trọng

| Cờ | Ý nghĩa |
|----|---------|
| `--allow-navigation-only` | BẮT BUỘC cho feed-session-smoke |
| `--allow-feed-swipe` | BẮT BUỘC cho phép swipe feed |
| `--allow-benign-popup-dismiss` | CẦN để tự động tắt popup "Add phone" và các popup vô hại |
| `--allow-like` | Cho phép thả tim (tự động bật trong feed-session-smoke) |
| `--prepare-tiktok` | Force-stop + launch TikTok (CHỈ hỗ trợ multi-machine-feed-session, KHÔNG hỗ trợ feed-session-smoke) |
| `--recovery-test-swipes N` | Giới hạn swipe cho test (1-3), chỉ trong multi-machine-feed-session |

## Like & Follow — Cách hoạt động

- **Like:** Tự động bật trong `feed-session-smoke` (code tự set `allow_like = True`). Dùng `content_desc="Thích"` để tìm nút qua UI XML, tap ngẫu nhiên theo tỉ lệ.
- **Follow:** Tự động chạy nếu `follow_rate_percent > 0`. Dùng `content_desc="Follow"` để tìm nút.
- Tỉ lệ mặc định: For You (like 12%, follow 5%), Following (like 7%, follow 0%), Friends (like 2%, follow 0%).
- **Follow Following/Friends = 0% là chủ đích** (commit e7f4f9f): tab Following/Friends toàn người đã follow rồi → không có nút follow để bấm. Chỉ For You mới follow (5%). User có workflow follow chéo riêng giữa các acc, nên feed session không cần follow nhiều.
- Để test với tỉ lệ 100%: `--like-rate '{"for_you":100,"following":100}' --follow-rate '{"for_you":100,"following":100}'`

## Pitfalls & Cách xử lý

### 0. Like/Follow im lặng thất bại — ROOT CAUSE: selector không khớp UI thực tế (ĐÃ FIX)

**Triệu chứng:** Chạy với `--allow-like` và `like_rate=100`, UI dump thành công, nhưng log KHÔNG có dòng `like_video` hay `follow_video` nào cả.

**Nguyên nhân & Fix (đã xác minh + commit `0bba9f8`):**

1. **Nút Like:** `find_by_fields(root, resource_id="", content_desc="Thích")` — `resource_id=""` chỉ match element có resource-id rỗng. Nhưng nút like thực tế có `resource-id="com.ss.android.ugc.trill:id/fan"`.
   - **Fix:** Đổi `resource_id=""` → `resource_id=None`

2. **Nút Follow:** `find_by_fields(root, resource_id="", content_desc="Follow")` — exact match `"Follow"` không khớp `"Follow Deltaforce short"`.
   - **Fix:** Duyệt `iter_elements(root)`, tìm element có `content_desc.startswith("Follow ") or content_desc == "Follow"`

3. **False positive `already_following`:** `find_by_fields(root, resource_id=None, text="Đã follow")` match nhầm top tab "Đã follow" (Following tab) → luôn return False trước khi kịp tìm nút follow.
   - **Fix:** Chỉ check `element.clickable` khi tìm text tiếng Việt, và giới hạn match là `desc.startswith("Following") or desc == "Đang follow" or txt == "Đang follow" or txt == "Following"`

**Chi tiết UI XML:** Xem `references/like-follow-selector-evidence.md`

### 1. UI dump lỗi triền miên trên SM-G930F (`uiautomator_idle_state_error`)
**Triệu chứng:** Log liên tục có `dump_ui_xml | uiautomator_idle_state_error`, status `degraded`.
**Hậu quả:** Like/follow bị skip vì không đọc được UI XML để tìm nút. Swipe vẫn chạy nhưng like/follow luôn thất bại.
**Xử lý:** Đây là vấn đề phần cứng/môi trường trên dòng SM-G930F cũ. Chưa có fix tự động. Cần theo dõi tỉ lệ success của like/follow qua nhiều lần chạy.

### 2. Device lock cũ / stale (gồm cả `machine_N.lock.json` và `serial_XXXX.lock.json`)
**Triệu chứng:** `[device-lock] SKIP device ... device lock active`
**Xử lý:**
```bash
# Kiểm tra PID còn sống không
tasklist | grep <pid>
# Nếu PID đã chết, xóa tất cả lock của PID đó:
for f in "C:\Users\Kibe\.codex\device-locks"/*.lock.json; do
  if grep -q '"pid": <pid>' "$f" 2>/dev/null; then rm "$f"; fi
done
```
Lưu ý: Có cả lock `machine_N.lock.json` VÀ `serial_XXXX.lock.json` — phải xóa cả hai.

### 3. App ViChanger chiếm foreground
**Triệu chứng:** Log ghi `focused_package: vn.vichanger.app`, `TikTok focus lost`
**Xử lý:** Dùng ADB force-stop ViChanger + launch TikTok:
```bash
ADB="C:\Program Files (x86)\xiaowei\tools\adb.exe"
"$ADB" -s <serial> shell "am force-stop vn.vichanger.app && am force-stop com.ss.android.ugc.trill && input keyevent KEYCODE_HOME && sleep 1 && monkey -p com.ss.android.ugc.trill -c android.intent.category.LAUNCHER 1"
```

### 4. Popup "Add phone" chặn màn hình
**Triệu chứng:** `detected: manual-needed:add-phone`, `dismiss requires explicit flag`
**Xử lý:** Thêm `--allow-benign-popup-dismiss` vào command.

### 5. `--prepare-tiktok` không hoạt động với feed-session-smoke
**Triệu chứng:** `CONFIG_ERROR: --prepare-tiktok is only supported for run-plan-smoke, multi-machine-smoke, and multi-machine-feed-session`
**Xử lý:** Dùng ADB thủ công (xem mục 3) hoặc chuyển sang `multi-machine-feed-session`.

### 6. `automation_core` thiếu module
**Triệu chứng:** `ModuleNotFoundError: No module named 'automation_core.xxx'`
**Xử lý:** Cài lại wheel mới nhất:
```bash
pip install --force-reinstall --no-deps "D:\Taadaa\automation-core\dist\automation_core-0.2.11-py3-none-any.whl"
```

## Test nhanh like/follow (100%, 5 video, 2 máy)

```bash
# Chuẩn bị: force-stop ViChanger + launch TikTok
ADB="C:\Program Files (x86)\xiaowei\tools\adb.exe"
for SERIAL in 9885b64957334f5a46 9885e6303951513337; do
  "$ADB" -s $SERIAL shell "am force-stop vn.vichanger.app && am force-stop com.ss.android.ugc.trill && input keyevent KEYCODE_HOME && sleep 1 && monkey -p com.ss.android.ugc.trill -c android.intent.category.LAUNCHER 1"
done

# Dọn lock cũ
for f in "C:\Users\Kibe\.codex\device-locks"/*.lock.json; do
  pid=$(python -c "import json; print(json.load(open('$f')).get('pid',''))" 2>/dev/null)
  if [ -n "$pid" ] && ! tasklist | grep -q "$pid"; then rm "$f"; fi
done

# Chạy test
python python_runner/run_tiktok.py --mode feed-session-smoke \
  --device "9885b64957334f5a46" --account "lipsellczaw" --machine 1 \
  --max-swipes 5 --allow-navigation-only --allow-feed-swipe \
  --allow-benign-popup-dismiss --allow-like \
  --like-rate '{"for_you":100,"following":100}' \
  --follow-rate '{"for_you":100,"following":100}' \
  --config python_runner/config.example.yaml
```

## Kiểm tra kết quả

Xem log like/follow:
```bash
grep -i "like_video\|follow_video" <artifact_dir>/log.jsonl
```

Xác minh selector có khớp UI thực tế không (quan trọng khi like/follow im lặng thất bại):
```bash
XML="<artifact_dir>/artifacts/<serial>/<account>/feed-session-smoke/swipe_N_after/attempt_1/ui.xml"
grep -o 'content-desc="[^"]*"' "$XML" | sort -u
grep -o '<node[^>]*content-desc="Thích"[^>]*/>' "$XML"
grep -o 'content-desc="Follow[^"]*"' "$XML"
```
Chi tiết: xem `references/like-follow-selector-evidence.md`

## Tài liệu tham khảo

- `references/workbook-structure.md` — Cấu trúc workbook `taikhoan_run_safe.xlsx`
- `references/like-follow-selector-evidence.md` — Bằng chứng UI XML thực tế và cơ chế exact match của `find_by_fields`
