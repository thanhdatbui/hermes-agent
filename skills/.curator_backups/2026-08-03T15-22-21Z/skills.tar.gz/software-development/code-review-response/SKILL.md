---
name: code-review-response
description: Respond to code review findings (especially critical/P0 issues). Implement fixes, verify with tests, and ensure no regressions.
triggers:
  - code review feedback
  - P0 critical issues
  - review findings
  - Claude review
  - fixing review comments
  - fix re-review
  - verify fixes applied
  - re-review findings
  - verify criteria
  - verification review
  - check requirements
  - compliance review
---

# Code Review Response

Systematic approach to fixing critical issues identified in code review.

## When to Use

- Received code review with P0/critical issues
- Need to implement reviewer-suggested fixes
- Must verify fixes don't introduce regressions

## Severity-Based Triage

Review findings come in severity tiers. Handle in strict priority order:

| Tier | Label | Action |
|------|-------|--------|
| 🔴 Critical | Blocking, security, data loss, TODO stubs | Implement immediately |
| 🟠 High | Correctness, major API misuse, private API access | Fix after critical, before medium |
| 🟡 Medium | Style, dead code, minor patterns, doc/import hygiene | Auto-fix in batch after everything else |

For each tier, read all findings first, then batch independent fixes across files.

## Workflow

### 1. Read All Findings First
Before touching code, read ALL review findings completely. Understand:
- What files are affected
- What the issues are (type mismatches, race conditions, missing logic, TODO stubs, private API access, styling)
- Severity and dependencies between fixes
- Whether any findings affect the same file (plan conflicts)

### 1b. Read Each Affected File Completely
- Use `read_file` to get full file contents (not just error-line snippets)
- If `read_file` truncates (shows offset/limit pagination), continue with `offset=` until you have the complete file
- **Only then** start editing — patching a partial view risks corrupting surrounding lines
- Understand the full method/class/module before making targeted changes
- Pay attention to the project's language convention (code may mix Vietnamese, English, Chinese — match existing style)

### 2. Batch Independent Changes Across Files
- Group fixes by file — all fixes to the same file can be done in sequence
- **Independent fixes across different files** can be patched in parallel (one turn)
- Dependent fixes (where fix A changes a signature that fix B must match) MUST be serialized
- After each batch, verify: `python -c "from project.module import Symbol"` (or `python -c "import package"`)

### 3. Fix Issues Systematically
For each issue:
- Read the affected file completely
- Understand the context and surrounding code
- Implement the minimal fix that addresses the specific issue
- Match existing code style and conventions
- Do NOT refactor unrelated code

### 4. Verify Each Fix
After fixing each issue (or group of related issues):
- Re-read the changed files if another agent/external writer may have touched them since your last read. Never patch from stale/partial content.
- Run the repository's canonical suite, using the project's import path explicitly when needed (for example `PYTHONPATH=scripts python -m pytest tests/`).
- If the suite is unavailable, stale, or does not cover the finding, create focused ad-hoc verification with an OS-safe temporary path. On Windows, use `tempfile`/`TemporaryDirectory` and a `hermes-verify-` prefix under the user's Temp directory; do not hand-build `/tmp` paths. Run it, assert the exact behavior, and remove it when possible.
- Distinguish evidence labels precisely: `pytest: N passed` is suite evidence; `ad-hoc verification passed` is targeted evidence only. Never call a stale or unrelated prior run "fresh passing verification".
- Verify both: (a) existing tests still pass, (b) each changed behavior works, without live device/upload actions when the user forbids them.

### 5. Report Results Clearly
Summarize:
- What was fixed (one line per issue)
- Files modified
- Verification evidence (test counts, specific behavioral tests)
- Any issues encountered

## Common P0 Issues and Fixes

### Type Mismatches
**Problem**: Function expects type A but receives type B
**Fix**: Update type annotations to accept the actual usage
```python
# Before: text: Optional[str]
# After: text: Union[str, List[str], None]
```

### Missing Retry Logic
**Problem**: Comments say "TODO: implement retry" but no retry exists
**Fix**: Implement retry wrapper with checkpoint/resume
```python
def execute(self, context):
    for attempt in range(self.retry_limit):
        if attempt > 0:
            self._load_checkpoint()  # Resume from last state
        result = self._run_states()
        if result:
            return True
        # Reset for next attempt
    return False
```

### Race Conditions
**Problem**: Check-then-write pattern allows race
**Fix**: Use atomic file operations
```python
# Non-atomic (BAD):
if not file.exists():
    write_file()

# Atomic (GOOD):
fd = os.open(file, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
with os.fdopen(fd, 'w') as f:
    f.write(data)
```

### TODO Stubs in Critical Path
**Problem**: Critical workflow handlers are empty TODO stubs (`return True` with no real logic)
**Fix**: Implement real automation matching the surrounding pattern:
```python
# Before:
def handle_video_pick(self) -> bool:
    logger.info("Will implement later")
    return True

# After:
def handle_video_pick(self) -> bool:
    """Pick video from gallery — multi-strategy fallback."""
    # 1. Try resource-id selectors first
    # 2. Fall back to text-based matching
    # 3. Fall back to coordinate tap
    # Each step dumps UI and searches for expected element
    for strategy in [selector_tap, text_tap, coordinate_tap]:
        if strategy():
            return True
    return False
```

### Multi-Strategy Fallback Chains (Brittle Systems)
**Problem**: A single approach (e.g. `adb pull -`) will fail on some device/OS versions
**Fix**: Implement a fallback chain — try each strategy, collect errors, raise with all messages:
```python
errors = []
# Strategy 1: primary approach
result = method_a()
if result.ok:
    return result
errors.append(f"method_a failed: {result.stderr}")

# Strategy 2: fallback
result = method_b()
if result.ok:
    return result
errors.append(f"method_b failed: {result.stderr}")

raise AllFailedError(f"All strategies failed: {'; '.join(errors)}")
```

### Method-Body Imports (Code Smell)
**Problem**: `import X` inside a method body (lazy-import that doesn't save meaningful startup time)
**Fix**: Move to top-level imports:
```python
# Before:
class Foo:
    def bar(self):
        import openpyxl  # ← lazy import, no justification
        wb = openpyxl.load_workbook(...)

# After:
import openpyxl  # top-level

class Foo:
    def bar(self):
        wb = openpyxl.load_workbook(...)
```
**Exceptions**: Keep lazy imports for heavyweight GUI/ML libraries (torch, tkinter) or circular-dependency breakers — comment the reason.

### Dead Code
**Problem**: Defined dict/list/constant that is never referenced anywhere
**Fix**: Remove it. If it documents a schema, move to a docstring or a `references/` file.
```python
# Before (never used):
COLUMN_MAP = {"A": "Name", "B": "Age", ...}

# After: removed. The xlsx reader parses headers dynamically.
```

### Private Attribute Access
**Problem**: External code reads `obj._private_attr` (e.g. `config._data.get(...)`)
**Fix**: Add a public property to the class, update all call sites:
```python
# In config.py:
@property
def video_source_root(self) -> Path:
    raw = self._data.get("video_source_root")
    return Path(raw) if raw else self.media_source_root

# In consumer (before):
path = config._data.get("video_source_root", fallback)
# After:
path = config.video_source_root
```

### Silent Error Swallowing
**Problem**: `except Exception: ... return True` — handler claims success even when it crashed
**Fix**: Log the error, detect known edge cases from state, and return False to trigger retry:
```python
try:
    risky_operation()
except Exception as e:
    logger.warning(f"Operation failed: {e}")
    # Check UI for known edge cases
    xml = dump_ui()
    if "captcha" in xml.lower():
        context.is_captcha = True
    return False  # Let state machine handle retry/escalation
```

### Computed-But-Never-Used Variables (Dead Code Variant)
**Problem**: A variable is assigned (e.g. `escaped = caption.replace(...)`) but the next line uses the original value (`caption`) instead of the computed one. The variable is dead.

**Fix**: Remove the unused assignment, or if the intent was to use the escaped version, fix the call site to reference the computed variable:
```python
# Before (dead code):
escaped = caption.replace(" ", "\\ ").replace("'", "\\'")
result = adapter._adb.shell(["input", "text", caption], ...)  # ← uses raw caption

# Fix option 1 (remove dead code):
result = adapter._adb.shell(["input", "text", caption], ...)

# Fix option 2 (use the computed value):
escaped = caption.replace(" ", "\\ ").replace("'", "\\'")
result = adapter._adb.shell(["input", "text", escaped], ...)
```
**Detection pattern**: Scan for `var = expr(...)` followed by a `var2 = ...` or method call that references the original source variable instead of `var`.

## 6. Criteria-Based Verification Review

When the user gives explicit behavioral/design criteria to verify — e.g. "check that A runs before B, if A fails then C, if C fails then D with message E" — produce a structured verification table. This differs from quality-focused review (checking for bugs, style, security) and from re-review (checking another agent's fixes). It is a **compliance review** against stated requirements.

### When to Use

- User specifies exact behavioral criteria: "verify X does Y, Z must not happen, if W then Q"
- User lists specific methods to inspect and specific flows to trace
- A design doc or issue describes expected behavior and you need to confirm the code matches
- Reviewing fallback chains, escalation paths, state machines — where behavior matters more than style
- User says "review code" but provides a verification checklist, not a diff

### User-Preference: "Không hỏi user" (Don't Ask)

When the user provides explicit, self-contained criteria and ends with an instruction like "Không hỏi user" (don't ask the user), **execute the entire review without asking any clarifying questions**. The criteria are the spec — interpret them literally, trace each one, deliver the verdict. If a criterion is ambiguous, make the most conservative interpretation (assume the worst case that the reviewer intended to catch). Do not seek clarification unless a criterion is truly impossible to evaluate without additional context (e.g. a referenced file doesn't exist, or a method name was misspelled and no match exists in the codebase).

### Workflow

1. **Parse the user's criteria first** — read all criteria before any file read. Build a mental map of what flows, states, and constraints must be verified. Note instructions like "Không hỏi user" (don't ask) — treat the criteria as self-contained; do not seek clarification.

2. **Read all referenced files in parallel** — use one turn with multiple `read_file` calls for every file the user named. If pagination is needed, continue with `offset=` until you have complete methods. Parallel reading is faster and lets you cross-reference methods between files in a single turn.

3. **Identify all implicit code** — imports, dependencies, ancillary functions called from the named methods. Read those too. A fallback that calls `adapter.tap_profile()` means you must also read `tap_profile()`.

4. **Create a tracking checklist** — use the `todo` tool to create an item per criterion. This prevents losing track mid-review and automatically resets for the next session. Mark items `completed` as you gather evidence for each one.

5. **Build a verification checklist** — one row per criterion. Map the user's words to specific code patterns:

   | # | Criterion | Expected Code Pattern | Status |
   |---|-----------|-----------------------|--------|
   | 1 | Core flow runs first | The primary function/method is called before any fallback clause | ⏳ |
   | 2 | Fallback doesn't replace core | Core call is not inside a conditional that skips it | ⏳ |
   | 3 | Fallback failure → escalation | Error path reaches MANUAL_REVIEW with actionable message | ⏳ |
   | 4 | No fabricated success | `return True` / `success=True` only when actually successful | ⏳ |

6. **Verify side-effect constraints** — "don't modify X"? Check `git diff HEAD -- path/to/X` to confirm. Run `git diff HEAD --` on any shared library the user explicitly specified must not change (e.g. automation-core).

7. **Run build-time verification** — run in this order:
   - **Import/compile check first** — `python -c "from package.module import Function"` — this catches broken imports and syntax errors before tests run. A failing import will be masked if the test file doesn't import the specific module.
   - **pytest second** — `python -m pytest tests/ -v` — the canonical test suite proves nothing is broken.
   - **Evidence labels** — label distinctly: `import: OK` vs `pytest: 92/92 passed`. A passing import doesn't mean tests pass, and passing tests don't mean the module can be imported.

8. **Produce structured verdict** — verification table + build evidence + decision.

### Verdict Format

```markdown
## Verification Review: [topic]

### Checklist

| # | Criterion | Expected | Actual | Status |
|---|-----------|----------|--------|--------|
| 1 | Core flow runs before fallback | `open_profile_root()` called first | Line 714: first action in retry loop | ✅ PASS |
| 2 | Fallback doesn't replace core | Core call unconditional | No conditional gate before line 714 | ✅ PASS |
| 3 | Fallback fail → escalation | MANUAL_REVIEW with instructions | Lines 740-757: `is_ui_unavailable=True`, detailed message | ✅ PASS |
| 4 | No fabricated success | success=True only on real success | Line 737: `profile_success=True` after verified fallback | ✅ PASS |
| 5 | No automation-core changes | No diffs in shared library | git diff shows 0 changes in automation-core/ | ✅ PASS |

### Build Verification

| Check | Result |
|-------|--------|
| pytest | 92/92 passed |
| Compile | OK (py_compile) |
| Import | OK |

### Minor Findings

- **Finding 1** — non-blocking, suggestion only
- **Finding 2** — minor issue, not blocking

### Decision

**✅ APPROVED** — All criteria met. Ready for merge.
```

### Common Criteria Categories

**Flow ordering:**
- Does step A execute before step B?
- Is the primary strategy attempted before any fallback?
- Are retries exhausted before escalation?

**Error handling:**
- Does each error path produce a unique, actionable message?
- Are transient errors (retryable) distinguished from permanent failures?
- Are edge-case flags (`is_ui_unavailable`, `is_captcha`, etc.) set appropriately?

**Side effects:**
- Are shared/global modules modified (if the constraint says no)?
- Are new dependencies introduced unnecessarily?

**Truthfulness:**
- Does `return True` / `success = True` only appear on actual success, not after swallowing an error?
- Does the log message match what actually happened?
- Is a checkpoint saved with correct data before returning a terminal state?

### Pitfalls

- **Don't trust docstrings alone** — verify by reading the actual code path, line by line
- **Don't skip reading fallback/ancillary methods** — a fallback that calls another public method means you must read that method too
- **Don't forget build verification** — "looks right" is not enough; run tests and imports
- **Criteria without evidence is speculation** — every PASS/FAIL must cite line numbers or diff output
- **Side-effect checks require git diff** — "X was not modified" is only proven by `git diff HEAD --path-to-X`
- **Name your source for each criterion** — when the criterion came from user words, quote them; when it came from a doc or issue, cite it. This prevents scope creep and makes the verdict auditable.
- **Domain-specific patterns** — ADB/Android automation code has unique patterns (force-stop + monkey launch, uiautomator dump fallback chains, feed-polling by UI indicators, bottom-nav resolution-aware taps, device reboot recovery). See `references/adb-automation-review-patterns.md` for the full review checklist for these patterns.
- **Don't skip the dry-run trace** — verify that `dry_run` short-circuits before device-dependent operations (feed polling, UI dump, tap). A mock XML that happens to contain a feed indicator can mask a missing early-return.
- **Import check before pytest** — run `python -c "from package.module import Symbol"` separately before `pytest`. A failing import may be invisible in test output if the test file doesn't import the specific module. Label evidence distinctly: `import: OK` vs `pytest: N/N passed`. These are separate guarantees.
---

## 7. Re-Review: Verifying Fixes Applied by Another Contributor

When you did an initial code review (finding issues) and another agent or contributor applied the fixes (Codex, Claude Code, OpenCode, a human), you need to **re-review** — not just re-test — to confirm the fixes actually landed correctly. This is distinct from both initial review and self-verification.

See `references/fix-re-review-format.md` for the structured verdict output template.

### When to Use

- User says "re-review", "verify the fixes", "check if Codex fixed it", "recheck the changes"
- Fixes were applied by a different agent or a human while you context-switched
- You have a known finding list and need to confirm each one was resolved
- A previous code review identified issues, and the implementation was delegated

### Workflow

#### 1. Read All Affected Files in Parallel

Use one turn with multiple `read_file` calls. Every file that was supposedly fixed should be loaded in the same batch. Do not read files one-by-one — use the parallelism.

```text
# One turn, six reads:
read_file(state_machine.py)
read_file(adapter.py)
read_file(config.py)
read_file(account_source.py)
read_file(report.py)
read_file(requirements.txt)
```

#### 2. Build a Finding Checklist

Map each finding from the original review to what you expect to see in the code. Tracking by ID makes the verdict report scannable:

| ID | Finding | Expected Fix | Status |
|----|---------|-------------|--------|
| C1 | VIDEO_PICK stub → real UI automation | Multi-strategy fallback with `_find_ui_element`, `_wait_for_element`, `_tap_if_found` | ⏳ |
| C2 | adb pull failure | Fallback chain (exec-out cat → temp pull → content provider) | ⏳ |
| H2 | Private `config._data` access | Public `video_source_root` property | ⏳ |

#### 3. Trace Each Finding Through the Code

For each finding, search the relevant file(s) for the expected change. Don't just check it exists — check it's correct:

- **Does the fix address the root cause?** — Not just the symptom
- **Is the fix robust?** — Multiple fallback strategies? Error handling? Timeouts?
- **Are there untouched copies of the old pattern?** — One call site fixed, another identical one left alone elsewhere in the same file
- **Does the fix introduce new issues?** — Dead code (assigned-but-unused variables), wrong API method names, stale comments, regression in style

#### 4. Run Verification

```bash
# 1. Verify all modules import cleanly
python -c "from project.module import ClassA, ClassB"
python -c "import project"

# 2. Run the test suite
python -m pytest tests/ -v

# 3. Static analysis if tooling is available
which ruff && ruff check .
```

Every import error or test failure must be traced back to a specific fix. If a fix introduced a regression, flag it — do not wave it away as "pre-existing".

#### 5. Report Per-Finding Verdict

Use `references/fix-re-review-format.md` for the structured template. Example:

| Finding | Verdict | Notes |
|---------|---------|-------|
| 🔴 C1 | ✅ **APPROVED** | Real UI automation with multi-strategy fallback, timeouts, and element verification |
| 🟠 H2 | ✅ **FIXED** | `video_source_root` property added with fallback to `media_source_root` |
| 🟡 M3 | ✅ **FIXED** | Returns `False` on failure, detects CAPTCHA/login, sets edge case flags |
| — | ⚠️ **MINOR** | Variable `escaped` assigned but never used (state_machine.py:986) |

### Re-Review Decision Table

| All APPROVED? | MINOR items? | Any REJECT? | Action |
|:---:|:---:|:---:|--------|
| ✅ Yes | No | No | **APPROVED** — all fixes good, merge ready |
| ✅ Yes | Yes | No | **APPROVED (MINOR_FIXES)** — fix minor items, then merge |
| No | — | No | **PARTIAL_APPROVAL** — approved items mergeable, rejected need a new fix cycle |
| No | — | Yes | **REJECT** — at least one fix is wrong; needs full redo |

### Pitfalls (Re-Review Specific)

- **Don't re-read the review findings as if they're new code** — the findings are your checklist. You're not reviewing from scratch; you're verifying specific points. Re-reading everything costs time and risks re-discovering what was already found
- **Batch reads, serialize writes** — read all files in one turn. Only write if the re-review demands additional fixes, and do that in a separate turn after the verdict
- **API method mismatch** — verify method names used in fixes actually exist on the target class. A fix that calls `adb.run()` when the API only has `adb.shell()` is silently broken
- **Dead code detection (assigned-but-unused)** — the fixer may have left scaffolding: a variable computed but never passed to the next call. Scan for this explicitly
- **Regressions** — a test that passed before the fix and fails after is the fixer's bug, not "pre-existing". Report it
- **Look for untouched copies of old pattern** — the fixer may have targeted one call site but missed an identical one two methods away in the same file. This is the most common re-review fail

## Pitfalls

- **Don't over-engineer**: Fix exactly what review found, don't refactor unrelated code
- **Verify before claiming done**: Always run tests after fixes
- **Ad-hoc verification is valid**: If no test suite exists, create targeted verification script
- **Clean up temp files**: Remove verification scripts after running
- **Match code style**: Use same indentation, naming, patterns as surrounding code
- **Read file completely first**: Don't just read the lines mentioned in review — use offset pagination if read_file truncates
- **Patching truncated files is dangerous**: The `_warning` in patch output saying "was last read with offset/limit" means you only saw part of the file — re-read the complete file before further edits
- **Verify imports after each batch**: Run `python -c "from module import Class"` between edit batches — failed imports catch a bad edit before you compound it with more edits
- **Removing old_string content that was also needed**: When consolidating code (e.g. removing lazy imports), double-check you didn't delete a variable assignment alongside the import — the pattern `from X import Y; y = fn()` needs both the import AND the assignment to stay

## Verification Strategy

### Option 1: Existing Test Suite (preferred)
```bash
pytest tests/ -v
```

### Option 2: Ad-Hoc Verification (when needed)
```python
# Test specific behavior
from module import Class
obj = Class()
assert obj.method() == expected_value

# Test edge cases
try:
    obj.failing_case()
except ExpectedException:
    pass
```

### Report Format
```
✅ Fixed P0 #1: <description>
✅ Fixed P0 #2: <description>
...
✅ pytest: 11/11 passed
✅ Ad-hoc verification: All fixes verified
```

## Example Session

```
User: Fix 4 P0 critical issues that Claude review found. After fix, run pytest to verify.

Agent workflow:
1. Read all 4 P0 issues from review
2. Read affected files (ui_profile.py, state_machine.py, locks.py)
3. Fix each issue:
   - P0 #1: Type mismatch → update Union type
   - P0 #2: Missing retry → implement 2-tier retry with checkpoint
   - P0 #3: Race condition → use atomic file creation
   - P0 #4: Commented code → uncomment
4. Run pytest: 11/11 passed
5. Create ad-hoc verification for each specific fix
6. Report: All 4 P0s fixed, verified with pytest + ad-hoc tests
```
