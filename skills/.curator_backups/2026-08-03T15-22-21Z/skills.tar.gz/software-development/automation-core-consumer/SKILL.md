---
name: automation-core-consumer
description: "Build and fix consumers of automation-core for Android/TikTok workflows. Covers startup contract, ADB config, workbook mapping, Excel pitfalls, device lock policy, and the Codex↔Claude approval loop."
version: 1.5.0
author: Hermes Agent
metadata:
  hermes:
    tags: [automation-core, android, tiktok, adb, consumer, workbook, openpyxl]
    related_skills: [consumer-scheduler-orchestration, github-code-review]
---

# automation-core-consumer

Build a consumer of `automation-core` for Android/TikTok automation.  
Repo root is typically `D:\Taadaa\<project-name>\`.

## Startup Contract (must follow exactly)

```
ACQUIRE_LOCKS
→ CONNECT_DEVICE / prepare_device (wake, swipe_unlock, lock_rotation)
→ OPEN_TIKTOK
→ DISMISS_POPUPS
→ ACCOUNT_SWITCHER
→ DISMISS_POPUPS_AFTER_SWITCH
→ ACCOUNT_READY
```

- `prepare_device()` is called ONCE from `automation_core.device`. Consumed parameters: `rotation`, `wake=True`, `swipe_unlock=True`, `lock_rotation=True`.
- No TikTok-specific actions before `prepare_device`.
- TikTok-specific upload logic begins only after `ACCOUNT_READY`.

## OPEN_TIKTOK Implementation (must verify feed loaded)

The handler **must** do more than just call `adapter.launch_app()`. On some devices (e.g. SM-G930S) the app starts but sticks at SplashActivity — the ADB command succeeds but the UI never reaches the feed. This cascades into `PROFILE_ROOT_NOT_CONFIRMED` during account switching because there is no profile root.

**Required pattern — force-stop, launch, verify feed, retry, MANUAL_REVIEW:**

```python
def _handle_open_tiktok(self) -> bool:
    package = self.context.config["tiktok_package"]
    adapter = self.context.adapter
    feed_indicators = ["for you", "following", "đề xuất", "home_tab",
                       "com.ss.android.ugc.trill:id/home"]

    for attempt in range(1, self.ui_retry_limit + 1):
        # 1. Force-stop guarantees a cold start (resets stuck SplashActivity)
        adapter._adb.shell(["am", "force-stop", package], timeout=10, check=False)
        time.sleep(2)

        # 2. Launch via monkey → am start fallback
        if not adapter.launch_app(package):
            if attempt < self.ui_retry_limit: time.sleep(3); continue
            break  # exhausted → MANUAL_REVIEW

        # 3. Poll UI dump for feed indicators (30s timeout, 2s interval)
        if _wait_for_feed(adapter, feed_indicators, timeout=30):
            return True
        if attempt < self.ui_retry_limit: time.sleep(2)

    # All retries exhausted → MANUAL_REVIEW
    self.context.is_ui_unavailable = True
    self.context.error = (
        f"[OPEN_TIKTOK_FAILED] TikTok không load feed/home sau "
        f"{self.ui_retry_limit} lần force-stop+launch. "
        f"Cần MANUAL_REVIEW: mở TikTok thủ công, kiểm tra login/onboarding."
    )
    return False
```

**Key rules:**
- **Force-stop every attempt** — a stuck SplashActivity will not recover without killing the process. Not optional.
- **Poll UI dump for feed** — returning True just because the ADB command succeeded is the root cause of the machine-62 bug. The only signal that matters is finding feed markers (`for you`, `following`, `đề xuất`, `home_tab`) in the UI XML.
- **Inner retry loop** — each attempt does one complete force-stop+launch+wait cycle. After all retries, `is_ui_unavailable=True` forces the outer `_execute_with_ui_retry` to break and `_transition(False)` to route to MANUAL_REVIEW (not FAILED).
- **MANUAL_REVIEW, not FAILED** — a device that can't reach the feed after repeated cold starts won't fix itself on a job-level retry. The user must intervene.

### Soft reboot recovery (optional escalation before MANUAL_REVIEW)

When all `ui_retry_limit` launch attempts fail, the consumer can attempt a **device soft reboot** before escalating to MANUAL_REVIEW. This is gated by a config opt-in (`allow_device_reboot_recovery`, defaults `False` — fail-closed).

**When to add this:** Devices that occasionally enter a deep hang state where even force-stop + cold launch cannot reach the feed, but a full Android boot cycle clears the condition. Samsung S7-era farm devices are the typical case.

**Required pattern — reboot sequence, then retry launch once:**

```python
def _soft_reboot_recovery(self, adapter, package, feed_indicators) -> bool:
    # 1. adb shell reboot
    # 2. adb wait-for-device (120s timeout)
    # 3. Poll sys.boot_completed=1 via getprop (60s timeout)
    # 4. am force-stop TikTok
    # 5. adapter.launch_app(package)
    # 6. _wait_for_feed(adapter, indicators, timeout=30)
    # Return True only if feed confirmed after reboot
```

**Integration point in `_handle_open_tiktok`:** Between the retry loop and the MANUAL_REVIEW block:

```python
# After the for-loop exhausts all attempts
allow_reboot = self.context.config.get("allow_device_reboot_recovery", False)
if allow_reboot:
    reboot_ok = self._soft_reboot_recovery(adapter, package, feed_indicators)
    if reboot_ok:
        return True  # recovery succeeded, workflow continues
    # fall through to MANUAL_REVIEW
```

**Key rules:**
- **Config opt-in, fail-closed** — `allow_device_reboot_recovery` defaults `False`. Must be explicitly set to `True` in the YAML/JSON config file.
- **Log every step** — use `[REBOOT_N/6]` prefix so the log is grep-able during debugging.
- **wait-for-device needs 120s** — some Samsung farm devices take 60-90s to reappear after reboot. The default ADB connection timeout (20s in AdbClient) is too short for this path; pass `timeout=120` explicitly via `adb.run(["wait-for-device"], timeout=120, check=False)`.
- **sys.boot_completed polling** — after `wait-for-device` returns, the device is in `device` state but Android may still be booting. Add a secondary 60s polling loop checking `getprop sys.boot_completed` → `"1"` before assuming readiness.
- **Settle time** — insert `time.sleep(5)` after boot completes before force-stopping or launching. Some devices need a moment after `sys.boot_completed=1` for the UI layer to stabilize.
- **On failure → MANUAL_REVIEW** — if any reboot step fails or the post-reboot launch still can't reach the feed, the handler must fall through to the existing MANUAL_REVIEW path (with `is_ui_unavailable=True`). Never loop back into the retry cycle — reboot is the last resort.
- **Reuses existing infrastructure** — force-stop, `launch_app`, and `_wait_for_feed` are the same methods used in the normal retry loop. No new automation-core changes needed.
- **Error messages include reboot context** — when reboot was attempted and also failed, append "Soft reboot recovery cũng thất bại." to the MANUAL_REVIEW error so the operator knows reboot didn't help.

**Reference implementation:** See `references/device-reboot-recovery.md` for full code, logging format, and the session that introduced this pattern.

### _wait_for_feed helper

```python
def _wait_for_feed(self, adapter, indicators: list[str], timeout=30) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            xml = adapter.dump_ui().lower()
            if any(ind in xml for ind in indicators):
                return True
        except Exception:
            pass
        time.sleep(2)
    return False
```

## Device Lock Policy

- Device lock via `automation_core.device_lock.acquire_device_lock()`.
- Workbook lock via `automation_core.workbook.acquire_workbook_lock()`.
- Locks released in `finally` (via `_release_leases()`).
- **Consumer-side unlock recovery**: After `prepare_device()` returns, if `unlock_state == "locked_or_secure"`, the consumer MUST retry swipe-unlock with more aggressive parameters before proceeding. Do NOT blindly proceed (TikTok won't render on a genuinely locked screen) and do NOT immediately escalate to MANUAL_REVIEW (the core swipe may have been close but slightly mis-timed for this device).
  - Retry swipe from 95% height → 25% height (steeper than core's 85%→35%), with 500ms duration (longer than core's 280ms)
  - Verify unlock via `dumpsys window policy` — check that `mShowingLockscreen=false`, no `keyguardShowing=true`, etc.
  - Up to 3 retry attempts (match `ui_retry_limit` pattern)
  - If retries succeed → continue normally
  - If retries exhausted → `is_ui_unavailable=True` → MANUAL_REVIEW (ask user to unlock manually)
- **Keyguard detection patterns** (reusable module-level constants matching `automation_core.device._window_state()`):

  ```python
  _LOCKED_PATTERNS: tuple[re.Pattern[str], ...] = (
      re.compile(r"mShowingLockscreen\s*=\s*true", re.IGNORECASE),
      re.compile(r"isStatusBarKeyguard\s*=\s*true", re.IGNORECASE),
      re.compile(r"keyguard(?:Showing|Locked)?\s*=\s*true", re.IGNORECASE),
      re.compile(r"showing\s+keyguard", re.IGNORECASE),
  )

  def _is_locked_in_dumpsys(text: str) -> bool:
      return any(pattern.search(text) for pattern in _LOCKED_PATTERNS)
  ```

## ADB

- ADB is NOT in PATH. Must use explicit path:
  `C:\\Program Files (x86)\\xiaowei\\tools\\adb.exe`
- Configurable via `adb_path` config key.
- `DeviceTransport.__init__` and `AdbClient` both consume `adb_path`.
- **Discovery pattern**: Before live run, check actual ADB availability:
  1. Try `adb_path` config key
  2. Fall back to sibling project config: `python_runner/config.example.yaml` has `adb_path: C:\\Program Files (x86)\\xiaowei\\tools\\adb.exe`
  3. Run `adb -s <serial> get-state` AND `getprop ro.product.model` before any live action.
- **Preflight required after code APPROVED**: Fixture approval is NOT sufficient for live readiness. After Claude APPROVED but before first live run, must:
  1. Read the **real** workbook and check header aliases (e.g. `ID` vs `ID TikTok`, `Máy` vs `May`)
  2. Resolve numeric column types (e.g. `Folder Video = 489.0` → folder `489`)
  3. Check machine-first-row selection and serial/device ID extraction
  4. Verify next-video path exists on disk
  5. Run `adb devices -l` with the exact configured ADB path
  6. Verify no machine or serial lock for the target
  7. **Only then** start the live workflow
- **Lock check**: Must check BOTH `machine_<n>.lock.json` AND `serial_<serial>.lock.json`. A stale serial lock (PID dead) does not block but must be noted.

## Workbook Mapping Pattern

- `Tik1.xlsx` (D:\\OneDrive\\Tiktok\\Tik1.xlsx) is the canonical workbook.
- Columns: `Máy | device ID (= ADB serial) | ID (= TikTok ID) | Folder Video | video gốc | Keyword Video | Hashtag Pool | Video Đã Đăng | Kiểm Tra Dữ Liệu`.
- **No `account_profile` YAML.** All mapping comes directly from the workbook.
- Each workbook (Tik1, Tik2, Tik3, ...) is an independent workflow.
- Consumer supports `--workflow-workbook` CLI arg to point to any TikN workbook.
- Machine-first-row selection: first row per machine number in the workbook.
- Serial/device ID from the workbook is the ADB serial directly.
- **Workbook lock workaround**: When pandas/permission fails on OneDrive-synced workbooks, use `openpyxl.load_workbook(path, read_only=True, data_only=True)` instead. This avoids file-lock conflicts with OneDrive sync.

### Inventory/Reconcile: Separate Mapping from Credential Tracking

For account reconciliation, do **not** force one workbook to serve two incompatible schemas:

- **Safe mapping workbook** is the source for inventory: machine number, ADB serial/device ID, and expected TikTok IDs. Pass it as `--workbook`.
- **Tracking workbook** (for example `taikhoan_dat_v2_updated .xlsx`) is the source for account/login fields. Pass it separately as `--tracking-workbook`; it is read only when an expected account is missing on-device and needs a login attempt.

Required flow:

```
safe mapping: machine + device ID + expected IDs
→ inspect account switcher
→ reboot/refresh only for an evidenced stale-navigation signature
→ select only expected IDs still missing on device
→ tracking workbook: retrieve the matching account data for those IDs
→ login and verify switcher again
```

Rules:
- Never pass the credential-tracking workbook as the inventory mapping merely because it contains account IDs; it may not have a usable serial header.
- Never derive credentials from the safe mapping workbook; it intentionally omits them.
- The reconciliation CLI should require distinct explicit arguments (`--workbook`, `--tracking-workbook`) and thread the tracking path only into the login-provider selection function.
- Before a live run, run a read-only parser check against the exact safe workbook: selected machine resolves to exactly one serial and the expected account count is nonzero. Treat a schema error as a pre-lock/config failure, not a device failure.
- Add regression tests proving the two paths are distinct and that only `device_missing` IDs are requested from the tracking provider.

### Canonical Header Normalization

Headers have many variants. Always normalize with:
- Unicode NFKC
- NBSP (\u00a0, \u200b) → space
- Collapse whitespace
- lowercase
- Strip diacritics (đ→d, ê→e, etc.)
- Known aliases per field (e.g. "ID" / "username" → "ID TikTok")

**Serial column aliases** (all known variants — missing one causes `CONFIG_ERROR: account workbook is missing serial column`):
- `"so seri"`, `"series model may"`, `"phoneid"`, `"phone id"`, `"serial"`
- `"device id"`, `"deviceid"` ← real-world workbooks often use "device ID" as the column header
- When adding a consumer, always check the actual workbook column headers with `openpyxl` before hardcoding `SERIAL_HEADERS`.

### Excel Data Type Pitfalls

- `Folder Video` can be an int/float (489 or 489.0). Must convert safely:
  `int(x) → str(x)` for int, `str(int(x)) if x == int(x) else str(x)` for float.
- `Video Đã Đăng` can be int/float/None. Must int-cast with zero default.
- `EmptyCell` (openpyxl read-only mode) has no `column_letter`. Iterate by index.
- `video_number` override must propagate to `context.video_number` and workbook write.

## Cache Cleanup

Must run `pm trim-caches` (NOT `pm clear` — that logs out) at both:
- **Pre-CACHE** (after INIT, before READ_WORKBOOK)
- **Post-CACHE** (after DELETE_REMOTE_MEDIA, before RELEASE)

## Device Readiness — USB popup & Wi-Fi gate (core 0.4.22+)

Samsung farm: USB popup `MtpApplication/USBConnection` xuất hiện sau PC sleep
chặn uiautomator + mọi UI tap; wifi có thể văng tự nhiên và reboot không tự
lên. Core `prepare_device` (0.4.22) tự dismiss popup qua shell + verify bằng
`dumpsys activity`; `watch_device_reconnect` (0.4.23) defer on_ready tới khi
wifi lên (`WIFI_NOT_READY`). Chi tiết detect/dismiss/verify + lệnh chạy env
sạch + PS 5.1 pitfall: `references/core-device-readiness.md`.

## Video Selection

- `Video Đã Đăng + 1` = next video number.
- Video at: `D:\TIKTOK-videonuoinick\{Folder Video}\{video_number}.mp4`
- `--video-number` for debug override; override must update context and workbook.
- Upload duplicate guard: `is_video_already_posted()` check before proceeding.

## Hashtag Selection

- Random 3-6 from `Hashtag Pool` column in workbook.
- Each run picks differently (random seed not pinned).
- Pool may be comma/space/newline delimited; parse and dedupe.
- If pool < 3, fall back to safe default hashtags.
- Keyword Video field can influence selection priority.

## Workbook Write Safety

- `atomic_workbook_update()` from `automation_core.workbook` with:
  - `backup=True`
  - `lock_timeout=30`
  - Save → reopen → verify cycle.
- Only write after verified post success.
- `dry_run` must propagate to `AccountSource`: if `dry_run=True`, update logs but does not write.

## ACCOUNT_SWITCHER Error Handling — Simplified (v2)

`_handle_account_switcher()` calls `open_profile_root()` then `open_switcher()` from `automation_core.tiktok.account_switcher`. The consumer must **NOT** add fallback tiers, coordinate hacks, subpage-clearing helpers, or recovery pipelines. Core is the single source of truth for navigation.

### Required pattern

```
_handle_account_switcher():
  1. if not dismiss_popups_core(): return False  ← check is_ui_unavailable after dismiss
  2. open_profile_root(adapter)                  ← core call, no consumer fallback
  3. if not dismiss_popups_core(): return False  ← popups may appear after profile loads
  4. open_switcher(adapter)                      ← core call, no recovery tiers
  5. if not dismiss_popups_core(): return False  ← popups after switcher opens
  6. return True
```

**CRITICAL — check is_ui_unavailable after every _dismiss_popups_core() call.**
`_handle_dismiss_popups()` can fail silently (UI dump exception sets `is_ui_unavailable=True` and returns `False`). If the caller ignores the return value, the state machine proceeds into core navigation with a broken UI, producing confusing downstream errors. Always gate: `if not self._dismiss_popups_core(): return False`.

On ANY core failure (AccountSwitcherError or other exception):
- Set `context.is_ui_unavailable = True`
- Populate `context.error` with `[ACCOUNT_SWITCHER_FAILED]` + core error + MANUAL_REVIEW instructions
- Save checkpoint
- Call `_detect_account_switcher_edge_cases()` for CAPTCHA/login detection
- Return False → state machine routes to MANUAL_REVIEW

### Helper methods

```python
def _dismiss_popups_core(self) -> bool:
    """Dismiss popups best-effort using core module.

    Returns:
        True nếu dismiss OK (hoặc không có popup), False nếu is_ui_unavailable bị set.
    """
    try:
        self._handle_dismiss_popups()
    except Exception:
        pass  # Best-effort
    return not self.context.is_ui_unavailable

def _fail_account_switcher(self, err_msg: str) -> None:
    """Centralized error logging → MANUAL_REVIEW."""
    self.context.is_ui_unavailable = True
    full_msg = (
        f"[ACCOUNT_SWITCHER_FAILED] {err_msg}. "
        f"Cần MANUAL_REVIEW: kiểm tra TikTok đã login chưa, "
        f"dismiss popup/onboarding thủ công rồi retry."
    )
    self.context.error = full_msg
    self.context.checkpoint.update({
        "last_state": WorkflowState.ACCOUNT_SWITCHER.value,
        "error": full_msg,
    })
    logger.error(full_msg)
    self._detect_account_switcher_edge_cases()
```

### Rules

- **No consumer-side recovery.** Do NOT add `_fallback_tap_profile_tab`, `_reset_to_home_feed`, `_reopen_tiktok_clean`, `_clear_profile_subpage_before_navigation`, or `_verify_clean_profile_root`. These have been removed from all consumers.
- **Only core: `open_profile_root` and `open_switcher`.** Do NOT import `leave_profile_subpage`, `is_switcher_open`, `is_profile_subpage`, or `find_switcher_anchor` from the consumer. Core handles all internal retries and subpage clearing.
- **All failures → MANUAL_REVIEW.** A device that can't navigate to profile/switcher after core's internal retries needs human intervention, not a job-level retry.
- **Dismiss popups before and after** every core navigation call. Use the existing `_handle_dismiss_popups()` which delegates to `automation_core.popup.detect_popup`.

## ADB Install Troubleshooting (Samsung Farm Devices)

ADB install/install-multiple timeout trên Samsung S7 (SDK 26) có 2 nguyên nhân chính:

### 1. Stale Install Session

Khi `adb install-multiple` bị kill giữa chừng, packageinstaller giữ session dangling. Mọi lệnh install sau treo vì pm chờ session cũ.

**Phát hiện:** `adb -s <serial> shell "pm install-create"` trả về session ID cũ (VD `[131451610]`).

**Xử lý:** `adb -s <serial> shell "pm install-abandon <session_id>"`
**Verify:** `adb -s <serial> shell "pm install-create"` → session mới; abandon luôn session test.

### 2. Samsung Device Security Verifier

SM (`com.samsung.android.sm.devicesecurity`) là requiredVerifier. Khi thiếu `-i installerPackage`, SM treo kiểm tra sideload → timeout.

**Giải pháp — `-i com.android.vending`:**
```bash
# Single APK
adb -s <serial> shell "pm install -i com.android.vending /path/to/app.apk"

# Multi-split
SES=$(adb -s <serial> shell "pm install-create -S $TOTAL_SIZE -i com.android.vending" | grep -oP '\[(\d+)\]' | tr -d '[]')
adb -s <serial> shell "pm install-write -S <size> '$SES' 'base' /path/base.apk"
adb -s <serial> shell "pm install-write -S <size> '$SES' 'split1' /path/split1.apk"
adb -s <serial> shell "pm install-commit '$SES'"
```
`-i com.android.vending` giả danh Google Play Store, bypass Samsung verifier.

### 3. Push-then-Install cho ADB chậm

Samsung S7 transport ~1.0 MB/s (USB 2.0). `install-multiple` streaming dễ timeout.

**Workflow:** push trước → install local:
```bash
adb -s <serial> push <source_dir> /data/local/tmp/apks/
adb -s <serial> shell "pm install -i com.android.vending /data/local/tmp/apks/app.apk"
# Multi-split: install-create → install-write × N → install-commit
adb -s <serial> shell "rm -rf /data/local/tmp/apks/"
```

Luôn dùng timeout ≥ 300s cho push & install-commit.

## Consumer Project Topology (where source actually lives)

The TikTok automation project has a **dual-location** architecture that can make code review confusing, especially when Codex made changes.

### Two source trees

| Location | Purpose |
|---|---|
| `D:\Taadaa\<project-name>\` | **Real source** — editable development tree. `social_reg_v1.py` here is the full ~6000+ line source file. |
| `D:\OneDrive\Tiktok_Reg\` | **Deployed bootstrap** — the `social_reg_v1.py` here is a 16-line loader that imports a compiled `.pyc` from `__pycache__/`. |

The OneDrive copy runs in production; the Taadaa copy is the canonical source. **Editing the OneDrive `.py` bootstrap does not change behavior** — the real logic is in the `.pyc` loaded at runtime.

### Finding the real source tree for review

Before searching for a function, identify both trees:

```bash
# 1. Find automation-core's editable install to find the parent tree
pip show automation-core
# → Editable project location: D:\Taadaa\automation-core

# 2. Look for sibling consumer projects under the same parent
ls D:\Taadaa\
# → Tiktok_Reg/  automation-core/  Tiktok-video/  ...
```

Always check `D:\Taadaa\Tiktok_Reg\` first for function definitions. The OneDrive tree will be invisible to `grep`/`search_files` when the function exists only in compiled form.

### Compiled `.pyc` pitfall (Codex review blind spot)

Codex sometimes modifies the **compiled** `.pyc` directly without updating the `.py` source. This creates a critical blind spot:

- `grep`, `search_files`, and `git diff` on the `.py` files will **not find** Codex's changes.
- The `__pycache__/social_reg_v1.cpython-311.pyc` contains the actual runtime logic.
- A function like `_soft_reboot_recovery` may exist **only** in the `.pyc`.

**Detect this during review:**

1. Check the deployment tree's `social_reg_v1.py` — if it's a <20-line bootstrap with `marshal`/`importlib` loading a `.pyc`, the real code is compiled.
2. Compare file sizes: OneDrive bootstrap is ~600 bytes; Taadaa source is ~290KB.
3. If Codex ran on a worktree pointing to the OneDrive bootstrap, it may have modified the `.pyc` only. **Request a decompile or source commit before approving.**
4. When you can't find a function in either `.py` tree, check `__pycache__/` for a `.pyc` larger than the expected loader.

## Safety Guards (do NOT add)

- Do NOT add `is_device_locked` flag on `StateContext` — the consumer's unlock detection is a temporary implementation detail of `_handle_connect_device`, not a cross-state flag.
- Do NOT add `locked_or_secure` as a permanent workflow block. The consumer retries swipe with better parameters. Only escalate to MANUAL_REVIEW when retries are also exhausted (indicating a real lock, not swipe timing).

## Consumer-Side Unlock Recovery (Core `prepare_device` Still Returns locked_or_secure)

`automation_core.device.prepare_device()` does `wake` + `swipe_unlock` + `lock_rotation`, but some Android devices (Samsung S7 series, SM-G930F/G930S) still report `locked_or_secure` even after a successful swipe when:
- The screen was off for a long time before the workflow started
- The swipe duration (core uses 280ms) is slightly short for the device's sensor
- The swipe start height (core uses 85%) doesn't reach the unlock trigger zone

The consumer MUST NOT block on `locked_or_secure` without attempting recovery, and MUST NOT blindly proceed when the device is genuinely locked (TikTok won't render).

### Required Pattern — Insert Between prepare_device and rotation_locked Check

```python
readiness = prepare_device(self.context.adb_client, **prepare_kwargs)

# After prepare_device but before rotation check: consumer-side unlock retry
_UNLOCK_RETRIES = 3
if readiness.unlock_state == "locked_or_secure":
    logger.warning(f"Device locked after core prepare_device. Retrying swipe ({_UNLOCK_RETRIES} attempts)...")
    width, height = readiness.screen_size or (1080, 1920)
    for retry in range(1, _UNLOCK_RETRIES + 1):
        # Swipe from sát bottom edge (95% height), longer duration (500ms)
        adb_client.shell(["input", "swipe",
                          str(width // 2), str(round(height * 0.95)),
                          str(width // 2), str(round(height * 0.25)),
                          "500"], timeout=10, check=False)
        time.sleep(1.5)

        # Verify unlock via dumpsys window policy
        policy = adb_client.shell(["dumpsys", "window", "policy"], timeout=10, check=False)
        if policy and policy.ok and not _is_locked_in_dumpsys(policy.stdout):
            logger.info(f"Consumer swipe retry {retry} succeeded ✓")
            break
    else:
        # All retries exhausted → MANUAL_REVIEW
        self.context.is_ui_unavailable = True
        self.context.error = "[DEVICE_LOCKED] ..."
        return False

if readiness.rotation_locked is not True:
    # rotation check — unchanged, only reached if unlock succeeded or was never needed
    ...
```

### Key Rules

- **Separate recovery layers, in strict order:**
  1. `prepare_device` (core) — standard wake + swipe (85%→35%, 280ms)
  2. **Consumer swipe retry** — more aggressive (95%→25%, 500ms), verified via `dumpsys window policy`
  3. `rotation_locked` check — only reached after unlock is confirmed or was never needed
  4. OPEN_TIKTOK → force-stop + relaunch + `_wait_for_feed` + optional soft reboot
  5. MANUAL_REVIEW → user opens TikTok / unlocks device manually

- **Do NOT grab `screen_size` from `adb shell wm size` separately** — `prepare_device` already returned it as `readiness.screen_size`. Use it directly with a fallback of `(1080, 1920)`.

- **Do NOT add the rotation check before the unlock retry** — rotation must wait until unlock is confirmed because `settings put system` commands may not apply on a locked screen.

- **Reuse `_is_locked_in_dumpsys()`** (defined at module level) rather than inline-regexing dumpsys output in the handler. The patterns must match `automation_core.device._window_state()` exactly so both layers use the same definition of "locked".

- **Fallback screen size `(1080, 1920)` is safe** — the Samsung S7 farm devices all use 1080×1920. For other resolutions, `readiness.screen_size` will be populated by `prepare_device`'s `wm size` call.

## User Frustration Signals (do NOT ignore)

- If user says "xoá" (remove), remove it from ALL mentioned locations. Do not keep a guard in other projects.
- If user says "đừng gọi tao" (stop calling me), run the loop to completion internally; relay only the final APPROVED result.
item. Fix: add `am force-stop <package>` with `time.sleep(1.5)` before monkey/am start inside `launch_app()`. 
14. **`import re` inside `while` loop degrades performance on large UI XML** — Python caches the module lookup but the dict lookup still runs on every iteration over hundreds of XML nodes. Fix: import all stdlib modules (`re`, `xml.etree.ElementTree`, `time`) at the **top of the method**, never inside a loop.
15. **Consumer skips unlock_state check after `prepare_device`** — core `prepare_device` may return unlock_state=locked_or_secure on Samsung S7 devices even after a swipe attempt. Without consumer-side retry, TikTok opens on locked screen -> SplashActivity -> MANUAL_REVIEW cascade. Fix: consumer-side retry with aggressive swipe (95%->25%, 500ms) and dumpsys-window-policy verification.
16. **reboot_and_restore() callbacks are Callable[[], object] — zero arguments** — See `references/reboot-and-restore-callback-contract.md`. Old `soft_reboot_and_wait` removed in core >=0.2.40. Callbacks capture `adb` via closure: `lambda: wait_until_unlocked(adb)`, never `lambda a: ...`. Error: `TypeError: <lambda>() missing 1 required positional argument`.
## TikTok New UI Login (post-46.x) & Manual ADB Workflow

Khi reconcile script thất bại (thường do account switcher navigation fail trên máy chưa có tài khoản nào, hoặc UI TikTok đã thay đổi), dùng quy trình ADB thủ công:

### Flow tổng quát (đã sửa cho TikTok 44.x)

```
1. Dismiss post-install consent popup "Đồng ý và tiếp tục" — SWIPE UP (không tap)
2. Dismiss Google sign-in popup (BACK key)
3. Từ màn hình "Đăng ký TikTok" → tap "Bạn đã có tài khoản? Đăng nhập" ← KHÔNG tap "Tiếp tục với email" (đó là signup!)
4. Từ màn hình "Đăng nhập vào TikTok" → tap "Sử dụng số điện thoại/email/tên người dùng"
5. Tap tab "Email/tên người dùng"
6. AdbKeyboard input username → tap "Tiếp tục"/"Đăng nhập"
7. AdbKeyboard input password → tap "Tiếp tục"
8. (Nếu có) 2FA → pyotp.TOTP → input code → tap "Tiếp tục"
9. Dismiss popup bảo mật (tap nút "Đóng") + Từ chối contact permission ("TỪ CHỐI")
10. BACK về feed nếu đang ở Shop → tap Hồ sơ → tap tên → verify
```

### Post-Login Privacy Policy (SparkActivity) — unresolved

Trên TikTok 44.2.3, sau login có thể hiện SparkActivity (WebView privacy policy). UIAutomator không thấy nút trong WebView. Scroll xuống cuối + tap bottom. BACK = dismiss mà không accept → account không fully activated.

### Chi tiết UI mới

Xem `references/tiktok-new-ui-login.md` — bounds, activity names, text patterns cho từng màn hình.

### AdbKeyboard Input Verification

Broadcast `ADB_KEYBOARD_INPUT_TEXT` return code KHÔNG đáng tin cậy. Luôn verify text đã nhập bằng UI XML dump:

```bash
adb shell "uiautomator dump /sdcard/window_dump.xml && cat /sdcard/window_dump.xml" | grep -oP 'text="<expected>"'
```

Nếu nút submit vẫn `enabled="false"` sau broadcast → text chưa vào. Retry broadcast hoặc tap lại input field rồi gửi lại.

### 2FA với pyotp

```python
import pyotp
# Secret từ cột 2FA trong workbook (thường là base32, 32 ký tự)
totp = pyotp.TOTP(secret)
code = totp.now()  # 6 chữ số, hết hạn sau ~30s
```

Code phải được generate và gửi trong cùng một cửa sổ <5 giây. Nếu sai, xóa text cũ (`KEYCODE_MOVE_END` + longpress DEL) rồi tạo code mới.

**Reusable provider:** `login_runner/totp_provider.py` (xem `references/totp-provider-implementation.md`) — đọc 2FA secret từ workbook, tự động match row theo `(machine, identifier)`, cache kết quả. Dùng trong `cli.py`:
```python
from login_runner.totp_provider import WorkbookTotpProvider
challenge_provider=WorkbookTotpProvider(workbook_path, secret_provider)
```

### Workbook Lock Workaround

Khi `pandas.read_excel()` báo `PermissionError` trên file OneDrive, dùng:

```python
wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
```

## Common Bugs Found in This Project

1. `context.current_state` typo — `StateContext` doesn't have this; use `machine.current_state`.
2. AccountSource created without `dry_run=self.context.dry_run` — always passes it.
3. `str(row["Folder Video"])` produces "489.0" — use canonical int-safe conversion instead.
4. `EmptyCell.column_letter` crash — iterate rows by index, not cell object.
5. `Video Da Đăng` typo key — always use canonical aliases.
6. `run_post.py` reporting uses `context.current_state` — must be `machine.current_state`.
7. **New config property added to Config class, mock Config in tests not updated** — when adding a new property to `Config` (e.g. `allow_device_reboot_recovery`) and referencing it in `run_real()`, the mock Config created via `type("Config", (), {...})` in `test_run_post_manual_review_uses_machine_state` MUST include the new attribute. Otherwise tests fail with AttributeError. Always add the new attribute with its default value to the mock.
8. **`_handle_account_switcher` adds consumer-side fallback/recovery tiers** — the consumer must NOT add `_fallback_tap_profile_tab()`, multi-tier recovery pipelines (direct → home-reset → reopen-tiktok), coordinate hacks, or subpage-clearing helpers (`_clear_profile_subpage_before_navigation`, `_verify_clean_profile_root`). Core handles internal retries. The only valid consumer pattern: dismiss popups → call core → core fail → `is_ui_unavailable=True` → MANUAL_REVIEW. Any consumer-side fallback masks core bugs and creates divergent behavior across consumers.
9. **`adapter.tap_profile()` hardcoded `(100, 1800)` is wrong** — position `(100, 1800)` corresponds to the Home tab (leftmost), not Profile tab. Profile tab is typically bottom-right on 1080×1920 devices (`900, 1800`). Fix: make `tap_profile()` use UI dump to find the real profile tab element first, with coordinate fallback only as last resort. Search order: resource-id → text → content-desc → coordinate.
10. **Consumer reimplements core's back-press loop for subpage clearing** — `_clear_profile_subpage_before_navigation` and `_verify_clean_profile_root` with manual `for attempt in range(5): adapter.back()` loops duplicate `leave_profile_subpage(max_back=3)` from core. Fix: import `leave_profile_subpage` from `automation_core.tiktok.account_switcher` and delegate instead.
11. **`_execute_with_ui_retry` outer loop has no awareness of inner retry exhaustion** — the outer loop treats `_handle_account_switcher` returning False as retryable, even though the inner loop already exhausted all retries and fallbacks. Fix: set `is_ui_unavailable=True` after the inner fallback exhausts so `_execute_with_ui_retry` breaks on its `if self.context.is_ui_unavailable: break` guard.
12. **`_handle_open_tiktok` skips force-stop and does not verify feed** — calling `adapter.launch_app()` without `am force-stop` first can leave the app stuck at SplashActivity. The ADB return value says "success" but the UI never reaches the feed. Fix: force-stop before every launch, then poll UI dump for feed indicators (`for you`, `following`, `đề xuất`, `home_tab`) with a 30s timeout. After all retries exhausted, set `is_ui_unavailable=True` to route to MANUAL_REVIEW (not FAILED). This is the root cause of the máy-62 PROFILE_ROOT_NOT_CONFIRMED cascade.
13. **`adapter.tap_profile()` coordinates do not account for device resolution** — the old hardcoded (900, 1800) is correct for 1080×1920 but wrong for 1440×2560 (SM-G930S). Fix: add resolution detection via `wm size` and calculate profile tab at right 1/5 of screen width, or use bottom-nav XML scan to find the rightmost clickable element. Keep multiple coordinate fallbacks for common resolutions.
14. **`adapter.launch_app()` does not force-stop** — without a force-stop before launch, subsequent retries resume the existing stuck process rather than starting fresh. Fix: add `am force-stop <package>` with `time.sleep(1.5)` before monkey/am start inside `launch_app()` itself.
15. **Consumer skips unlock_state check after `prepare_device`** — core `prepare_device` may return `unlock_state="locked_or_secure"` on Samsung S7 devices even after a swipe attempt (swipe timing slightly off, or screen was off for minutes beforehand). Without a consumer-side retry, TikTok opens on a locked screen → sticks at SplashActivity → `_wait_for_feed` fails → PROFILE_ROOT_NOT_CONFIRMED cascade → MANUAL_REVIEW. The fix is NOT a hard block on `locked_or_secure` (swipe-only devices still work); the fix is consumer-side retry with more aggressive swipe parameters (95%→25%, 500ms) and dumpsys-window-policy verification, with escalation to MANUAL_REVIEW only when retries are also exhausted."
