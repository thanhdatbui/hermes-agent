---
name: code-audit
description: "Proactive code audit — systematically inspect code for bugs across defined categories before they manifest. Find, fix, verify, and report."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [code-audit, bug-hunting, code-review, quality, static-analysis]
    related_skills: [systematic-debugging, requesting-code-review, code-review-response, test-driven-development]
---

# Code Audit

## Overview

Proactive code audit finds bugs before they manifest — no failing test, no user report, no PR review needed. Systematic inspection across defined categories catches what tests and linters miss.

**Core principle:** Audit from first principles — don't wait for a bug to crash. Read the code, trace the logic, identify what *could* go wrong, and fix it now.

## When to Use

Use when the user asks you to:

- "Audit this code" / "audit this function" / "review this code for bugs"
- "Check logic of X" with specific concerns (type safety, cleanup, edge cases, correctness)
- "Find bugs in" / "fix any issues in" a specific file or function
- "Kiểm tra kỹ logic" (check the logic carefully) + list of concern areas
- "Verify correctness" of new or changed code

**Don't use for:**

- Debugging an existing failure → `systematic-debugging`
- Pre-commit verification pipeline → `requesting-code-review`
- Responding to third-party review findings → `code-review-response`
- Metrics/statistics → `codebase-inspection`
- Project handoff review → `project-handoff-audit`

## Audit Categories

Inspect every function against these categories:

### 1. Logic Correctness
- Does the algorithm produce the right result for all inputs?
- Are edge cases (empty input, single element, max values) handled?
- Are conditional branches exhaustive, or does a fall-through silently skip?
- **Example:** Fabricated split names "base"/"split_00" instead of actual APK split identifiers → `pm install-commit` always fails.

### 2. Error Handling
- Are failures silently ignored (empty `except`, `if ok:` without `else`)?
- Are error messages actionable (include values, context, not just "failed")?
- Does a failure in one step cascade correctly to the next?
- **Example:** `stat -c %s` fails → `if size_result.ok:` silently skips → wrong `total_bytes` → downstream `install-commit` fails with cryptic size mismatch.

### 3. Resource Cleanup
- Are temp files, connections, locks released on ALL exit paths (success, error, exception)?
- Is `try/finally` used for cleanup?
- Does early `raise` (or `return`) skip cleanup?
- **Example:** `rm -rf remote_dir` only runs after commit, not when `push`/`ls`/`install-create` raises → temp files accumulate on device.

### 4. Type Safety
- Can `int()`, `float()`, `json.loads()` receive non-numeric/non-JSON input and crash?
- Are `None` or empty-string return values handled before use?
- **Example:** `int(size_result.stdout.strip())` crashes with `ValueError` if `stat` returns empty string or error text.

### 5. String Safety (Shell Injection / Path Quoting)
- Are strings concatenated into shell commands without quoting?
- Do paths with spaces break the command?
- Are user-controlled values escaped?
- **Example:** `adb shell` concatenates args with spaces for the device's shell. `stat -c %s /path/to/my file.apk` word-splits at the space.

### 6. Race Conditions & Atomicity
- Check-then-write patterns without locks?
- Shared mutable state across calls?
- **Example:** Two simultaneous installs on the same device could conflict on `remote_dir` (mitigated by `abandon_stale_install_sessions` at top of `install_package`).

### 7. API Contract Compliance
- Does the function match its documented behavior?
- Are arguments in the right order?
- Are return types consistent with what callers expect?
- Are deprecated/private APIs used when public ones exist?

## Workflow

### Phase 1: Scope & Locate

1. Read the user's request — extract the **function name(s)** and **specific concern areas**.
2. Search the codebase for the target function:
   ```
   search_files("target_function", path="src/", file_glob="*.py", output_mode="files_only")
   ```
3. Read the COMPLETE file containing the function:
   ```
   read_file("src/module/file.py")
   ```
   If it paginates, continue with `offset=` until you have the full file.

### Phase 2: Systematic Inspection

Go through each audit category (1–7 above) against the target function.

For each category:
- Note what you find — GOOD or ISSUE
- For each ISSUE: record the exact line number, the pattern, and why it's wrong
- Reference a concrete example from the session's experience when applicable

### Phase 3: Fix

1. Plan fixes in dependency order (if fix A changes a signature fix B depends on, do A first).
2. Apply one fix per `patch` call — batch only truly independent changes.
3. After each batch, verify the module imports: `python -c "from package.module import Function"`.

### Phase 4: Verify

1. Run the project's canonical test suite:
   ```
   python -m pytest tests/ -v
   ```
2. If no test suite exists — create a focused ad-hoc verification script.
3. If the suite covers the changed code, note which tests exercised it. If not, note the coverage gap.

### Phase 5: Report

Deliver a structured report:

```
## Audit Summary: <function_name>

### Issues Found & Fixed

| # | Severity | Issue | Lines | Fix |
|---|----------|-------|-------|-----|
| 1 | Critical | description | N-N | fix summary |
...

### Verification
- pytest: N/N passed
- Import check: OK

### Minor/Unfixed Findings
- ...
```

## Examples

### ADB Multi-Split Install Audit (automation-core, device.py)

**Trigger:** "Kiểm tra kỹ logic install_multi_split (tính total_bytes, split_name mapping, cleanup khi crash, type safety, edge case file path có space). Nếu ổn → ghi 'NO_ISSUES_FOUND'. Nếu có → sửa."

**Result:** 6 bugs found & fixed:
1. **Critical** — fabricated split names → use `os.path.splitext(f)[0]`
2. **High** — stat failure silently skipped → hard-fail with `ADBError`
3. **High** — no cleanup on early failure → `try/finally` guarantees `rm -rf`
4. **High** — commit failure doesn't abandon session → `finally` calls `install-abandon`
5. **Medium** — `int("")` crash on non-numeric stat output → validate with `isdigit()`
6. **Medium** — shell path broken by spaces → `_quote()` helper wraps in double quotes

**Verification:** `pytest: 66/66 passed`, import check OK.

## Relationships to Other Skills

| Skill | When to Use Instead |
|-------|---------------------|
| `systematic-debugging` | Bug already exists, need root cause — audit is proactive, debugging is reactive |
| `requesting-code-review` | Pre-commit verification pipeline with security scan — audit is deeper, category-based inspection |
| `code-review-response` | Someone already reviewed your code and gave findings to fix |
| `test-driven-development` | Writing tests before code — use audit *after* code exists |
| `codebase-inspection` | Statistics (LOC, languages, ratios) — not bug hunting |

## Pitfalls

- **Don't audit from partial context** — always read the complete file, not just the target function. Surrounding code may influence correctness.
- **Don't skip the test suite** — "looks right" after fixing is not enough. Run tests.
- **Don't fabricate findings** — if the code is clean, report `NO_ISSUES_FOUND`. Audits that always find something lose credibility.
- **Don't over-engineer fixes** — fix the specific issue, not everything that looks suboptimal. One change per root cause.
- **Don't forget to check callers** — a fixed function signature may break its callers. Run the full test suite.
- **Space in paths is a real shell-injection vector on `adb shell`** — `adb shell` joins args with spaces for the device shell. Always quote remote paths with `_quote()`.
