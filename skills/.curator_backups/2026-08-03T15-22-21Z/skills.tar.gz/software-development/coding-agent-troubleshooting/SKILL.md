---
name: coding-agent-troubleshooting
description: "Diagnose and fix common CLI failures for Codex and Claude Code — sandbox, PATH, auth, version conflicts."
version: 1.0.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [troubleshooting, codex, claude, sandbox, windows, debugging]
    related_skills: [codex, claude-code, hermes-orchestration-dispatcher]
---

# Coding Agent Troubleshooting

Quick-reference diagnostic patterns for Codex CLI and Claude Code failures.
Load this skill when any coding agent returns infrastructure errors (sandbox, PATH, auth, shell).

## First Step for Any Agent

```
<agent> doctor    # Always the first diagnostic command
<agent> --version # Confirm running version
```

## Codex CLI — Windows Sandbox Failures

### Diagnostic Commands

```bash
codex doctor                           # Full health report
codex doctor 2>&1 | grep "runtime "    # Find REAL runtime path
codex --version                        # Running version
ls "$(dirname $(which codex))"         # What's next to the executable?
echo "$PATH" | tr ':' '\n' | grep -i codex  # All Codex PATH entries
tail -30 ~/.codex/.sandbox/sandbox.$(date +%Y-%m-%d).log  # Today's sandbox log
```

### Key Architecture

Codex has TWO locations:
1. **Executable** (in PATH): `~/AppData/Local/Programs/OpenAI/Codex/bin/codex.exe`
2. **Runtime** (packages): `~/.codex/packages/standalone/releases/<version>-x86_64-pc-windows-msvc/`
   - `codex-resources/codex-windows-sandbox-setup.exe`
   - `codex-resources/codex-command-runner.exe`

The executable may NOT have sandbox binaries next to it. The runtime ALWAYS does.

### Error: `program not found` for sandbox-setup

**Root cause**: `codex-windows-sandbox-setup.exe` missing from executable directory. Often happens after Microsoft Store version is uninstalled (takes the sandbox helper with it).

**Fix**:
```bash
RUNTIME=$(codex doctor 2>&1 | grep -oP 'package \K[^,]+')
cp "$RUNTIME/codex-resources/codex-windows-sandbox-setup.exe" "$(dirname $(which codex))/"
cp "$RUNTIME/codex-resources/codex-command-runner.exe" "$(dirname $(which codex))/"
rm -f ~/.codex/.sandbox-bin/codex-command-runner-*.exe  # clear stale cache
```

### Error: `unsupported protocol version 4`

**Root cause**: Sandbox binaries from a NEWER version (e.g. 0.146 alpha) paired with an OLDER codex.exe (e.g. 0.144). Protocol mismatch.

**Fix**: Copy sandbox binaries from the runtime matching the codex.exe version. See fix above — the `codex doctor` output tells you the correct runtime.

### Error: `CreateProcessAsUserW failed: 1920` or `CreateProcessWithLogonW failed: 2`

**Root cause**: Sandbox cannot access `WindowsApps\pwsh.exe` (error 1920) or cannot find `codex-command-runner.exe` (error 2).

**Fix for 1920** — create a pwsh wrapper from System32 PowerShell:
```bash
mkdir -p ~/.codex/shell
cp /c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe ~/.codex/shell/pwsh.exe
powershell.exe -Command \
  '[Environment]::SetEnvironmentVariable("PATH", [Environment]::GetEnvironmentVariable("PATH", "User") + ";C:\Users\'$USERNAME'\.codex\shell", "User")'
```
This wrapper is PowerShell 5.1, not 7. Basic exec commands work fine. Codex resolves `pwsh.exe` from PATH.

**Fix for error 2** — copy the correct command-runner. See "program not found" fix above.

### Error: `codex update` fails with tar error

```
tar (child): Cannot connect to C: resolve failed
```

**Root cause**: Git Bash `tar` is before Windows `tar` in PATH. PowerShell inherits the MSYS PATH and `tar` interprets `C:` as a network host.

**Fix** — clean PATH before update:
```bash
PATH="/c/Windows/System32:/c/Windows/System32/WindowsPowerShell/v1.0:/c/Windows:$(dirname $(which codex))" \
  codex update
```

### Multiple Installations After Auto-Update

Check with `codex doctor` → `PATH entries`. Common locations:
- `~/AppData/Local/Programs/OpenAI/Codex/bin/` — user PATH (may be stale)
- `~/AppData/Local/OpenAI/Codex/bin/<hash>/` — auto-update target
- `C:/Program Files/WindowsApps/OpenAI.Codex_*/` — Store version (may be uninstalled)

Remove stale PATH entries via Windows System Properties → Environment Variables.

### Sandbox Log Analysis

Sandbox logs at `~/.codex/.sandbox/sandbox.YYYY-MM-DD.log`. Key patterns:
- `spawning codex-windows-sandbox-setup.exe` WITHOUT full path → **will likely fail** if not next to executable
- `spawning C:\...\69066b736e1e17a4\codex-windows-sandbox-setup.exe` WITH full path → found via runtime
- `setup binary completed` → sandbox initialized successfully
- `CreateProcessAsUserW failed: 1920` → can't access WindowsApps pwsh
- `helper copy: recopied command-runner` → cache was stale, auto-fixed
- `START: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe` → using legacy PowerShell (works)
- `START: C:\Users\...\WindowsApps\pwsh.exe` → using Store PowerShell (may fail)

### MCP node_repl vs exec

`codex exec` (pwsh commands) requires working sandbox. MCP `node_repl` (file read/write via Node.js) uses a separate runtime and often works even when exec is broken. If `codex exec "echo test"` fails but codex can still read/write files, the issue is sandbox-specific, not a complete outage.

## Claude Code — Common Failures

### Permission Prompts Blocking Automation

`claude -p` (print mode) skips all interactive dialogs — use it for automation. If using interactive mode with `--dangerously-skip-permissions`, the permissions dialog defaults to "No, exit". Must send Down then Enter:

```bash
tmux send-keys -t <session> Down && sleep 0.3 && tmux send-keys -t <session> Enter
```

### Tool Call Denied (Permission Mode)

If Claude says "tool call denied", check permission mode:
```bash
claude -p "task" --permission-mode bypassPermissions
# or
claude -p "task" --dangerously-skip-permissions
```

## Dispatch Fallback Pattern

When the primary coding agent is blocked by infrastructure issues (sandbox, auth, PATH):

1. **Codex blocked** → try `codex doctor` and apply fixes above
2. **Codex still blocked** → dispatch to Claude: `claude -p --dangerously-skip-permissions "<task>"`
3. **Both blocked** → report to user with diagnostic output from both `doctor` commands

This pattern is especially relevant for `hermes-orchestration-dispatcher` workflows where Codex is the primary implementer and Claude is the reviewer.
