---
name: tiktok-consumer-automation
description: Patterns, pitfalls, and proven workflows for TikTok consumer automation — ADB interaction, UI compatibility, VPN gating, 2FA, and reconciliation scripts on Samsung Galaxy farms (SM-G930F/W8).
---

# TikTok Consumer Automation

Patterns và pitfall khi phát triển consumer automation cho TikTok trên farm Samsung Galaxy (SM-G930F, SM-G930W8).

## Quy tắc vàng

1. **Không reboot khi có VPN**: reboot giết `tun0`, đợi watcher gán lại mất 30-300s. Chỉ reboot khi thực sự cần (startup fail, UiAutomator treo).
2. **Ghi mọi thay đổi UI/handler vào `docs/ui-compatibility.md`**: mỗi fix popup, selector, fallback, startup handler phải có contract entry.
3. **Dùng `dumpsys activity` thay vì `uiautomator dump` để detect popup**: UiAutomator treo trên Samsung. `dumpsys activity activities` nhanh và không treo.
4. **Luôn có coordinate fallback cho image navigation**: `bottom_navigation_point` hoạt động ngay cả khi `detect_feed_controls`/`detect_profile_screen` trả về None trên W8.
5. **CẤM ghi/đè bất kỳ file nào vào `D:\video goc`** (kho video gốc — CHỈ ĐỌC). Ảnh/asset sinh mới chỉ ghi vào `D:\TIKTOK-videonuoinick\<folder>\` hoặc runtime root; override nguồn avatar qua `--avatar-source-root`. Vi phạm = phá kho nguồn của user (đã xảy ra: ghi đè avatar.jpg 45/64 không thể khôi phục). Nếu script nguồn (vd `make_avatar_yolo.py`) cần guard, dùng helper `_assert_outside_source(output, source_root)` ném ValueError khi output nằm trong source root.
6. **Batch chết giữa chừng → rerun ĐỒNG LOẠT cả list song song, không debug lẻ từng máy**. User yêu cầu chạy đồng loạt; khi launcher PS1 bị kill giữa chừng, đừng sa vào xử lý từng máy một — xác minh checkpoint/report rồi phóng lại N runner song song (`--recovery-mode` để takeover lock stale). Checkpoint trong `runs/<run_id>/checkpoint.json` là nguồn sự thật (state, post_tap_attempted, post_verified) — không dựa vào process exit.
7. **Không tải ảnh từ web rồi ghi vào kho nguồn**: avatarLarger từ HTML TikTok có thể là **avatar placeholder mặc định** (account chưa set ảnh) — kết quả ảnh trắng + silhouette, vô dụng. Xác minh nội dung trước khi dùng; và tuyệt đối không đè file trong `D:\\video goc` bằng ảnh tải về.
8. **Check wifi/connectivity trước live run và sau reboot, TRƯỚC khi gán proxy/VPN**: máy trong farm có thể văng wifi tự nhiên (`wlan0` state DORMANT/NO-CARRIER, mất IP, `ping: Network is unreachable`) dù VPN `tun0` vẫn báo CONNECTED — tun0 lên trên nền không mạng = gán proxy mù, upload fail/đăng ảo. Quy trình: (a) verify `ip addr show wlan0` có `state UP` + `inet <ip>` (chấp nhận `state up` HOẶC `state unknown` khi có `inet ` — một số ROM báo UNKNOWN dù có carrier); (b) `ping -c 2 -W 3 8.8.8.8` OK. Nếu wifi chết: `svc wifi enable` không cứu được (NO-CARRIER = radio không thấy AP, cần toggle tay trong Settings hoặc kiểm tra vùng phủ/antenna); `adb reboot` không tự đảm bảo wifi lên lại. **Đã implement trong core** `automation_core/device_recovery.py::wait_for_wifi(adb, timeout, poll_interval, stop_event)` — chỉ quan sát (không mutate device) — và gate `wifi_timeout` trong `watch_device_reconnect` trước `on_ready`: wifi chưa lên trong thời hạn → defer `on_ready` + log `WIFI_NOT_READY` (không gán proxy mù), retry khi wifi về; `wifi_timeout=0` tắt gate; `pending_notified` giữ reason (boot_id_changed) ổn định qua gate. Wheel từ 0.4.23. Không tự toggle/reboot wifi trong core code — chỉ chờ + verify.

## ADB Patterns

### AdbKeyboard text input

```python
# Cách 1: Broadcast (có thể timeout nhưng text vẫn vào)
b64 = base64.b64encode(text.encode()).decode()
subprocess.Popen([ADB, "-s", SERIAL, "shell", "am", "broadcast",
    "-a", "ADB_KEYBOARD_INPUT_TEXT", "--es", "text", b64],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Cách 2: input text (nhanh, cần field đã focus)
subprocess.run([ADB, "-s", SERIAL, "shell", "input", "text", text], timeout=10)
```

### Detect popup không cần UI dump

```python
activities = adb.shell(["dumpsys", "activity", "activities"]).stdout
if "UniversalPopupActivity" in str(activities):
    adb.shell(["input", "swipe", "540", "1600", "540", "400", "300"])
if "com.android.vending" in str(activities):
    # Google Play ToS hoặc PlayCore
    adb.shell(["input", "tap", "863", "1419"])  # Chấp nhận
```

### Samsung USB connection popup (sau PC sleep)

Popup `com.samsung.android.MtpApplication/.USBConnection` xuất hiện sau khi PC
sleep/bật lại (USB reconnect). Nó phủ lên MỌI app, chặn uiautomator dump, khiến
flow fail với `AVATAR_EDIT_OPEN_FAILED`/`OPEN_TIKTOK_FAILED` (mọi tap trúng
popup). Detection BẮT BUỘC qua `dumpsys` (uiautomator bị chặn):
`mCurrentFocus=...MtpApplication/.USBConnection`; nút dismiss là
`app:id/button_cancel` (bounds 0,0-540,162 → center ~(270,81)), fallback Back.

Handler app-neutral đã có trong core: `automation_core/usb_popup.py`
(`usb_popup_activity_present` + `dismiss_usb_popup`, từ wheel 0.4.21). Consumer
TikTok import + gọi ở 4 chỗ (profile-root recovery, account-switcher,
ENSURE_AVATAR). KHÔNG duplicate handler per-consumer.

**Hướng tối ưu (user đề xuất)**: popup này xuất hiện BẤT KỲ LÚC NÀO (mỗi lần PC
sleep bật lại), nên đừng gọi dismiss rải rác từng flow — đưa auto-dismiss vào
`automation_core/device.py::prepare_device` (cuối hàm, sau swipe-unlock; dùng
`dismiss_usb_popup_shell(adb)` — shell input không cần adapter consumer). Mọi
consumer (upload, feed, login, gmail, gan-proxy) đều đi qua `prepare_device`
qua `wait_until_unlocked`/`watch_device_reconnect` → "kệ mẹ nó, chạy cái gì
cũng bỏ qua popup". Dismiss fail chỉ log warning + field evidence, KHÔNG raise
(giữ contract `DeviceReadiness`). **Đã implement từ core 0.4.22** (commit
`1933c24`).

**Pitfall verify**: `dismiss_usb_popup` cũ dùng `uiautomator dump` để tìm Cancel
+ recapture — nhưng popup Samsung chặn uiautomator → recapture trả `unavailable`
→ hàm trả False dù BACK đã đóng. Fix: `dismiss_usb_popup_shell` verify bằng
**ActivityManager probe** (`_shell_probe` qua `dumpsys activity`) sau mỗi action
(thay vì uiautomator). Rule: bất kỳ handler nào phải xử lý popup chặn
uiautomator đều verify bằng `dumpsys activity`, không bằng UI dump.

**Pitfall timeline**: nếu consumer/core vừa sửa nhưng máy chạy TRƯỚC mốc đó thì
handler chưa có hiệu lực — kiểm tra mtime `state_machine.py`/wheel vs thời điểm
run trước khi kết luận "rule không hoạt động". Cũng check env đã cài đúng wheel
mới chưa (xem mục "Env automation_core dở dang").

**Pitfall verify-avatar false negative (máy 74)**: verify avatar sau save bằng
correlation pixel (ngưỡng 0.8) trên vùng crop — nhưng avatar hiển thị trong
khung tròn + overlay bị crop/scale khác nguồn vuông → correlation thấp
(0.02-0.25) dù nội dung ĐÚNG. **User nhìn xác nhận avatar đúng = bằng chứng
mạnh hơn pixel correlation** — báo user + để user xác nhận trước khi kết luận
fail; phân biệt similarity thấp TRƯỚC Next (chọn sai tile — bug thật) vs SAU
save (có thể false negative do overlay).

## UI Compatibility

### Machine 9 (SM-G930W8, TikTok 44.2.3)

- `detect_feed_controls`, `detect_profile_screen` → None (không detect được)
- `bottom_navigation_point(screenshot, "profile")` → (972, 1857) ✅
- Account switcher: `tap(540, 552)` sau khi vào Profile
- Consent popup: `UniversalPopupActivity` + swipe up
- Google sign-in: `AssistedSignInActivity` → Back key
- Login flow: "Bạn đã có tài khoản? Đăng nhập" → email option

### Các popup đã biết

| Popup | Detection | Dismiss |
|-------|-----------|---------|
| Consent "Đồng ý và tiếp tục" | `UniversalPopupActivity` | swipe(540,1600,540,400,300) |
| Google Play ToS | `com.android.vending` + `TosActivity` | tap(863, 1419) |
| Google Play PlayCore | `com.android.vending` + `PlayCoreAcquisitionActivity` | tap(783, 1824) then relaunch TikTok |
| Security check "Kiểm tra bảo mật" | "Hãy cùng kiểm tra bảo mật" text | tap(996, 923) — nút Đóng |
| Contacts permission | "Cho phép TikTok truy cập vào danh bạ" | tap(557, 1134) — TỪ CHỐI |
| Google sign-in | `AssistedSignInActivity` | `keyevent 4` (Back) |

## VPN Preflight Pattern

```python
from automation_core.preflight import require_android_vpn, serial_is_mapped_in_workbook
VICHANGER_SERIAL_HEADERS = ("phoneId", "deviceId", "serial")

# Trong reconcile_target, SAU lock acquisition:
if proxy_mapping and proxy_mapping.is_file():
    require_android_vpn(
        adb,
        required=serial_is_mapped_in_workbook(
            proxy_mapping, target.serial, serial_headers=VICHANGER_SERIAL_HEADERS,
        ),
    )

# Trong verify_post_reboot callback:
reboot_and_restore(
    adb,
    cleanup_before_reboot=lambda: None,
    recover_post_reboot=lambda: wait_until_unlocked(adb),
    verify_post_reboot=lambda: _verify_vpn(adb, target, proxy_mapping),
    boot_timeout=180,
    verification_timeout=300,  # Đủ 10 chu kỳ watcher 30s
)
```

## 2FA TOTP từ Workbook

```python
import pyotp
# Đọc cột 2FA từ workbook, tìm theo (machine, identifier)
totp = pyotp.TOTP(secret_2fa)
code = totp.now()  # 6-digit code
```

## Proxy readiness bypass (automation-core 0.2.40+)

`acquire_device_lock` gọi `wait_for_proxy_ready` để đợi watcher ghi marker `proxy_ready`. Nếu VPN (`tun0`) đã up nhưng watcher chưa ghi marker, dùng `live_vpn_verifier`:

```python
def _check_tun0(adb_path: Path, serial: str) -> bool:
    try:
        adb = AdbClient(str(adb_path), serial, default_timeout=10)
        result = adb.shell(["ip", "addr", "show", "tun0"], timeout=10)
        return result.ok and "inet " in str(result.stdout or "")
    except Exception:
        return False

# Trong reconcile_target:
lease = acquire_device_lock(
    ...,
    live_vpn_verifier=lambda s: _check_tun0(adb_path, s),
)
```

## Coordinate login fallback

Khi provider `login_one_account` fail (image-nav không hoạt động), dùng coordinate tap + `input text`:

```python
def _coordinate_login(target, account, adb_path):
    adb, s = str(adb_path), target.serial
    uid = account["id"]; pw = account.get("pass") or account.get("password")
    subprocess.run([adb,"-s",s,"shell","input","tap","427","1788"], timeout=10)  # Thêm TK
    time.sleep(2)
    subprocess.run([adb,"-s",s,"shell","input","tap","540","1830"], timeout=10)  # Đăng nhập
    time.sleep(1.5)
    subprocess.run([adb,"-s",s,"shell","input","tap","561","851"], timeout=10)   # SDT/email
    time.sleep(1)
    subprocess.run([adb,"-s",s,"shell","input","tap","713","288"], timeout=10)   # Tab Email
    time.sleep(0.5)
    subprocess.run([adb,"-s",s,"shell","input","text", uid], timeout=10)
    time.sleep(1)
    subprocess.run([adb,"-s",s,"shell","input","tap","540","1681"], timeout=10)  # Tiếp tục
    time.sleep(2)
    subprocess.run([adb,"-s",s,"shell","input","text", pw], timeout=10)
    time.sleep(1)
    subprocess.run([adb,"-s",s,"shell","input","tap","540","1681"], timeout=10)  # Tiếp tục
    time.sleep(3)
    subprocess.run([adb,"-s",s,"shell","input","tap","996","923"], timeout=5)    # Dismiss security
    return True
```

Gọi trong reconcile khi `login_module.login_one_account()` trả về False.

## Media fingerprint stale reservation recovery

Khi workflow chết giữa chừng (batch bị kill), ledger `idempotency/media-fingerprints/<key>.json` có thể giữ entry `status: reserved` của run chết. Lần chạy sau sẽ fail `MEDIA_FINGERPRINT_PENDING` ở `RESOLVE_NEXT_VIDEO` trước khi push media.

**Phân loại đúng trước khi xoá:**
- **Chưa từng post** (`post_tap_attempted=false` trong checkpoint, không có receipt `post-attempts/machine_X_video_N.json`) → reservation là stale hoàn toàn → **xoá entry** để retry chạy tiếp.
- **Đã bấm Post** (`post_tap_attempted=true`, checkpoint ở `VERIFY_POST`) → **KHÔNG xoá**; giữ reservation để recovery recheck profile, tránh repost mù.

```python
# Checkpoint là nguồn sự thật:
# runs/<run_id>/checkpoint.json  →  last_state, post_tap_attempted, post_verified, status
```

## Tạo avatar từ kho video (YOLO animal / frame sáng)

Video thú cưng/thiên nhiên không có mặt người → `make_representative_avatar(subject_type="person")` fail (face cascade rỗng) → fallback frame đầu tối. Giải pháp:

1. Cài `ultralytics` + opencv vào env automation:
   ```bash
   /d/Taadaa/python-envs/automation/Scripts/python.exe -m pip install opencv-python-headless ultralytics
   # numpy phải tương thích 3.12 (2.2.x), không dùng bản cp311
   ```
2. Tải model: `D:\CodexRuntime\tiktok-video\models\yolo11n.pt`.
3. Gọi `make_representative_avatar(subject_type="animal", subject_model=<path>, diagnostics=...)` từ `scripts/pipeline_common.py` — nó chọn **nhân vật xuất hiện nhiều nhất** (cluster theo binary hash). Nếu không detect được động vật đủ tin cậy → fallback chọn frame sáng có nội dung (std>50, mean 60-200, sat cao) crop vuông 512x512.
4. Script chuẩn đã có: `scripts/make_avatar_yolo.py` (map folder nguồn→output, guard `_assert_outside_source`, verify size/std, ghi report).
5. Output avatar chỉ ghi vào `D:\TIKTOK-videonuoinick\<folder>\avatar.jpg`, workdir tạm `D:\CodexRuntime\tiktok-video\avatar-yolo-work\<folder>`.

**Pitfall env**: chạy bằng `env -i PATH=...` (bỏ PYTHONPATH/PYTHONHOME lẫn hermes venv) nếu `import cv2/numpy/PIL` báo sai version hoặc lỗi C-extension — sys.path bị hermes venv chèn trước automation site-packages.

**Pitfall `AVATAR_EDIT_OPEN_FAILED`**: máy có thể kẹt ở surface khác (vd `FindFriendsPageActivity` — Tìm bạn bè) làm workflow không mở được màn Sửa hồ sơ → avatar fail dù ảnh nguồn tốt. Retry avatar smoke lần sau (sau khi máy tự về đúng surface) thường qua được như máy 45; máy 74 vẫn kẹt → giữ MANUAL_REVIEW, không spam retry cùng signature. Chạy avatar smoke song song với các máy khác, không làm lẻ.

## Env automation_core dở dang (import fail module mới)

Khi core build wheel mới (`dist/automation_core-X.Y.Z.whl`) nhưng env thực thi
(`D:\Taadaa\python-envs\automation`) import **không thấy module mới** (vd
`usb_popup`) — dù `pip show` báo version cao hơn:

- Nguyên nhân: dist-info bị cập nhật nhưng site-packages KHÔNG có file module
  tương ứng (cài dở dang/force-reinstall lỗi) → import fail im lặng.
- Chuẩn đoán: `ls site-packages/automation_core/ | grep usb` rỗng nhưng
  `dist-info` version mới hơn wheel hiện có.
- Fix: cài lại đúng wheel theo pin consumer:
  ```bash
  env -i PATH="/c/Windows/system32:/c/Windows:/d/Taadaa/python-envs/automation/Scripts:/c/Users/Kibe/AppData/Local/Programs/Python/Python312" \
    HOME="C:\\Users\\Kibe" USERPROFILE="C:\\Users\\Kibe" \
    /d/Taadaa/python-envs/automation/Scripts/python.exe -m pip install --force-reinstall \
    "D:\\Taadaa\\automation-core\\dist\\automation_core-0.4.21-py3-none-any.whl"
  ```
  (đúng version trong `requirements-automation-core.txt`). Verify:
  `python -c "from automation_core.usb_popup import ..."`.
- Lưu ý: `env -i` PHẢI kèm `HOME`/`USERPROFILE` nếu không pathlib `expanduser`
  raise "Could not determine home directory".

## Codex exec bị kill → để lại patch dở (working tree dirty)

`codex exec` chạy background qua Hermes bị kill giữa chừng (user interrupt /
process.kill) sẽ để lại **working tree lẫn lộn**: file đã patch một phần, test
mới viết dở, import mới thêm nhưng module chưa tồn tại. Trước khi chạy lại:

1. `git status --short` để thấy toàn bộ file dính.
2. `git diff --stat` đánh giá mức độ: thay đổi nhỏ/đúng hướng → giữ + hoàn thiện;
   thay đổi sai/chưa rõ → `git checkout -- <file>` revert.
3. Kiểm tra import mới có module đích chưa (vd `from automation_core.usb_popup
   import ...` mà core chưa build) — nếu chưa, workflow sẽ import-fail ngay
   đầu run.
4. Dispatch lại Codex với prompt yêu cầu "hoàn tất/verify trạng thái git trước,
   rồi implement tiếp" — không giả định run trước sạch.

## Verify avatar sau save — false negative (so sánh pixel thô)

Workflow verify avatar sau save bằng grayscale correlation trên vùng crop;
ngưỡng 0.8. Khi avatar hiển thị trong **khung tròn + overlay** (TikTok), ảnh bị
crop/scale khác nguồn vuông → correlation thấp (0.02-0.25) dù nội dung ĐÚNG →
`AVATAR_VERIFY_FAILED` false negative.

- Người nhìn (user) xác nhận avatar đúng là bằng chứng mạnh hơn correlation
  pixel — báo user kết quả + để user xác nhận trước khi kết luận fail.
- Nếu user xác nhận avatar đúng: không cần sửa handler (hoặc chỉ sửa verify
  poll recapture sau save 2s×15, lưu artifact ảnh sau save).
- Phân biệt: similarity thấp TRƯỚC Next trong picker (chọn sai tile — bug thật)
  vs thấp SAU save (có thể false negative do overlay).
- Vision model (vision_analyze) KHÔNG khả dụng trên môi trường này — đừng dựa
  vào nó để xác nhận ảnh; dùng ASCII preview (PIL convert L → chars) + user xác
  nhận.

## File quan trọng

- `references/usb-popup-root-cause.md` — chuỗi root cause popup USB Samsung đầy đủ (timeline mtime, env dist-info dở, fix shell-probe)
- `references/wifi-check-after-reboot.md` — chuẩn đoán + rule check wifi trước live/sau reboot (bài học máy 74)
- `references/killed-batch-recovery.md` — phục hồi batch bị kill: checkpoint/lock stale/fingerprint stale/chạy lại đồng loạt
- `docs/ui-compatibility.md` — registry tất cả UI handler (phải cập nhật mỗi lần sửa)
- `reports/AUDIT_LOG.md` — audit log cho blocked/reviewed work
- `login_runner/account_reconcile.py` — reconcile orchestration
- `login_runner/account_inventory.py` — inventory + startup/popup handling
- `login_runner/live_adapter.py` — live login adapter (hỗ trợ UI mới + cũ)
- `login_runner/totp_provider.py` — TOTP challenge provider
