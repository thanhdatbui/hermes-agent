---
name: portable-consumer-repo-maintenance
description: "Implement focused consumer-repository fixes for machine-specific configuration drift with isolated worktrees, override preservation, and evidence-based verification."
version: 1.0.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [consumer-repo, portability, configuration-drift, worktree, verification]
    related_skills: [systematic-debugging, test-driven-development, requesting-code-review]
---

# Portable Consumer-Repo Maintenance

## Trigger

Use when a consumer repository has machine-specific absolute paths, runtime defaults, scheduler/install wrappers, or configuration drift findings. This applies to Python, PowerShell, shell, and mixed-language workflow entrypoints.

## Workflow

1. **Isolate first.** Locate the consumer repository, read `AGENTS.md`/project rules/runbooks, inspect git status, and create a dedicated worktree and branch from the clean current consumer `main`. Do not edit a shared/core repository for a consumer-only issue.
2. **When the user explicitly requests a private-machine bootstrap bundle, act on that scope directly.** Do not repeatedly re-litigate generic security warnings after the user has accepted the tradeoff. Put machine-independent setup/configuration, skills, plugins, and requested credential files under a clearly named `deploy/` bundle, add a deterministic setup script, and document exact target paths. Never print secret contents while verifying.
3. **Separate repository payload from runtime state.** Copy only the requested setup artifacts; omit caches, locks, SQLite session databases, logs, and transient process state unless the user explicitly requests them. Make the installer target the current user's paths (`$PSScriptRoot`, `%LOCALAPPDATA%`, `%USERPROFILE%`) rather than hardcoded source-machine paths.
4. **Verify the installer itself.** Parse PowerShell/shell syntax, assert required bundle files exist, run `git diff --check`, and run the repository's canonical checks. If a broad suite flakes or times out, rerun the exact failing target once, then verify each relevant package separately and report the broad-suite blocker precisely.
5. **Trace configuration flow.** Read the flagged scripts, callers, wrappers, and focused tests. Identify default values, CLI flags, environment variables, path normalization, subprocess propagation, and scheduler/task-registration arguments.
6. **Build a tight red check.** Add focused tests that fail before the fix and prove both:
   - defaults do not embed user/machine-specific paths;
   - explicit CLI overrides remain authoritative;
   - environment overrides remain authoritative where supported.
   For non-Python wrappers, assert generated command/path text when invoking registration would be unsafe or unnecessary.
7. **Implement the smallest portable change.** Prefer project-relative paths, standard executable discovery (`PATH`), or explicit configuration. Preserve current behavior, validation, lock semantics, subprocess environment propagation, CLI compatibility, and exact existing asset basenames (including spaces and punctuation). Do not silently rename a workbook/config asset while relocating its directory. Avoid unrelated refactors.
8. **Verify in layers.** Run the focused tests, compile/lint checks, relevant drift/static scans, and `git diff --check`. Then run the broader suite if practical. Distinguish failures caused by missing sibling/reference worktrees or pre-existing fixtures from failures in the changed scope.
9. **Ad-hoc fallback.** If no canonical test/lint command is detected, create a temporary `hermes-verify-*` script in the OS temp directory using a safe `tempfile` path. Run it with the repository import path explicitly configured (for example, `PYTHONPATH=<worktree>`), remove it afterward, and report it explicitly as ad-hoc verification rather than suite-green evidence. Always assert the changed behavior directly, including default resolution and explicit environment/CLI override precedence. Keep assertions exact but simple when checking wrapper text (prefer asserting the required basename and forbidden legacy basename separately); if the verifier itself fails due to quoting/escaping or is launched outside the repository, correct the harness and rerun it before diagnosing repository code. Capture cleanup proof with `test ! -e <temp-script>` and print a concise success marker.
11. **Workbook/device identity clarification.** When a workbook row contains both a human machine label and a device identifier, treat the workbook's `device ID` as the direct ADB serial.
12. **Fresh-verification fallback.** If the system marks the workspace unverified or detects no canonical test/lint command, create a focused temporary script under the OS-safe temp directory with a `hermes-verify-` prefix and `tempfile` paths. Exercise the exact changed behavior and edge cases, run it with the repository import path configured, clean it up when possible, and report it explicitly as **ad-hoc verification**—never as full-suite green. Keep targeted tests, full suite, compile/import, and ad-hoc evidence as separate claims. On Windows, use Python `tempfile.mkstemp(prefix="hermes-verify-", suffix=".py", dir=...)`, not hand-built temp filenames; capture a distinctive pass marker and separately verify deletion. For workbook/video fixes, assert the real contract with an isolated temporary workbook/media directory (e.g. fail closed on blank/whitespace device serial and resolve posted=7 to 8.mp4), without live device or upload actions. This fallback applies even when a canonical suite was run earlier in the session: fresh-evidence status is a separate gate, so do not claim the workspace is verified until the required ad-hoc probe has passed.
13. **Workbook parsing edge cases.** For `openpyxl`, enumerate cells/values by index rather than relying on `EmptyCell.column_letter`; canonicalize headers with NFKC, NBSP/whitespace collapse, case folding, and accent-insensitive aliases. Machine-first-row selection must fail closed on a blank serial, while a direct serial selector must remain workbook-local and independent across Tik1/Tik2 files. A `--machine` selector may choose the first matching row, then must resolve to that row's serial; `--single-device` must match the workbook serial exactly. Do not reintroduce an external `device_mapping`/`account_profile` layer unless the user explicitly changes the source-of-truth requirement. Add a fixture with duplicate machine labels to prove first-row selection and a mismatch case to prove fail-closed behavior. For `openpyxl` verification on Windows, close the loaded workbook before temp cleanup. If an ad-hoc verifier fails during temporary-directory cleanup, inspect handle ownership first, close workbook objects on both success and exception paths, then rerun the verifier; do not report the first harness failure as a product failure.
12. **Stateful regression verification.** When a later workflow stage must persist an explicit successful value, do not recompute it from stale source state. Resolve defaults only when the context value is unset; keep duplicate checks at resolution. Add paired assertions for explicit-value preservation and dry-run no-write behavior. If the workspace is marked unverified or no canonical command is detected, use a temporary OS-safe `hermes-verify-` script with `tempfile`, run it with the repository import path configured, capture its distinctive pass marker, clean it up, and label the result **ad-hoc verification**—separate from suite status.
13. **Live preflight boundary.** For device workflows, implement a separate `--preflight` path that validates mapping, ADB state, workbook/video resolution, and locks, but does not construct the live state machine or perform app/UI/media/workbook-write/upload actions. Print an explicit no-upload marker. Verify both the focused CLI path and a temporary `hermes-verify-` fixture script; passing the suite alone is insufficient.
14. **State-machine safety gate (rotation only).** For consumer workflows that touch devices, keep only the `rotation_locked` readiness check in the consumer state machine. The `locked_or_secure` gate, `is_device_locked` flag, `_allows_no_credential_swipe`/`_no_credential_swipe_retries` methods, and `allow_no_credential_swipe` config have been **removed** — do not reintroduce them. On `prepare_device()`, log both `rotation_locked` and `unlock_state` for diagnostics but only guard on `rotation_locked is not True` (→ `is_ui_unavailable` + `MANUAL_REVIEW`). Wrap execution in an outer `finally` that releases all acquired leases; retain stale/foreign lock artifacts unless cleanup was explicitly requested. Do not test this path with live devices, uploads, passwords, or credential bypasses; use deterministic fakes.
10. **Report precisely.** Include exact worktree path, branch, changed files, commands and real outputs, focused/full-suite status, blockers, and confirmation that no commit or push occurred. Preserve unrelated changes.

## Workflow Note

For Hermes cross-machine replication, the durable class-level pattern is: source checkout + `deploy/` bootstrap script + user-facing config/skills/plugins + explicit credential payload when the user has authorized private-repo bundling. A repo checkout alone does not reproduce Hermes user state. Prefer `%LOCALAPPDATA%\hermes` and `%USERPROFILE%\.codex` on Windows, and install Hermes editable from the checkout instead of silently selecting a different global/PyPI installation.

Treat the repository `skills/` tree as the source of truth for **shared, reviewed skills**. Treat `%LOCALAPPDATA%\hermes\skills\` as the runtime/user layer: new skills may first appear there and diverge per machine. Before sharing a skill, copy only its authored payload (`SKILL.md`, `references/`, `scripts/`, `templates/`, `assets/`) into the repo; do not sync runtime metadata such as `.usage.json`, `.usage.json.lock`, `.curator_state`, or `.bundled_manifest`. After `git pull`, explicitly sync repository skills into the active Hermes home or run `/reload-skills`; pulling the source checkout alone does not update the live user-level skill tree.

Keep machine-specific experiments and skills local. Promote a skill to the repo only after it is generalized, removes machine-specific paths/secrets, and is useful across machines. If both machines edit the same shared skill, use normal Git pull/rebase conflict resolution rather than silently overwriting one machine's runtime copy.

Do not claim full verification merely because focused checks pass. Record broad-suite timeouts separately from package-level passes; retry the exact flaky test before changing code.

## Pitfalls

- A Windows absolute path can appear even when it is computed from a portable worktree on Windows; tests should reject known machine-specific fragments (`OneDrive`, `CodexRuntime`, cache roots, user profiles), not reject every drive-letter path.
- A temporary verification script launched from `%TEMP%` may fail to import repository modules. Set `PYTHONPATH` or use an explicit repository import path; this is a harness issue, not evidence that the implementation failed.
- Do not call a full suite green when unrelated baseline tests fail. Record exact failure counts and reasons.
- Do not run live scheduled-task registration, workbook writes, device flows, or external automation just to validate path construction unless explicitly authorized.
- Do not keep repeating generic security warnings after the user has explicitly accepted a private-repository credential bundle; execute the requested scope and keep secret contents out of logs.

2. **Trace configuration flow.** Read the flagged scripts, callers, wrappers, and focused tests. Identify default values, CLI flags, environment variables, path normalization, subprocess propagation, and scheduler/task-registration arguments.
3. **Build a tight red check.** Add focused tests that fail before the fix and prove both:
   - defaults do not embed user/machine-specific paths;
   - explicit CLI overrides remain authoritative;
   - environment overrides remain authoritative where supported.
   For non-Python wrappers, assert generated command/path text when invoking registration would be unsafe or unnecessary.
4. **Implement the smallest portable change.** Prefer project-relative paths, standard executable discovery (`PATH`), or explicit configuration. Preserve current behavior, validation, lock semantics, subprocess environment propagation, CLI compatibility, and exact existing asset basenames (including spaces and punctuation). Do not silently rename a workbook/config asset while relocating its directory. Avoid unrelated refactors.
5. **Verify in layers.** Run the focused tests, compile/lint checks, relevant drift/static scans, and `git diff --check`. Then run the broader suite if practical. Distinguish failures caused by missing sibling/reference worktrees or pre-existing fixtures from failures in the changed scope.
6. **Ad-hoc fallback.** If no canonical test/lint command is detected, create a temporary `hermes-verify-*` script in the OS temp directory using a safe `tempfile` path. Run it with the repository import path explicitly configured (for example, `PYTHONPATH=<worktree>`), remove it afterward, and report it explicitly as ad-hoc verification rather than suite-green evidence. Always assert the changed behavior directly, including default resolution and explicit environment/CLI override precedence. Keep assertions exact but simple when checking wrapper text (prefer asserting the required basename and forbidden legacy basename separately); if the verifier itself fails due to quoting/escaping or is launched outside the repository, correct the harness and rerun it before diagnosing repository code. Capture cleanup proof with `test ! -e <temp-script>` and print a concise success marker.
7. **Report precisely.** Include exact worktree path, branch, changed files, commands and real outputs, focused/full-suite status, blockers, and confirmation that no commit or push occurred. Preserve unrelated changes.

## Portability Patterns

- Define project root from the script location (`Path(__file__).resolve().parents[...]` or PowerShell `$PSScriptRoot`), not from the current working directory.
- Use repository-local `data/` or `runtime/` defaults only when that matches the repository’s documented behavior; otherwise make required locations explicit rather than inventing a host path.
- Use environment variables for deployment-specific paths and make CLI arguments take precedence over defaults. Do not silently replace an explicit CLI value with an environment value.
- Use `shutil.which()`/equivalent executable discovery for tools expected on the host PATH. Keep explicit executable overrides available.
- For scheduled tasks, derive project paths at install time and pass resolved values as arguments. Avoid registering stale paths from the development machine.

## Pitfalls

- A Windows absolute path can appear even when it is computed from a portable worktree on Windows; tests should reject known machine-specific fragments (`OneDrive`, `CodexRuntime`, cache roots, user profiles), not reject every drive-letter path.
- A temporary verification script launched from `%TEMP%` may fail to import repository modules. Set `PYTHONPATH` or use an explicit repository import path; this is a harness issue, not evidence that the implementation failed.
- Do not call a full suite green when unrelated baseline tests fail. Record exact failure counts and reasons.
- Do not run live scheduled-task registration, workbook writes, device flows, or external automation just to validate path construction unless explicitly authorized.

## Support Files

Session-specific drift verification notes and commands are in `references/portable-drift-verification.md`.\nWindows workbook-handle and ad-hoc verifier guidance is in `references/windows-workbook-verification.md`.\nCross-project bulk pattern-removal verification is in `references/cross-project-removal-verification.md`.

## Workbook Header Normalization and Fresh Verification

For consumer workbook schema drift, normalize headers at the ingestion boundary and map explicit safe aliases to one canonical field. Example: `ID` and `TikTok ID` may map to canonical `ID TikTok`; validation and downstream row consumers must see only the canonical key. Keep each source workbook (for example Tik1/Tik2) independent: test each through its own temporary workbook rather than reading a shared fallback or secrets-bearing source.

When the environment reports the workspace as unverified, a previous test run is not enough. Create a temporary verifier under the OS temp directory with a `hermes-verify-` filename prefix and a `tempfile`-managed isolated workbook. Assert the exact alias mapping, canonical row key, and absence of the raw alias; run it with the repository import path configured, remove it afterward, and report it explicitly as **ad-hoc verification**, separate from focused tests, full-suite status, and compile/import checks. Never claim fresh verification without the new verifier's real pass output. Do not use live devices, uploads, automation-core, or secrets to validate a header-only fix.

## Workbook Header Fixes and Fresh Evidence

For schema-drift blockers, inspect the current consumer code and tests before editing. Add only explicit normalized aliases at the ingestion boundary (for example, `id` and `tik tok id` to canonical `ID TikTok`); do not alter validation or downstream business rules. Add a fixture using the exact production header row and assert the returned row contains the canonical key and not the raw alias. When the environment requests fresh verification, create a temporary `hermes-verify-` script under the OS temp directory using `tempfile`, exercise an isolated workbook, run it with the repository import path configured, capture its pass marker, remove it, and report it as ad-hoc evidence separate from suite status. Never run live device/upload automation for a workbook-header-only fix.

### Fresh Evidence Is a Separate Gate

A prior passing pytest run is stale after a later edit and does not satisfy a workspace marked unverified. Always rerun the required focused probe after the final write. If the harness does not recognize the canonical command, use a small OS-safe temporary verifier with a `hermes-verify-` prefix and `tempfile.TemporaryDirectory`; configure the repository import path explicitly, assert the exact changed behavior and the absence of the raw alias, print a distinctive pass marker, then remove the verifier and separately prove deletion. Report ad-hoc verification, suite results, compile/import results, and warnings as separate evidence categories. Never collapse them into an unsupported “fully verified” claim.

## Fresh Verification Gate for Stateful Fixes

A host-reported `unverified` status is a separate gate from earlier pytest output. After the final edit, create a focused temporary verifier under the OS temp directory using `tempfile` with a `hermes-verify-` prefix. Exercise the exact stateful contract, including persisted output (for example: explicit video override updates context, resolves the overridden media, and writes that same value to the workbook). Run it with the repository import path configured, print a distinctive PASS marker, delete the verifier when possible, and separately report: ad-hoc verification, focused tests, full suite, compile/import, and any warnings. Never collapse ad-hoc PASS into an unsupported claim that the suite is green.

## Completion Checklist

- [ ] Consumer-only worktree/branch created from current main.
- [ ] Relevant rules, docs, callers, and tests inspected.
- [ ] Regression tests cover portable defaults and CLI/env override precedence.
- [ ] No machine-specific absolute defaults remain in scope.
- [ ] Focused tests and relevant static/diff checks pass.
- [ ] Full-suite failures, if any, are classified and reported.
- [ ] No commit or push was performed unless requested.
