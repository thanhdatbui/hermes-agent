# VPN preflight pattern for reconcile scripts

## Required imports
```python
from automation_core.preflight import require_android_vpn, serial_is_mapped_in_workbook
```

## Pattern

Every reconcile entrypoint MUST:

1. **Accept `--proxy-mapping`** argument (default `None` — skips check when not provided).

2. **Before lock acquisition**: no action needed. VPN check runs AFTER lock.

3. **Inside `reconcile_target`**, after acquiring lock:
```python
if proxy_mapping is not None and proxy_mapping.is_file():
    adb = AdbClient(str(adb_path), target.serial, default_timeout=20)
    require_android_vpn(
        adb,
        required=serial_is_mapped_in_workbook(
            proxy_mapping, target.serial,
            serial_headers=("phoneId", "deviceId", "serial"),
        ),
    )
```

4. **In `acquire_device_lock`**, pass `live_vpn_verifier`:
```python
lease = acquire_device_lock(
    ...,
    live_vpn_verifier=lambda s: _check_tun0(adb_path, s),
)
```

5. **After reboot** (`_soft_reboot`), the `verify_post_reboot` callback must re-verify VPN:
```python
def _verify_vpn(adb, target, proxy_mapping):
    if not prepare_device(adb):
        return False
    if proxy_mapping is not None and proxy_mapping.is_file():
        require_android_vpn(
            adb,
            required=serial_is_mapped_in_workbook(
                proxy_mapping, target.serial,
                serial_headers=("phoneId", "deviceId", "serial"),
            ),
        )
    return True
```

## `_check_tun0` helper
```python
def _check_tun0(adb_path: Path, serial: str) -> bool:
    try:
        adb = AdbClient(str(adb_path), serial, default_timeout=10)
        result = adb.shell(["ip", "addr", "show", "tun0"], timeout=10)
        return result.ok and "inet " in str(result.stdout or "")
    except Exception:
        return False
```

## Proxy readiness marker

`automation-core>=0.2.40` adds `wait_for_proxy_ready` inside `acquire_device_lock`. This reads from `~/.codex/device-readiness/<hash>.json`. The Gan proxy watcher writes `proxy_ready` state there. If the watcher hasn't written it yet, pass `live_vpn_verifier` to bypass the wait.
