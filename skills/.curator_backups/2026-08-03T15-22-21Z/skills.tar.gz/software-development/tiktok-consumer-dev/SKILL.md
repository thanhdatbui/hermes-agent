---
name: tiktok-consumer-dev
description: Develop, debug, and run TikTok login/reconcile consumer projects against the shared automation-core. Covers VPN preflight, reboot rules, image-navigation fallbacks, ui-compatibility.md documentation, and common automation-core API migrations.
---

# TikTok Consumer Development

Shared conventions, pitfalls, and workflows for all TikTok login consumer projects under `D:\CodexRuntime\consumer-worktrees\` and `D:\Taadaa\`.

## Before any live device action

1. **VPN gate**: always check `--proxy-mapping` with `require_android_vpn` before inventory or login. The reconcile script must accept and pass `--proxy-mapping` through to `acquire_device_lock` (with `live_vpn_verifier`) and to `_soft_reboot` (`_verify_vpn` callback). See `references/vpn-pattern.md`.

2. **Device lock**: use `acquire_device_lock` with `project="tiktok-log-in"`. The lock now includes `wait_for_proxy_ready`. Pass `live_vpn_verifier=lambda s: _check_tun0(adb_path, s)` to bypass proxy-readiness marker wait when the watcher hasn't written it yet.

3. **Reboot rules**: the user configures rebootable error signatures. After reboot, the device MUST be re-locked and VPN MUST be re-verified before continuing. The `_verify_vpn` callback inside `reboot_and_restore` does this. Use `verification_timeout=300` to give the watcher (30s poll) time to restore VPN.

4. **Documentation**: every UI handle, popup dismissal, coordinate fallback, or selector change MUST be recorded in `docs/ui-compatibility.md` using the contract template. This file lives in the main repo and each worktree. Do NOT use `AUDIT_LOG.md` for UI changes.

## automation-core API migrations

- **0.2.40**: `soft_reboot_and_wait` → `reboot_and_restore`. Callbacks are `Callable[[], object]` (no arguments). Required: `cleanup_before_reboot`, `recover_post_reboot`, `verify_post_reboot`.
- **0.2.40**: `acquire_device_lock` adds `wait_for_proxy_ready`. Pass `live_vpn_verifier` to check `tun0` directly.
- **0.2.44**: `soft_reboot_and_wait` reinstated. Check core version before migrating.
- **0.2.53**: Windows retained-lock takeover correctly detects PID reuse, including protected processes where `OpenProcess` is denied. Consumers that resume `recovery`/`handoff` locks should pin this version or newer.

## Retained lock takeover on Windows

When resuming a target whose previous worker died:

1. Read both machine and serial lock records and verify they describe the same lease.
2. Verify the recorded same-host owner, including process creation time; a matching PID alone is insufficient because Windows can reuse PIDs.
3. Use `acquire_device_lock(..., allow_takeover=True)` so takeover is atomic. Expose a scoped CLI flag such as `--takeover-lock` and thread it to the lock call.
4. Never manually delete/release the old lock before launching the replacement runner; that creates an unlocked race window.
5. Keep readiness/VPN verification before claim, and require the replacement runner to own the lock before any TikTok action.
6. If liveness is indeterminate and creation time cannot be read, fail closed as `SKIPPED_LOCKED`; do not infer that `owner_active=true` proves the process is alive.
7. Regression tests must cover dead owners, live owners, reused PIDs, protected Windows processes, and CLI propagation of `allow_takeover`.

Implementation and reproduction detail: see `references/windows-pid-reuse-lock-takeover.md`.

## Target-machine Python and render-worker provenance

For TikTok build/render/test commands, run the target machine's installed Python and capture real terminal output; do not use Hermes `execute_code` Python as the build/runtime interpreter or fabricate results. Verify `where.exe python` / `py.exe -0p` before using a bare `python`, because the Kibe host can resolve bare `python` to the Hermes venv. Prefer `py -3.12 -u ...` or the confirmed absolute machine Python path.

`--parallel 1` means one FFmpeg process at a time, not one encoder thread. FFmpeg/libx264 may still auto-select many threads; inspect the generated command/log for `threads=N` and `lookahead_threads=N`. For an interrupted render, check for an existing runner/FFmpeg first, reuse the original run-id and seed parameters, and continue without `--overwrite` so valid outputs are skipped and remaining tasks stay deterministic. A Task Manager screenshot is point-in-time evidence; cross-check `tasklist`, full process command lines, run metadata, and output counts. See `references/render-interpreter-and-worker-semantics.md`.

## Image navigation quirks

- `detect_feed_controls` and `detect_profile_screen` may return `None` on SM-G930W8 even when feed is visible.
- `bottom_navigation_point(screenshot, "profile")` is more reliable — use as fallback before declaring navigation surface unavailable.
- `tap_profile` uses `bottom_navigation_point` internally; if it fails, coordinate tap `(972, 1857)` works for 1080x1920.
- Account switcher: `open_account_switcher` canonical (core) may fail; coordinate fallback `tap(540, 552)` + verify `"Chuyển đổi tài khoản"` in XML.

## TikTok version differences

- **v46.x**: legacy flow. Login screen has `"Sử dụng số điện thoại/email/tên người dùng"` → `"Email/tên người dùng"` tab.
- **v44.2.3**: signup screen `"Đăng ký TikTok"` → `"Bạn đã có tài khoản? Đăng nhập"` → login screen `"Đăng nhập vào TikTok"` → same email option.
- Auto-detect new UI: check for Google `AssistedSignInActivity` popup at startup.

## Popup handling (avoid UiAutomator hang)

Use `dumpsys activity` instead of `uiautomator dump` to detect popups. Known patterns:

| Popup | Detection | Dismissal |
|-------|-----------|-----------|
| Consent `"Đồng ý và tiếp tục"` | `UniversalPopupActivity` in dumpsys | `swipe(540,1600,540,400,300)` |
| Google Play ToS | `com.android.vending` + `TosActivity` | `tap(863,1419)` |
| Play Core download | `PlayCoreAcquisitionActivity` | `tap(783,1824)` |
| Google sign-in | `AssistedSignInActivity` | `keyevent 4` (Back) |

## AdbKeyboard

- Broadcast `ADB_KEYBOARD_INPUT_TEXT` may timeout but text still enters. Use fire-and-forget `Popen` with `DEVNULL`.
- On some devices, `input text` works more reliably than broadcast.
- Ensure IME is set: `ime set com.github.uiautomator/.AdbKeyboard`.

## workbook column mapping

- `SERIAL_HEADERS` in `account_inventory.py` must include `"device id"` and `"deviceid"` (the workbook uses column `device ID`).
- Proxy mapping uses `VICHANGER_SERIAL_HEADERS = ("phoneId", "deviceId", "serial")`.

## References

- `references/vpn-pattern.md` — complete VPN preflight integration pattern with code snippets.
