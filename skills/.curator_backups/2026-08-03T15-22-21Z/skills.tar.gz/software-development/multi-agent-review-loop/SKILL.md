---
name: multi-agent-review-loop
description: "Điều phối worker-reviewer với phản biện hai chiều."
version: 1.0.2
author: Hermes Agent
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [multi-agent, coding, review, codex, claude, opencode, orchestration]
    category: software-development
---

# Multi-Agent Review Loop Skill

Skill này điều phối một agent làm code và một agent review/audit theo vòng phản biện hai chiều. Nó không gắn cứng vendor/model, không tự coi `APPROVED` là đủ nếu chưa có bằng chứng test, và chỉ dùng reviewer fallback khi reviewer chính hết quota hoặc provider lỗi.

## When to Use

- Khi cần một coding agent implement rồi reviewer độc lập audit.
- Khi muốn worker đọc finding, chấp nhận hoặc phản biện từng finding.
- Khi cần đổi Codex/Claude/OpenCode/model mà không đổi logic orchestration.
- **Khi user đưa plan/spec có sẵn**: dispatch audit trước, không bao giờ nhảy vào implementation khi chưa có audit + user approval.

## Role Separation (Critical)

Khi user đã giao role rõ ràng (ví dụ: "Codex plan và code, Claude audit và review, Hermes chỉ điều phối"), **TUYỆT ĐỐI KHÔNG tự ý làm thay**:

- **Hermes = Orchestrator**: Chỉ điều phối, dispatch, tổng hợp kết quả. KHÔNG code, KHÔNG audit, KHÔNG review.
- **Codex = Plan + Code**: Dispatch cho planning, architecture, implementation.
- **Claude = Audit + Review**: Dispatch cho audit findings, code review.

### Pitfall: Không tự ý code khi đã giao role

**WRONG**: User giao "Codex code" → Hermes tự write_file/patch vì nghĩ "leaf không thể write file" → phải code trực tiếp.

**RIGHT**: User giao "Codex code" → Hermes dispatch Codex subagent. Nếu subagent role="leaf" không thể write file, đó là vấn đề của **routing**, không phải lý do để Hermes làm thay. Giải pháp: dispatch với role phù hợp hoặc hỏi user, không tự ý nhận việc.

### Workflow đúng

#### Phase 0: Audit Plan trước Implement (khi có plan/spec sẵn)

Khi user đưa plan hoặc spec, workflow BẮT BUỘC:

```text
1. Dispatch CẢ HAI agent song song audit plan:
   - Codex: technical feasibility, architecture gaps, dependency analysis
   - Claude: business logic, edge cases, safety/security, workflow consistency
2. Hermes tổng hợp audit report từ cả 2 → trình user
3. User approve → mới vào Phase 1 implementation loop
4. Nếu user reject/chỉnh → điều chỉnh plan, audit lại, xong mới code
```

**Không bao giờ dispatch implementation khi chưa audit plan và chưa user approval.**

#### Phase 1: Implementation → Review Loop (Kín với user)

Khi plan đã được approve, Hermes chạy vòng lặp kín GIỮA Codex và Claude — không trình user giữa chừng:

```text
1. Hermes dispatch Codex → implement theo approved plan
2. Codex trả về code + logs
3. Hermes dispatch Claude → review code
4. Claude trả về findings (CRITICAL/HIGH/MEDIUM/LOW)
5. ❌ Nếu findings còn → Hermes dispatch Codex → phản biện + fix
6. Codex trả về fix + response cho từng finding
7. Quay lại bước 3 (Claude re-review)
8. Lặp cho đến khi Claude APPROVED
9. ✅ APPROVED → Hermes tổng hợp + trình user kết quả cuối
```

**Quan trọng**: 
- Tuyệt đối KHÔNG hỏi user trong lúc loop. Claude findings → direct to Codex. Codex fix → direct to Claude. Chỉ user thấy kết quả cuối.
- Nếu vòng lặp quá 3 vòng cho cùng 1 finding không đổi → CHANGES_REQUESTED → trình user để quyết định.

## Model Routing for Reviewer

Khi user đã chỉ định model cho reviewer (ví dụ: "Claude audit/review dùng opus-5"), **luân phiên dispatch đúng model**:

```text
reviewer: model=claude-opus-5  # hoặc model user chỉ định
worker: model=codex-mini  # hoặc model mặc định cho coding
```

**Không hardcode model trong logic orchestration.** Model chỉ nằm trong RoleSpec/config khi dispatch. Nếu user thay đổi preference ("từ giờ dùng opus-5"), cập nhật memory và áp dụng ngay lần dispatch tiếp theo.

## Prerequisites

- Git repository và working directory rõ ràng.
- CLI của worker/reviewer đã được cài và xác thực.
- Không cho worker và reviewer cùng sửa working tree trong cùng thời điểm.
- Với Windows CMD, không dùng `\\` để nối dòng; viết một dòng hoặc dùng `^`.

## How to Run

1. Xác định role: `worker`, `reviewer`, `fallback_reviewer`.
2. Cấu hình backend/model theo role; không hardcode vendor trong protocol.
2. Worker implement và ghi report.
3. Reviewer đọc task, diff, test output trước khi đọc report của worker.
4. Worker trả lời từng finding bằng `ACCEPT` hoặc `REJECT`, kèm rationale/evidence.
5. Reviewer re-check phản hồi; lặp tối đa số vòng đã đặt.
6. Chỉ hoàn tất khi reviewer approve và final tests pass.
7. **Không dùng `clarify` tool trong lúc loop — hỏi user giữa vòng phản biện là orchestration sai. Chỉ trình user kết quả cuối.**

## Quick Reference

```text
plan_audit (parallel) → user_approve → implementation → review → finding_response → consensus
```

Khi không có plan sẵn:

```text
plan → audit → user_approve → implementation → review → finding_response → consensus
```

Verdict chính:

```text
APPROVED
CHANGES_REQUESTED
FINAL_BLOCKED
MAX_ROUNDS
```

Fallback chỉ kích hoạt với lỗi được phân loại `quota` hoặc `provider`; không nuốt lỗi task/contract.

## Procedure

### 1. Role-based routing

Dùng interface chung kiểu:

```text
worker.run(task, context) -> implementation result
reviewer.review(task, diff, tests) -> structured verdict
```

Model/backend chỉ nằm trong `RoleSpec` hoặc config. Ví dụ routing có thể là:

```text
worker mặc định: model coding nhanh
worker khi plan/audit/code change: model reasoning cao
reviewer: model độc lập, read-only
fallback reviewer: backend khác khi quota/provider lỗi
```

Không đưa secret vào state/artifact; chỉ persist role name, backend và option keys.

### 2. Review độc lập

Reviewer phải:

- Đọc task/spec và diff thực tế.
- Kiểm tra code path, error path, sibling path và test coverage.
- Không tin self-report của worker trước khi kiểm tra evidence.
- Ghi finding có id, severity, file/location, evidence và required fix.
- Phân biệt blocking với non-blocking; chỉ blocking mới bắt worker sửa.

### 3. Hai chiều

Worker phải trả lời đủ từng finding:

```json
{
  "finding_id": "F1",
  "disposition": "ACCEPT",
  "rationale": "...",
  "evidence": ["tests/..." ]
}
```

Nếu `REJECT`, phải nêu bằng chứng hoặc reproduction; không chỉ nói “không đồng ý”. Reviewer phải phản hồi lại từng `REJECT`, giữ hoặc rút finding, rồi mới quyết định consensus.

### 4. State và recovery

Ghi state sau mỗi phase và artifact riêng theo round. Dùng atomic replace khi ghi JSON. Giới hạn số vòng; nếu cùng finding lặp lại mà không có thay đổi có ý nghĩa, chuyển `FINAL_BLOCKED` thay vì loop vô hạn. Khi resume, kiểm tra task và role configuration có khớp state.

### 5. Verification

Final success cần cả:

```text
reviewer: APPROVED
worker responses: complete
final tests: PASS
```

Nếu wrapper test chuẩn không chạy được do môi trường, chạy focused verification bằng command phù hợp và báo rõ đó là ad-hoc verification, không gọi là suite green.

## Pitfalls

- Không mặc định gọi ba agent; dùng worker + reviewer, fallback chỉ là escalation.
- **Live consumer preflight là một phase riêng, không gộp vào implementation/review**: trước khi chạy thật phải đọc đúng workbook/config source-of-truth, resolve mapping `Máy → serial`, kiểm tra ADB availability và `adb devices -l`, rồi đối chiếu lock theo cả machine và serial.
- **Nhiều workflow workbook là một class-level contract**: nếu consumer phải chạy Tik1/Tik2/Tik3..., mỗi workbook workflow là nguồn độc lập chứa `Máy → device ID/serial → ID TikTok` và các cột tiến độ/video. Thiết kế CLI/config bằng `--workflow-workbook`/`workflow_workbook`, không hardcode Tik1 và không dùng workbook mapping nuôi account để override workflow workbook. Mapping workbook kiểu `May/So Seri/ID` chỉ là nguồn riêng của runner khác; không trộn với workbook tiến độ upload.
- Khi user thay đổi clarification về source-of-truth, cập nhật ngay context của mọi worker/reviewer đang chạy; không để các agent song song implement hai kiến trúc khác nhau. Sau khi worker báo patch, kiểm tra `git diff` thực tế vì self-report có thể nói đã sửa trong khi patch validation thất bại.
- Với consumer live trên Windows, đọc config/entrypoint của sibling đang vận hành để lấy ADB path thực tế (ví dụ `C:\Program Files (x86)\xiaowei\tools\adb.exe`), constructor `AdbClient`, lock semantics và safety flags; sau đó tạo config runtime tạm ngoài repo/OneDrive chỉ chứa path không nhạy cảm.
- Khi consumer phụ thuộc sibling project, đọc entrypoint/config của sibling trước khi chạy để xác định ADB path thực tế, `AdbClient` constructor, lock root, CLI safety flags và cleanup policy; không suy đoán từ scaffold consumer.
- Với Windows, nếu `adb` không nằm trong PATH, lấy `adb_path` từ config chuẩn của sibling (ví dụ Xiaowei platform-tools), rồi chạy `adb -s <serial> get-state` và `getprop` trước live action.
- Workbook mapping phải đọc header thực tế và phân biệt mapping workbook (`May/So Seri/ID`) với workflow workbook (`Máy/device ID/ID TikTok/...`); không dùng mapping workbook thay cho workbook tiến độ upload.
- Lock preflight phải kiểm cả `machine_<n>.lock.json` và `serial_<serial>.lock.json`. Chỉ xoá lock sau khi xác minh PID owner đã chết; không xoá lock process sống chỉ vì user cho phép nếu process đó đang điều khiển cùng pool/device.
- Nếu consumer config còn bắt buộc `account_profile` YAML trong khi business rule cấm `account_profile`, đánh dấu BLOCKED architecture/config mismatch và sửa contract trước live run, không bịa mapping YAML.
- Không báo live run sẵn sàng chỉ vì ADB online; phải xác nhận workbook thật có row, video kế tiếp tồn tại, config trỏ đúng nguồn và lock acquisition thành công.
- Khi user yêu cầu chạy thật 1 máy, bắt đầu bằng preflight đúng 1 máy free; không chọn máy chỉ từ machine-lock nếu serial-lock hoặc runner sibling còn giữ tài nguyên.
- **Không xoá lock của process còn sống chỉ vì user cho phép** nếu process đó là runner đang điều khiển cùng pool/device; quyền xoá chỉ áp dụng sau khi xác định lock stale hoặc có handoff/stop protocol rõ ràng. Nếu ADB chưa sẵn sàng thì dừng ở BLOCKED, không chọn máy dựa trên lock file alone.
- Khi subagent hoặc shell chạy sai thư mục, truyền `workdir`/absolute repo path ngay từ dispatch; không suy đoán CWD.
- Với workbook mapping, đừng suy đoán tên cột: đọc header thực tế trước (ví dụ `May`, `So Seri`, `ID` khác với `Máy`, `device ID`) và chỉ xuất dữ liệu tối thiểu cần cho preflight.
- **Không dispatch implementation khi plan chưa được audit + user approve.** Nếu user đưa plan, dispatch cả Codex và Claude audit song song TRƯỚC. Đợi user approve mới code. Nhảy vào code trước audit là workflow sai.
- **KHÔNG HỎI USER GIỮA VÒNG PHẢN BIỆN**. Khi Claude gửi review findings về, Hermes dispatch ngay cho Codex phản biện/fix — không trình user. Chỉ gửi kết quả cuối cho user khi vòng lặp đã đạt APPROVED. Hỏi user giữa loop làm gián đoạn workflow và bị coi là orchestration sai.
  - **Standing-goal rule**: Khi user nói `/goal`, “làm đến khi xong”, hoặc yêu cầu tự xử lý đến APPROVED, phải coi đó là một loop kín/durable. Không gửi intermediate summaries, không gọi `clarify`, không kết thúc parent turn chỉ vì một child vừa hoàn tất. Dispatch worker → reviewer → fixer → reviewer tiếp tục ngay; chỉ báo user khi APPROVED, FINAL_BLOCKED, hoặc MAX_ROUNDS.
  - Nếu reviewer APPROVED trên snapshot cũ nhưng live preflight hoặc đọc source-of-truth thật phát hiện schema/runtime mismatch mới, verdict cũ bị superseded; mở round mới trên workspace hiện tại, không trình user APPROVED cũ.
  - Với consumer workbook, review phải gồm một preflight đọc workbook thật sau khi code APPROVED: header aliases (`ID` vs `ID TikTok`), numeric Excel cells (`489.0` vs folder `489`), blank/EmptyCell, first-row machine selection, next-video path. Fixture-only approval không đủ cho live readiness.
  - Với live Android workflow, review phải kiểm tra cả hành vi failure: `prepare_device` của automation-core phải nằm sau locks và trước mọi TikTok action; `locked_or_secure`/rotation failure phải dừng trước `OPEN_TIKTOK`; report phải dùng state machine thật và leases phải release idempotently.
  - Nếu live attempt dừng manual, verify workbook unchanged, remote media absent, and both machine/serial locks released/stale before any retry.
  - Không gọi live retry chỉ vì code review APPROVED; chạy preflight target-specific lại sau mỗi production-data fix.

  - Nếu parent session nhận async child results rời rạc/out-of-order, không relay từng kết quả cho user. Gắn mỗi result với snapshot/round; bỏ qua worker cũ chạy theo clarification đã lỗi thời; chỉ dùng chain mới nhất trên working tree thực tế.
  - Nếu user bực vì bị hỏi/cập nhật giữa loop, đó là workflow failure: đóng loop ngay, tuyệt đối không dùng clarify, không gửi status trung gian; chỉ gửi verdict cuối hoặc hard blocker.
  - **Single orchestrator ownership**: Không dispatch nhiều worker cùng sửa một working tree cho cùng một finding. Khi có các child cũ chạy theo clarification đã lỗi thời, đánh dấu/ignore kết quả đó, cập nhật một context chuẩn duy nhất, rồi chạy một worker-fix → reviewer cycle trên diff thực tế.
  - **Evidence gate**: Self-report “đã sửa” không đủ. Sau mỗi worker, đọc `git diff`/file thực tế và chạy targeted reproduction cho finding; nếu patch validation fail hoặc file không đổi, re-dispatch worker với absolute `workdir`/path trước khi reviewer.
- **Immediate closed-loop dispatch**: Khi user yêu cầu loop kín đến `APPROVED`, không gửi bất kỳ intermediate summary nào và không kết thúc parent turn giữa các child process. Sau Codex, dispatch Claude read-only ngay trên snapshot hiện tại; sau `REJECT` hoặc `MINOR_FIXES`, dispatch Codex fix ngay rồi Claude re-review. Chỉ trả lời user sau verdict cuối `APPROVED`, `FINAL_BLOCKED`, hoặc `MAX_ROUNDS`.
- **Review the actual test surface**: Reviewer phải xác định test node bằng cách search trong working tree trước khi chạy focused pytest; không giả định class/test name từ report cũ. Nếu test đã bị renamed/removed, report that fact and review the current equivalent instead of inventing a failure.
- **Separate code blockers from environment noise**: A missing binary or permission warning is not a durable code rule, but a reproducible logic/test failure is still blocking even if other tests pass. Require the reviewer to rerun the exact failing path after each fix, then run the broader suite.
- **Protect pre-existing dirty worktrees**: Before each worker round, capture status/diff and instruct the worker to touch only files relevant to current findings. If an agent reports concurrent edits or patch-validation failure, do not overwrite or “clean” the tree; re-dispatch with absolute workdir and a narrow patch after inspecting the actual file.
- **Workbook/row-parser regression pattern**: For spreadsheet consumers, test both header-only/blank-cell rows and populated rows with posted counts greater than zero. Assert canonical field names and next-video calculation, and separately assert machine-first-row serial validation and per-workbook independence. Include an end-to-end CLI/config override test whose fixture contains the actual next video file. Read the real workbook header before claiming preflight readiness: aliases such as `ID` may be the actual Tik workbook field for `ID TikTok`, while mapping workbooks may use `May/So Seri/ID`; never assume fixture headers match production.
  - **Review verdict gate**: `MINOR_FIXES` vẫn chưa phải hoàn tất nếu finding có thể ảnh hưởng live path. Chỉ `APPROVED` sau khi reviewer đọc diff mới và test pass; không trình user giữa loop.
  - **Concrete signal**: Bạn vừa nhận Claude findings (CRITICAL/HIGH/MEDIUM/LOW). Phản xạ đúng là: dispatch ngay Codex với findings + yêu cầu phản biện. Phản xạ sai là: tổng hợp findings rồi trình user hỏi "làm gì tiếp?" bằng `clarify`. Findings từ Claude → Codex, không phải Claude → user.
  - **Ngoại lệ duy nhất**: Nếu vòng lặp quá 3 vòng cho cùng 1 finding không đổi → CHANGES_REQUESTED → trình user để quyết định.
- **Subagent CWD**: Khi dispatch subagent làm việc trên repo, nếu repo không ở home directory (vd `D:\Taadaa\...`), specify WORKDIR trong context field. Subagent mặc định chạy ở `$HOME`/`%USERPROFILE%`, không phải repo root. Nếu subagent báo "file not found" do sai CWD, re-dispatch với path rõ ràng — không tự ý làm thay subagent.
- **Ad-hoc verification script**: Khi system request ad-hoc verification sau khi sửa code, dùng pattern: `tempfile.gettempdir() + '/hermes-verify-<name>.py'`. Script phải focused vào behavior vừa thay đổi, chạy xong cleanup. Gọi là "ad-hoc verification" chứ không gọi là "suite green".
- **Reviewer phải kiểm tra runtime semantics, không chỉ cấu trúc/test cũ**: Với workflow có dry-run, trace giá trị `dry_run` từ CLI → context → dependency constructors → side-effect methods. Một constructor mặc định `dry_run=True` có thể làm real path silently skip workbook writes dù toàn bộ test cũ pass; bắt buộc thêm regression test cho cả `dry_run=True` (không ghi) và `dry_run=False` (ghi + reopen/verify).
- **Không coi worker summary hoặc reviewer snapshot là final nếu workspace đã tiếp tục thay đổi**: đọc diff/file hiện tại và chạy lại targeted reproduction sau mỗi round. Khi có nhiều child cũ trả kết quả theo clarification lỗi thời, ignore kết quả đó và chỉ dùng một chain worker→reviewer trên snapshot mới nhất.
- **Standing-goal execution**: Nếu user yêu cầu `/goal`, “làm đến khi xong”, hoặc tỏ ra khó chịu vì bị hỏi giữa loop, parent phải giữ orchestration kín: không gửi intermediate summaries, không dùng `clarify`, không kết thúc vì child tạm hoàn tất; tiếp tục dispatch fix→review cho tới `APPROVED`, `FINAL_BLOCKED`, hoặc `MAX_ROUNDS`.
- **Pre-live gate**: Sau `APPROVED`, chạy một preflight riêng cho đúng target: workbook/source-of-truth, first-row machine mapping, serial online qua configured ADB, next-video path, machine+serial locks. Preflight không được mở TikTok, push media, write workbook, hoặc post; live chỉ bắt đầu sau bằng chứng preflight.
- Không cho reviewer sửa code trong flow chính.
- Không chạy blind retry cùng command; mỗi retry phải có recovery/evidence khác.
- Không dùng `\\\\` trong Windows CMD.
- Không nhầm app login với CLI auth/provider config; kiểm tra runtime provider/model bằng smoke test.
- Không đọc report worker trước diff nếu muốn tránh anchoring.
- Không kết luận `APPROVED` chỉ vì test cũ pass.

## Verification

Kiểm tra tối thiểu:

- State/artifact được tạo đúng thư mục.
- Worker trả lời đủ mọi finding.
- Reviewer fallback chỉ chạy khi quota/provider lỗi.
- Vòng lặp dừng ở `APPROVED`, `MAX_ROUNDS` hoặc `FINAL_BLOCKED`.
- Test focused và smoke test runtime đều có output thực tế.

## Support Files

- `references/session-routing.md` — routing model/role và các pitfall CLI Windows đã được rút gọn từ workflow thực tế.
- `references/production-consumer-preflight.md` — checklist bắt buộc sau APPROVED và trước live consumer/device actions.
