---
name: tiktok-login-automation
description: TikTok login automation via ADB — inventory, login, 2FA, UI handling for both legacy (46.x) and new UI.
---

# TikTok Login Automation

## Overview

Automate TikTok login on Samsung Galaxy S7 (SM-G930F/S, 1080x1920) devices. Supports two paths:
1. **Reconcile script** (`scripts/reconcile_tiktok_accounts.py`) — inventory + login missing accounts
2. **Manual ADB flow** — fallback when reconcile script fails (UI mismatch, navigation issues)

## Prerequisites

- ADB at `C:\Program Files (x86)\xiaowei\tools\adb.exe` (user's farm config)
- AdbKeyboard APK at `com.github.uiautomator/.AdbKeyboard` (install from `D:\Taadaa\tiktok-luot nuoi acc\.ai-runs\...\apks\com.github.uiautomator\00_base.apk`)
- Workbook: `D:\OneDrive\Tiktok_Reg\taikhoan_dat_v2_updated .xlsx` (columns: Máy, Tik, ID, PASS, 2FA, GMAIL, PASS MAIL, ..., device ID)
- Source runner: `D:\Taadaa\tiktok-luot nuoi acc`
- Login project: `D:\Taadaa\Tiktok_Reg`

## Project Architecture

```
login_runner/
├── cli.py              # CLI entry (--live mode)
├── executor.py         # Orchestrator: lock → preflight → login flow
├── live_adapter.py     # ADB device adapter (supports legacy + new UI)
├── totp_provider.py    # Workbook-backed TOTP challenge provider
├── account_inventory.py # Device inventory + workbook comparison
├── account_reconcile.py # Inventory → reboot → login → verify
├── models.py           # LoginJob, ExecutionResult, Step, JobStatus
├── contracts.py        # Protocol interfaces
├── dpapi_secret.py     # Windows DPAPI credential storage
└── device_lock.py      # Central machine/serial lock
```

## Code Architecture — `live_adapter.py`

`AdbKeyboardTikTokAdapter` implements `DeviceAdapter` protocol:
1. `open_tiktok()` — wake, force-stop, monkey-start, detect UI version
2. `choose_login_method()` — navigate to username form (legacy or new UI)
3. `submit_identifier()` — type username, tap continue
4. `submit_password()` — type password, tap login
5. `current_challenge()` — detect 2FA or other challenges
6. `submit_challenge()` — type 2FA code, tap continue
7. `current_identity()` — verify profile username matches submitted identifier

### New UI Detection

At startup, check for `AssistedSignInActivity` (Google sign-in popup). If present → dismiss with back key → set `_new_ui = True`.

### New UI Login Flow (TikTok 44.x)

1. **Dismiss post-install consent popup** "Đồng ý và tiếp tục" — appears after app data clear. Swipe UP from bottom: `input swipe 540 1600 540 400 300`. Added in `_dismiss_consent_popups()` and `_start_tiktok_and_wait()`.
2. Dismiss Google sign-in popup if present (back key)
3. **From signup screen ("Đăng ký TikTok"), tap "Bạn đã có tài khoản? Đăng nhập"** ← NOT "Tiếp tục với email" (that's for signup with email, not login!)
4. From login screen ("Đăng nhập vào TikTok"), tap "Sử dụng số điện thoại/email/tên người dùng"
5. Tap "Email/tên người dùng" tab
6. Enter username → tap "Tiếp tục"/"Đăng nhập"
7. Enter password → tap "Tiếp tục"
8. If 2FA: generate TOTP → submit → tap "Tiếp tục"
9. Dismiss post-login popups: "Cho phép truy cập danh bạ?" (tap TỪ CHỐI), "Kiểm tra bảo mật" (tap Đóng)

### Post-Login Privacy Policy (SparkActivity)

On TikTok 44.2.3, after successful login the app shows a mandatory privacy policy in a WebView (`com.bytedance.hybrid.spark.page.SparkActivity`). **UIAutomator cannot see buttons inside WebViews** — the "Agree" button is HTML-rendered. Scroll to bottom (10+ swipes) then tap bottom-center (y ≈ 1700-1850). If still stuck: BACK dismisses without accepting — account won't be fully activated. Known unresolved pattern on SM-G930W8.

### Legacy UI Flow (46.x)

1. Navigate to Profile → open account switcher
2. Tap "Thêm tài khoản"
3. Tap "Bạn đã có tài khoản? Đăng nhập"
4. Tap "Sử dụng số điện thoại/email/tên người dùng"
5. Tap "Email/tên người dùng" tab
6. Enter username/password as above

### 2FA Handling

`WorkbookTotpProvider`:
1. Receives `LoginJob` + `SecretProvider`
2. Gets identifier from secret provider
3. Finds row in workbook matching `(machine, identifier)`
4. Reads 2FA column (TOTP secret, 32-char base32)
5. Generates current code via `pyotp.TOTP(secret).now()`

## Workbook Reading

Workbook uses column `device ID` (not `serial`). `SERIAL_HEADERS` in `account_inventory.py` must include `"device id"`.

Columns: Máy (machine number), Tik (slot), ID (username), PASS, 2FA, GMAIL, PASS MAIL, device ID (serial).

## Manual ADB Flow (fallback)

When reconcile script fails, do manual login per device:

```bash
ADB="C:/Program Files (x86)/xiaowei/tools/adb.exe"
SERIAL="<serial>"

# 1. Check current activity
$ADB -s $SERIAL shell "dumpsys window windows | grep mCurrentFocus"

# 2. Dismiss Google popup if present
$ADB -s $SERIAL shell "input keyevent 4"

# 3. Dump UI to find elements
$ADB -s $SERIAL shell "uiautomator dump /sdcard/window_dump.xml"
$ADB -s $SERIAL shell "cat /sdcard/window_dump.xml" | grep -oP 'text="[^"]*"'

# 4. Enable AdbKeyboard
$ADB -s $SERIAL shell "ime set com.github.uiautomator/.AdbKeyboard"

# 5. Type text
b64=$(echo -n "username" | base64)
$ADB -s $SERIAL shell "am broadcast -a ADB_KEYBOARD_INPUT_TEXT --es text $b64"

# 6. Tap at coordinates
$ADB -s $SERIAL shell "input tap X Y"

# 7. Generate TOTP
python -c "import pyotp; print(pyotp.TOTP('SECRET').now())"
```

## Evidence-Driven Live Recovery (bắt buộc)

### Ngưỡng chuyển từ worker sang guided recovery

- Cho worker chạy **detection/bounded handler** trước và theo dõi bằng `notify_on_complete`; không poll liên tục hoặc nạp toàn bộ log vào context.
- Dừng autonomous worker và chuyển sang guided recovery ngay khi có một trong các dấu hiệu:
  - UI signature chưa có handler đã được chứng minh;
  - UI dump treo, malformed hoặc trả payload non-XML;
  - cùng signature lặp lại sau một recovery có căn cứ;
  - worker chạy lâu nhưng không tạo proof tiến triển;
  - helper nội bộ loop/hang và cần external watchdog.
- Không giao Codex tự chạy lại full flow hàng giờ. Kill **toàn process tree**, không chỉ wrapper, rồi xác minh owner PID chết trước khi takeover orphan lock bằng central lock API.

### Guided loop

1. Giữ/takeover machine+serial lock cho toàn goal.
2. Trước mỗi action: foreground + screenshot + UI XML có watchdog + VPN/lock proof khi liên quan.
3. Classify màn hình/signature thật.
4. Thực hiện đúng **một action**: semantic selector/clickable parent trước; coordinate chỉ khi có screenshot/build/resolution evidence.
5. Recapture và ghi `state trước -> action/selector/tọa độ -> state sau`.
6. Không lặp cùng action nếu evidence không đổi.
7. Khi action thực tế đã qua, mới dispatch Codex đưa fix vào script + regression test; rerun đúng target/bước lỗi.

### Readiness marker timeout không đồng nghĩa VPN hỏng

Khi `acquire_device_lock()` timeout trong `wait_for_proxy_ready()` trước khi worker chạm TikTok:

1. Phân loại đây là lỗi **pre-lock readiness**, không phải lỗi login/UI.
2. Thu riêng `tun0`, `dumpsys connectivity`, foreground, screenshot, XML có watchdog và lock metadata.
3. Nếu `tun0` UP và Android VPN là `CONNECTED/VALIDATED`, marker có thể stale/missing. Reserve recovery bằng `bypass_proxy_readiness=True` chỉ cho bounded diagnosis/action; không dùng bypass cho login bình thường.
4. Consumer phải truyền `live_vpn_verifier` vào cả `acquire_device_lock()` và `soft_reboot_and_wait()`/post-reboot readiness. Verifier nên dùng primitive chuẩn `automation_core.preflight.check_android_vpn(..., required=True).allowed`, không tự regex lại proof.
5. Catch `RuntimeError`/`TimeoutError` phát sinh trước khi lease tồn tại và chuyển thành per-target recovery outcome; không để `future.result()` làm crash toàn batch.
6. Chỉ retry đúng target sau khi recapture chứng minh điều kiện readiness đã thay đổi. Đây mới là meaningful attempt 2.

Nếu foreground đang ở Vi Changer với `No LSPosed access !!!`, phân biệt modal với toast/snackbar bằng XML + screenshot. Chỉ tap exact semantic `OK` node khi XML chứng minh một control clickable duy nhất; recapture sau một action. Toast còn hiện nhưng không có modal không tự động là blocker nếu VPN live vẫn verified.

Chi tiết failure class và recovery ladder nằm trong `references/evidence-driven-reconcile-recovery.md`.

### XML hỏng không đồng nghĩa UI bị chặn

- Nếu screenshot + foreground + VPN vẫn khỏe, XML non-XML chỉ loại bỏ selector XML; **không được tự động kết luận `FINAL_BLOCKED`**.
- Kiểm tra screenshot-guided fallback đã từng chứng minh cho đúng app build và resolution. Dùng vision để xác định bounds, một tap/swipe mỗi vòng, rồi recapture.
- OCR/vision tự do có thể nhầm ký tự username (`i/r`, `z/2`, `v/y`). Khi proof là exact account set, đối chiếu candidate IDs đã scope từ safe workbook, crop/phóng lớn ảnh; nếu vẫn mơ hồ, chọn account dưới lock rồi verify Profile identity. Không tuyên bố exact match chỉ từ một OCR pass.
- `FINAL_BLOCKED` chỉ hợp lệ sau khi cả handler XML/instrumentation phù hợp **và** screenshot-guided handler có evidence (nếu tồn tại) đã cạn meaningful attempts, hoặc gặp hard stop thật.

Reconcile reboot làm watcher miss VPN vì lock collision là một failure class riêng. Nếu reconcile **cố ý giữ lock xuyên reboot**, không được thiết kế nó chỉ chờ watcher lấy cùng lock. Dùng post-reboot callback để parent runner gọi provider proxy hiện có dưới chính retained lock, verify ownership + `tun0` + Android VPN rồi mới tiếp tục. TikTok Profile logged-out phải được phân loại thành inventory rỗng, không phải account-switcher navigation failure. Chi tiết và contract: `references/retained-lock-post-reboot-proxy.md`; ladder takeover sau worker chết vẫn ở `references/evidence-driven-reconcile-recovery.md`; consolidated reproduction/testing notes ở `references/retained-lock-reconcile-recovery.md`. Session reference đầy đủ cho readiness-verifier propagation, TikTok 46.2.x UI layers, semantic anchor `sai`, core wheel integration và `pre_confirmed_xml` handoff: `references/reconcile-retained-lock-and-tiktok46.md`.

### TikTok 46.x overlay và switcher-anchor ladder

Khi Profile/switcher fail, xử lý từng lớp rồi recapture, không rerun full flow:

1. Feed tutorial `Vuốt lên để xem thêm` → vuốt lên đúng một lần.
2. Android `GrantPermissionsActivity` → dùng core detector `packageinstaller_permission`, chọn semantic `Từ chối`/Deny.
3. Google re-login sheet → đóng lớp trên cùng; bounded wait cho loading overlay trước khi đóng.
4. TikTok login modal → chỉ đóng để chẩn đoán Profile nền.
5. Prompt `Lưu thông tin đăng nhập` → chọn semantic `Để sau`/Not now; generic Later không có save-login markers không được tap.
6. Profile logged-out cần đủ ba marker (`Hồ sơ`, `Đăng nhập vào tài khoản hiện có`, clickable `Đăng nhập`) mới được trả inventory rỗng.

Trên TikTok `46.2.3`, override `1080x1920`, anchor tên/chevron có thể là clickable `android.widget.Button` với resource-id suffix `sai` (đã thấy bounds `[36,249][375,330]`). Đây là switcher anchor; person-plus góc phải là Add Friends và phải loại trừ. Sửa resolver trong shared `automation-core.tiktok.account_switcher`, thêm fixture regression, bump/build/install wheel; không thêm consumer coordinate fallback. Với core worktree isolated, chạy `PYTHONPATH=src pytest ...` để tránh vô tình test package venv khác, rồi xác minh resolver trên XML thật sau khi cài wheel.

Sau khi Profile được xác nhận, mọi bridge/provider phải giữ kết quả đó: `profile_xml = open_profile_root(...)` rồi `open_switcher(..., pre_confirmed_xml=profile_xml)`. Không gọi wrapper làm re-dump/re-navigation giữa hai bước; state có thể rơi lại về Home feed và tạo `SWITCHER_ANCHOR_AMBIGUOUS` giả. Áp dụng contract này ở cả consumer inventory bridge và provider login (`Tiktok_Reg`), với regression test xác minh exact kwargs.

Xem thêm `references/reconcile-guided-recovery-patterns.md` cho parent-lock proxy restore, readiness-verifier propagation, popup ladder và completion gate.

### Commit đúng worktree

Trước commit luôn chạy `git worktree list --porcelain`, `git branch --show-current`, `git status --short --branch` trong **path mà user gọi là “tree này”**. Stage file cụ thể; không stage dirty/untracked ngoài scope. Nếu commit nhầm tree, chuyển commit sang đúng branch bằng cherry-pick semantic (resolve handoff theo nội dung của target branch), rồi đưa pointer branch nhầm về commit trước bằng phương án không phá untracked/dirty state.

## Common Gotchas

- **Workbook locked by OneDrive**: Use `openpyxl.load_workbook(..., read_only=True)` or copy to temp first
- **UI XML dump hangs**: UIAutomator can fail on some Samsung devices → use manual ADB
- **Google AssistedSignInActivity**: Always appears on fresh install → dismiss with back
- **Google Play post-install popups** (2026-07-29): On devices where Play Store hasn't been initialized, `force-stop` + `monkey` can trigger Play ToS or PlayCore ("Tải xuống qua Play"). Dismiss by tapping "Chấp nhận" then "Tải xuống qua Play", then re-issue monkey. Handled in `_start_tiktok_and_wait()` via `_dismiss_play_popups()`.
- **2FA required**: New TikTok accounts often require 2FA → read secret from workbook 2FA column
- **Post-login popups**: Contact permission + security check → dismiss both
- **Account switcher navigation fails**: Occurs when device has no accounts logged in (reconcile script expects existing accounts)
- **API mismatch**: `automation-core` may change. Check `pip show automation-core` version. Consumer imports must match installed version (e.g., `soft_reboot_and_wait` → `reboot_and_restore` in 0.2.40)
- **AdbKeyboard broadcast timeout on some devices**: On SM-G930W8, `am broadcast ADB_KEYBOARD_INPUT_TEXT` hangs subprocess (result=-1, never exits). Text still enters correctly — use fire-and-forget with short timeout or `input text <base64>` via shell. Verify with UI dump after.
- **Consent popup after data clear**: Full-screen "Đồng ý và tiếp tục" dismissed by swipe up, NOT tap. Handle in both adapter and inventory startup wait.
- **Profile navigation fallback**: When image-based `tap_profile` fails, use coordinate tap `(972, 1857)` on 1080x1920 devices.
- **automation-core `build_machine_launch_plan` signature drift**: 0.4.19 rejects `max_workers`; 0.4.20+ *requires* it (and `requirements-automation-core.txt` may pin newer than the installed wheel — always verify with `pip show automation-core` / `inspect.signature` before dispatching a batch). Both `scripts/run_social_batch_deferred.py` and `_run_all_targets.py` shim it: `_LAUNCH_PLAN_PARAMS = inspect.signature(build_machine_launch_plan).parameters` then pass `max_workers` only `if "max_workers" in _LAUNCH_PLAN_PARAMS`. Keep this consumer-side pattern — never edit automation-core.
- **Never foreground-sleep-poll a running batch**: interrupting a foreground command (e.g. Ctrl-C on `sleep 90 && tail`) kills the whole background process tree (orchestrator + workers) in the same Hermes session. Use `process(action='wait')` (clamps to ~180s, repeat) or rely on `notify_on_complete`. Detached workers may keep running after the parent dies and leave `owner_active=True` locks whose PID is already dead — always verify by PID liveness, not by `owner_active`.

## Device Lock Convention

- Lock dir: `C:\Users\Kibe\.codex\device-locks\`
- Files: `machine_<N>.lock.json` and `serial_<SERIAL>.lock.json`
- Remove stale locks where PID is dead before starting
- Acquire lock before touching device, release in finally
- **A crashed batch leaks reserved locks**: if the orchestrator dies after `acquire_device_lock` but before `lease.finish()`, every reserved target keeps `machine_<N>.lock.json` + `serial_<SERIAL>.lock.json` with the same dead PID. The next batch then reports every target `SKIPPED_DEVICE_LOCKED`. Cleanup rule: remove a lock only when its `pid` is dead (verify via `tasklist /FI "PID eq <pid>"`) AND its `project` is `Tiktok_Reg` — never touch `tiktok-upload` or other projects' locks. Note `owner_active` stays `True` after parent death, so it is NOT a reliable staleness signal; PID liveness is. Re-runnable cleanup: `scripts/clean_stale_device_locks.py`.
