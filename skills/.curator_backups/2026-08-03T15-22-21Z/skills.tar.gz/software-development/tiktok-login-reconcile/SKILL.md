---
name: tiktok-login-reconcile
description: >
  Debug and fix TikTok login reconcile/inventory failures on Android devices.
  Covers VPN preflight integration, UI compatibility handling (popups, image
  navigation fallbacks), automation-core API migration patterns, and the
  required docs/ui-compatibility.md audit trail.
---

# TikTok Login Reconcile — Debug & Fix Patterns

## Trigger
- User asks to run reconcile/inventory/login on TikTok devices
- Reconcile script fails with navigation/popup/VPN errors
- Need to add new UI compatibility handling

## Project Layout
- Consumer worktree: `D:\CodexRuntime\consumer-worktrees\tiktok-login-vpn-preflight`
- Main repo: `D:\Taadaa\tiktok-log-in`
- Automation-core: installed via pip (0.2.40), source at `D:\Taadaa\automation-core`
- Source runner: `D:\Taadaa\tiktok-luot nuoi acc`
- Login provider: `D:\Taadaa\Tiktok_Reg\tiktok_login_v1.py`

## Mandatory: docs/ui-compatibility.md
**Every UI/popup/VPN/navigation fix MUST add an entry to `docs/ui-compatibility.md`.**
- File is at `docs/ui-compatibility.md` in the repo root
- If missing from worktree, copy from main repo: `D:\Taadaa\tiktok-log-in\docs\ui-compatibility.md`
- Entry format: ID/owner, UI signature, selector/fallback order, safety bounds, post-action verification, regression tests, affected versions
- Also update `reports/AUDIT_LOG.md` with chronological summary

## Debugging Reconcile Failures
When reconcile hangs or fails, debug step-by-step instead of blindly retrying:

1. **Read `docs/ui-compatibility.md` first.** It is the contract of record for recovery order, selector/fallback ownership, and branches that must be preserved. Do not invent a conflicting policy from the live symptom.
2. **Check VPN first**: `adb shell ip addr show tun0 | grep inet`.
3. **Verify watcher reality with four layers**: scheduler/tray state, process tree, a fresh target-specific artifact after the current boot, and live device VPN proof. A scheduled task marked Disabled does not prove a tray-launched watcher is absent; a live watcher process without a fresh machine/serial artifact does not prove reconnect recovery ran.
4. **Test `_start_tiktok_and_wait` in isolation** and identify the exact blocking activity before changing code.
5. **Test Profile navigation semantic/image-first.** Coordinate navigation is only a bounded, resolution-gated fallback with post-action verification; never replace image/core navigation merely because the agent cannot inspect a screenshot.
6. **Call the canonical automation-core account-switcher entrypoint.** It owns Profile-root positioning, required scrolling, sticky identity-header selection, and switcher verification. Do not emulate that sequence with a bare tap unless the documented fallback signature and verification both apply.
7. **Check popups via activity state**: `dumpsys activity activities | grep -E 'mResumedActivity'`.
8. **Read the JSON outcome, not only `DONE`.** Preserve bounded live runs until natural exit unless concrete evidence proves a hang; do not repeatedly kill/restart the same run.

### Recovery ownership correction

- Reconcile inventory/Profile/switcher recovery is an app-level bounded force-stop/relaunch retry. It must not ad-hoc reboot the device.
- Device reboot belongs to the dedicated guarded recovery flow. That flow retains the central lock, waits for boot/unlock, and then waits for fresh watcher/VPN proof before TikTok resumes.
- Never delete another live owner's lock or bypass watcher readiness because `tun0` was previously up.

## Common Failure Signatures & Fixes

### VPN/proxy readiness timeout
- `acquire_device_lock` may wait for a watcher readiness marker. Diagnose the evidence chain before bypassing it: live owner lock, current watcher process tree, fresh target artifact for the current boot, then `tun0` + Android VPN proof.
- `live_vpn_verifier` is appropriate only as a bounded supplement when live VPN proof already exists; it must not hide a missed reconnect event or authoritative `proxy_failed` marker.
- A scheduled task can be Disabled while a tray/supervisor-launched watcher is still running. Conversely, duplicate watcher parent processes can race. Never infer health from scheduler state or process existence alone.
- If reboot completed but no fresh target artifact appears, debug reconnect detection/worker scheduling. If a ready artifact exists without verified proof, debug ViChanger assignment/VPN verification.
- Keep the device lock through guarded reboot recovery; do not make TikTok reconcile own device reboot recovery.

### UiAutomator hang on Samsung
- `navigator.dump_ui()` can hang indefinitely on some Samsung devices
- Use `dumpsys activity activities` to check for popups/text instead
- Never call `dump_ui()` inside a loop without a try/except + timeout

### Image navigation fails on SM-G930W8
- `detect_feed_controls` and `detect_profile_screen` may return None even when feed is visible
- `bottom_navigation_point(screenshot, "profile")` still works → use as fallback for `has_navigation_surface`
- `tap_profile` → coordinate fallback (972, 1857) when image-nav fails
- `open_account_switcher` → coordinate fallback: tap (540, 552), then verify "Chuyển đổi tài khoản" in UI dump

### Post-install consent popup (UniversalPopupActivity)
- Appears after TikTok data clear: "Đồng ý và tiếp tục"
- Dismiss with swipe: `input swipe 540 1600 540 400 300`
- Detect via `dumpsys activity` (NOT uiautomator dump)

### Google Play ToS/PlayCore popups
- Appear after TikTok force-stop on devices with pending Play updates
- `TosActivity`: tap "Chấp nhận" at (863, 1419)
- `PlayCoreAcquisitionActivity`: tap "Tải xuống qua Play" at (783, 1824)
- Detect via `current_package == "com.android.vending"` in activity dump

### Workbook column compatibility
- `account_inventory.py` SERIAL_HEADERS must include `"device id"` and `"deviceid"` for workbooks using that column name
- Proxy mapping uses VICHANGER_SERIAL_HEADERS = `("phoneId", "deviceId", "serial")`

## AdbKeyboard Patterns
- Broadcast `ADB_KEYBOARD_INPUT_TEXT` with base64 text extra
- On some devices (SM-G930W8), broadcast times out but text still enters → use `subprocess.Popen` fire-and-forget
- Alternative: `adb shell input text <plaintext>` works on most devices (no special chars)
- Enable: `ime enable com.github.uiautomator/.AdbKeyboard && ime set ...`

## VPN Integration Flow
1. Reconcile script needs `--proxy-mapping` argument
2. `reconcile_target` checks VPN after lock acquisition
3. After reboot, `_verify_vpn` waits for `tun0` (verification_timeout=300s for watcher's 30s poll)
4. When VPN is mapped, **skip the switcher-refresh reboot** — reboot kills VPN and the watcher may be disabled
5. Use `live_vpn_verifier=_check_tun0` in `acquire_device_lock` to bypass proxy readiness marker wait

## automation-core 0.2.40 API Migration
- `soft_reboot_and_wait(adb, serial=..., boot_timeout=..., proxy_timeout=...)` → removed
- New: `reboot_and_restore(adb, *, cleanup_before_reboot, recover_post_reboot, verify_post_reboot, boot_timeout=180, verification_timeout=120)`
- Callbacks are `Callable[[], object]` — no arguments, use closures to capture `adb`
- Example verify callback: `lambda: _verify_vpn(adb, target, proxy_mapping)`

## Coordinate Login Fallback
When Tiktok_Reg provider `login_one_account` fails (image nav), use coordinate-based flow:
```
Signup → "Bạn đã có TK? Đăng nhập" (540,1830)
→ "SDT/email/username" (561,851) → Tab Email (713,288)
→ input text <username> → Tiếp tục (540,1681)
→ input text <password> → Tiếp tục (540,1681)
→ dismiss security popup (996,923)
```
Use `adb shell input text` — broadcast may timeout.

## Pre-commit Checklist
- [ ] `python -m pytest tests/ -q` passes (ignore pre-existing `TIKTOK_REFERENCE_ROOT` failures)
- [ ] Entry added to `docs/ui-compatibility.md` with full contract
- [ ] Entry added to `reports/AUDIT_LOG.md`
- [ ] `git diff --check` clean
- [ ] All coordinate fallbacks have safety bounds (resolution check, marker verification)
