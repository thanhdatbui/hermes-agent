---
name: android-device-automation
description: Patterns for automating Android devices — VPN preflight, TikTok login flows, UI popup handling, AdbKeyboard input, and reconcile workflows across consumer repos.
---

# Android Device Automation

General patterns for automating Android devices (Samsung SM-G930 series) in consumer
repos that depend on `automation-core`. Covers TikTok login, account inventory,
VPN/proxy preflight, popup dismissal, and the reconcile workflow.

## VPN / Proxy Preflight (MANDATORY)

Before ANY device interaction after a reboot, the VPN must be connected. The
workbook `PROXYgandienthoai.xlsx` maps serials to proxy requirements.

```python
from automation_core.preflight import require_android_vpn, serial_is_mapped_in_workbook
from automation_core.adb import AdbClient

adb = AdbClient(adb_path, serial, default_timeout=20)
require_android_vpn(
    adb,
    required=serial_is_mapped_in_workbook(
        proxy_mapping_path, serial,
        serial_headers=("phoneId", "deviceId", "serial"),
    ),
)
```

This check MUST run:
- After acquiring device lock, before any device action
- In the `verify_post_reboot` callback of `reboot_and_restore`

If the proxy watcher (`gan-proxy/scripts/vi_c`) holds a lock, the device is NOT
ready — skip or wait; never force-run without VPN.

## Consent / Popup Dismissal

After TikTok data-clear or fresh install, multiple popups can appear:

### UniversalPopupActivity (consent popup)
- **Activity**: `UniversalPopupActivity`
- **Detection**: use `dumpsys activity activities` (NOT `uiautomator dump` — it hangs on Samsung)
- **Dismissal**: swipe up from bottom

```python
activities_text = str(adb.shell(["dumpsys", "activity", "activities"]).stdout)
if "UniversalPopupActivity" in activities_text:
    adb.shell(["input", "swipe", "540", "1600", "540", "400", "300"])
```

### Google Sign-In Popup
- **Activity**: `AssistedSignInActivity` (package `com.google.android.gms`)
- **Dismissal**: back key

### Google Play Post-Install Popups (2026-07-29)
After `force-stop` + `monkey start`, Google Play Store may show on devices where it hasn't been fully initialized (first-time setup after factory reset):
1. **ToS**: `com.android.vending/...TosActivity` — "Điều khoản dịch vụ" with "Chấp nhận"/"Từ chối". Tap "Chấp nhận".
2. **PlayCore**: `com.android.vending/...PlayCoreAcquisitionActivity` — "TikTok cần tải các tệp bổ sung". Tap "Tải xuống qua Play".

Detection: check `current_package == "com.android.vending"` in the startup wait loop. After dismissing, re-issue `monkey -p <pkg> 1`. Handled by `_dismiss_play_popups()` in `account_inventory.py`.

### Profile Navigation Fallback
When `navigator.tap_profile(screenshot)` (image-based navigation) fails, fall back to coordinate tap:
```python
navigator.tap(972, 1857)  # Profile tab bottom-right at 1080x1920
```

## TikTok UI Versions

| Version | Signup → Login path |
|---------|-------------------|
| 46.x (legacy) | Account switcher → Add account → "Sử dụng số điện thoại/email/tên người dùng" → Email tab |
| 44.2.3 (newer) | Account switcher → Add account → "Bạn đã có tài khoản? Đăng nhập" → "Sử dụng số điện thoại/email/tên người dùng" → Email tab |
| 37.x (machine 7) | Signup screen → back once → "Tiếp tục với email/tên người dùng" |

**Rule**: The `choose_login_method` code in the adapter must NOT hardcode one path.
Always check for text presence and fall through. The signup screen has both
"Tiếp tục với email" (signup) and "Bạn đã có tài khoản? Đăng nhập" (login link at bottom).

## AdbKeyboard Text Input

- **IME**: `com.github.uiautomator/.AdbKeyboard`
- **APK source**: `D:\Taadaa\tiktok-luot nuoi acc\.ai-runs\*\app-sync\source_60\apks\com.github.uiautomator\00_base.apk`
- **Send text**: `am broadcast -a ADB_KEYBOARD_INPUT_TEXT --es text <base64>`
- **Pitfall**: On SM-G930W8, broadcast returns `result=-1` and ADB shell hangs after broadcast. Text IS entered successfully though — use fire-and-forget with short timeout (5-8s), don't wait for shell exit.
- **Alternative**: `adb shell input text <base64>` only works if AdbKeyboard is active IME, and the plain-text form can leak special chars. Prefer broadcast.

## 2FA / TOTP

TikTok accounts may require 2FA. The TOTP secret is stored in the tracking workbook
column `2FA`. Use `pyotp` to generate codes:

```python
import pyotp
code = pyotp.TOTP(totp_secret).now()
```

Codes expire every 30s — generate and submit immediately (don't generate ahead of time).

## Post-Login Popups

After successful login, dismiss these popups in order:
1. "Cho phép TikTok truy cập vào danh bạ?" → tap "TỪ CHỐI"
2. "Hãy cùng kiểm tra bảo mật nhanh nhé" → tap "Đóng" (top-right corner)
3. Privacy policy (`SparkActivity`) → scroll to bottom, tap "Agree"/"Đồng ý" (rendered in WebView, not detectable by uiautomator — use coordinate taps at y=1700-1850 after heavy scrolling)

## Reconcile Script Patterns

The reconcile script (`scripts/reconcile_tiktok_accounts.py`) does:
1. Acquire device lock
2. VPN preflight (with `--proxy-mapping`)
3. Inventory device accounts via `collect_device_inventory`
4. Compare with workbook
5. Login missing accounts
6. Verify

If inventory fails with a rebootable error, soft-reboot and retry. The `_soft_reboot`
function MUST pass `proxy_mapping` to `reboot_and_restore`'s `verify_post_reboot`
callback, which calls `require_android_vpn`.

### Parent-held lock across reboot

If reconcile intentionally retains the machine+serial lock across reboot, it must not merely wait for a proxy watcher that needs the same lock. Use `reboot_and_restore(..., wait_for_proxy_ready_after_reboot=...)` so the parent invokes the existing proxy provider under its own lease, then verify `tun0` plus Android VPN. The provider must verify the parent PID/host/machine/serial/lock-id before loading the scoped mapping; never expose the proxy through argv/logs.

When using `acquire_device_lock(..., live_vpn_verifier=fn)`, ensure the core version propagates `fn` into `wait_for_proxy_ready`. A stale `proxy_pending` marker plus `verifier_calls=[]` is evidence of a propagation regression. Fix in isolated automation-core worktree, use the merge guard, bump from the current version, run tests with `PYTHONPATH=src`, build/verify/install the wheel between live runs, then live-probe lock acquisition.

## automation-core API Notes (v0.2.40+)

- `reboot_and_restore(adb, *, cleanup_before_reboot, recover_post_reboot, verify_post_reboot, boot_timeout=180)` — all 3 callbacks are REQUIRED keyword-only args
- `wait_until_unlocked(adb)` — use as `recover_post_reboot`
- `prepare_device(adb)` — returns `DeviceReadiness`; use inside `verify_post_reboot` (or wrap with VPN check)
- `soft_reboot_and_wait` was REMOVED in v0.2.40; use `reboot_and_restore` instead

## SM-G930 Model Differences

| Model | Behavior |
|-------|----------|
| SM-G930F | Standard. Broadcast works normally. |
| SM-G930W8 | Broadcast hangs shell. Swipe-unlock pattern may differ. |

## Reference Files

- `references/tiktok-coordinates.md` — exact coordinates, resource-ids, workbook paths, and popup dismissal patterns (verified 2026-07-29)

## Pitfalls

- **Never** use `uiautomator dump` to check for popups in startup loops — it hangs on Samsung when UiAutomation service is busy. Use `dumpsys activity` instead.
- **Never** run device actions without VPN preflight after a reboot. The proxy watcher needs time to assign proxy.
- **Never** tap "Tiếp tục với email" on the signup screen — that's for creating NEW accounts. Tap "Bạn đã có tài khoản? Đăng nhập" at the bottom.
- ADB `keyevent 26` is POWER — toggles screen ON/OFF. Use `keyevent 82` (MENU) to wake without risk of turning screen off.
