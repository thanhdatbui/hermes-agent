---
name: consumer-scheduler-orchestration
description: Build per-consumer-repo schedulers that call existing scripts at fixed daily slots, share a base from a central library, respect device-lock pre-flight, and expose a unified tray. Covers dry-run semantics, optional-dep imports, lock policy, and ad-hoc verification.
tags:
  - scheduler
  - device-lock
  - consumer-repos
  - tray-icon
  - orchestration
  - time-windows
  - pystray
triggers:
  - "scheduler cho nhieu consumer repo"
  - "unified tray quan ly nhieu scheduler"
  - "time windows voi device lock"
  - "copy gmail_scheduler pattern sang TikTok"
  - "build scheduler with slot times + reserved blocks"
---

# Consumer Scheduler Orchestration

Pattern cho viec xay dung nhieu scheduler moi cai trong 1 consumer repo, chung 1 base module tu central library (`automation_core.scheduler`), voi device lock pre-flight, lock policy, va unified tray.

## Khi nao dung

- Co nhieu consumer repo moi cai co 1 script chay, can gioi lich chay theo slot (09:30, 14:00, ...)
- Can 1 shared library de tranh duplicate state/log/device-lock code
- Can unified system tray de start/stop/status tat ca schedulers
- Can lock policy ro rang: success → release, crash/timeout → handoff

## Architecture

```
automation-core/src/automation_core/scheduler/
├── __init__.py              # exports
├── time_windows.py          # AVAILABLE_SLOTS, RESERVED_BLOCKS, WORK_START/END, is_available(), get_slot_time()
├── base.py                  # SchedulerConfig dataclass + serve() + run_consumer() + state/log helpers
└── tray.py                  # SchedulerManager + pystray icon (deps optional)

<consumer-repo>/scheduler.py # thin wrapper: 1 config, calls existing script
```

## Steps

### 1. Central base module (automation_core/scheduler/base.py)

Dung `SchedulerConfig` dataclass de moi consumer chi can khai bao:
- `name` — slug (e.g. "tiktok_reg")
- `project` — device-lock project label
- `slot_hour` / `slot_minute` — thoi diem chay
- `command_builder` — callable(root) -> list[str] goi script co san
- `project_root` — duong dan consumer repo

Shared helpers tu base.py:
- `read_state()` / `write_state()` — atomic via tmp+rename
- `append_log()` — JSONL voi timestamp/event/host
- `choose_run_at()` / `next_plan()` — schedule next slot
- `_device_lock_available()` — pre-flight check (non-fatal)
- `run_consumer()` — subprocess voi timeout + lock policy
- `serve()` — main loop (poll → wait → run → plan tomorrow)
- `build_parser()` / `main()` — CLI wrapper

### 2. Consumer scheduler.py (thin wrapper)

```python
from automation_core.scheduler.base import SchedulerConfig, main as base_main

def build_command(project_root):
    return [sys.executable, str(project_root / "path/to/existing_script.py")]

def build_config():
    return SchedulerConfig(
        name="tiktok_reg", project="tiktok-reg",
        slot_hour=9, slot_minute=30,
        command_builder=build_command, project_root=PROJECT_ROOT,
    )

def main(argv=None): return base_main(build_config(), argv)
if __name__ == "__main__": raise SystemExit(main())
```

### 3. Unified tray (automation_core/scheduler/tray.py)

- `SchedulerManager` doc `processes: dict[str, Popen]`
- Start/stop via `subprocess.Popen` voi `--live` flag
- Read state.json per scheduler de hien status
- pystray icon voi menu: Start All / Stop All / View Status / Quit

## Pitfalls

### P1: `--dry-run` phai exit ngay, KHONG vao serve loop

```python
# WRONG — dry-run bi nested ben trong `if now >= planned`, bi block neu slot chua den
if args.once or force_run or now >= planned:
    if args.dry_run:
        ... return 0

# CORRECT — dry-run check TREN CUNG cua loop, truoc bat ky logic nao khac
while True:
    ...
    if args.dry_run:
        append_log(...); print(...); return 0
    if args.once or force_run or now >= planned:
        ...
```

Neu khong fix, `--dry-run` se timeout vi cho slot toi.

### P2: Optional deps (pystray/Pillow) KHONG duoc `sys.exit()` khi import fail

```python
# WRONG — lam bay import cua bat ky module nao dung tray.py
try:
    import pystray
except ImportError:
    print("ERROR: ..."); sys.exit(1)  # <-- giet ca process

# CORRECT — defer check den runtime
try:
    import pystray
    _HAS_TRAY_DEPS = True
except ImportError:
    _HAS_TRAY_DEPS = False

def create_tray_icon(manager):
    if not _HAS_TRAY_DEPS:
        raise RuntimeError("pystray required. pip install pystray Pillow")
```

### P3: Test expectations phai biet state.json co ton tai hay khong

Sau khi chay `--dry-run`, scheduler DA write state.json voi `status: "planned"`. Test ma mong doc `"not_started"` se FAIL.

Fix: test tren 1 scheduler name khong ton tai (e.g. "test_nonexistent_scheduler") hoac xoa runtime root truoc khi test.

### P4: Device lock IMPORT la FAIL-FAST (mandatory), pre-flight la non-fatal cho missing device

Co 2 layer khac nhau — KHONG duoc nhap lan:

**Layer 1: Import — FAIL-FAST (mandatory)**

```python
# WRONG — silent bypass cho phep scheduler chay MA KHONG CO device lock
try:
    from automation_core.device_lock import DeviceLock, ...
except ImportError:
    DeviceLock = None  # <-- NGUY HIEM: scheduler bypass lock → conflict

# CORRECT — raise ngay lap tuc
try:
    from automation_core.device_lock import DeviceLock, DeviceLockUnavailable, device_lock_paths
except ImportError as exc:
    raise ImportError(
        "automation_core.device_lock is required but could not be imported. "
        "Install automation_core or ensure it's on sys.path. "
        "Silent bypass is disabled to prevent device lock conflicts."
    ) from exc
```

**Layer 2: Pre-flight check — non-fatal cho missing device env vars**

```python
def _device_lock_available(cfg):
    # Module imported (fail-fast o tren) — khong check DeviceLock is None nua
    machine = cfg.machine or os.environ.get("CODEX_DEVICE_MACHINE")
    serial  = cfg.serial  or os.environ.get("CODEX_DEVICE_SERIAL")
    if not machine and not serial:
        return True  # Khong co device nao → khong can lock → allow
    ...
```

Pre-flight return True khi khong co machine/serial env vars (khong co device de lock). Module import la mandatory.

### P7: JSONL append can file locking (Windows race condition)

Windows KHONG atomic append cho file mo dong thoi. 2 scheduler process cung ghi vao 1 JSONL → interleaved/corrupted lines.

Fix: exclusive file lock truoc moi write — cross-platform:

```python
def _lock_file(handle):
    if sys.platform == "win32":
        import msvcrt
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)

def append_log(path, event, **fields):
    ...
    handle = path.open("a", encoding="utf-8")
    try:
        _lock_file(handle)
        handle.write(line)
        handle.flush()
    finally:
        _unlock_file(handle)
        handle.close()
```

Pitfall: `msvcrt.locking` lock 1 byte (LK_NBLCK, count=1) — du cho append mode. KHONG dung `LK_LOCK` (blocking) vi co the hang neu process khac crash giua lock.

### P5: Lock policy — phan biet "completed normally" vs crash/timeout

```python
# completed/failed → release (day la "normal completion" du exit code != 0)
# timeout/crashed → set_status("handoff") (giu lock de recovery khac takeover)

if status in ("completed", "failed"):
    lease.release()
else:
    lease.set_status("handoff")
```

### P6: Choose_run_at phai nhan du ca date, datetime, va string

```python
def choose_run_at(cfg, day):
    if isinstance(day, datetime): day = day.date()
    elif not isinstance(day, date): day = date.fromisoformat(str(day))
    ...
```

## Consumer startup contracts: core readiness before app logic

For any consumer state machine that controls TikTok or another device app, make the app-neutral core readiness call the hard boundary before app-specific logic. The intended sequence is `ACQUIRE_LOCKS -> CONNECT_DEVICE/PREPARE_DEVICE -> OPEN_APP -> DISMISS_POPUPS -> ACCOUNT_SWITCHER -> DISMISS_POPUPS -> ACCOUNT_READY`. `prepare_device` should own wake, credential-free swipe, rotation lock, and readiness verification; the consumer must pass explicit safe options and must not duplicate the call in later TikTok handlers. Treat `locked_or_secure` and failed rotation verification as terminal readiness failures routed to manual review before app launch. Add tests for exact transition order, prepare call count/options including configured rotation, and both readiness failure gates. If retries reset the state machine, reset preparation and adapter/ADB state together so a stale idempotence flag cannot skip setup.

## Consumer workflow failure gates and lock cleanup

For consumer workflows that drive devices or accounts, readiness is a hard gate, not a warning. If preparation reports `locked_or_secure`, or UI dump/profile confirmation is unavailable, stop before app launch/account switching, record a stable error code plus last state in checkpoint/report, and avoid retrying the same job blindly. Never let a broad exception handler convert account-switcher failure into success. Keep `FAILED` and `MANUAL_REVIEW` distinct.

Lock cleanup must be idempotent and independent of reaching the nominal `RELEASE` state: release every acquired lease on failure paths, clear the local lease reference after release, and never delete a live lock merely because a run failed. Consumer-specific policy belongs in the consumer repo; do not patch automation-core/sibling repos for a consumer orchestration defect.

## Fresh-verification protocol when Hermes evidence is stale

If the workspace verifier reports `unverified` or stale evidence after edits, do not rely only on an earlier pytest result. Create a focused temporary verifier under Windows `%TEMP%` using `tempfile` and a `hermes-verify-` prefix. Exercise the changed behavior with real temporary fixtures, explicitly label the result **ad-hoc verification** (not suite green), and delete the script afterward when possible. For dry-run/runtime-mode fixes, assert both dependency flag propagation and the observable side effect in each mode. If pytest passes but cannot write `.pytest_cache`, report that as an environmental warning, not a functional failure.

### Workbook numeric path values

Excel/openpyxl may return an identifier-like folder cell as `float` (`489.0`). Preserve the raw value at the caller boundary and let the shared resolver canonicalize it (`489.0` → `"489"`) before path construction. Do not stringify first (`str(489.0)` → `"489.0"`), which creates a false missing-folder failure. Regression coverage should use a real temporary workbook containing `489.0` and exercise the CLI/preflight seam with fake ADB/lock dependencies; never require a live device or upload.

## Verification pattern (ad-hoc)

Tao script `C:\Users\<user>\AppData\Local\Temp\hermes-verify-<topic>.py`:
1. Test constants (slot times, reserved blocks)
2. Test time math (03:00 → next=08:00; 12:30 → next=14:00; 23:00 → unavailable)
3. Test state round-trip voi tempfile (khong de lai .tmp)
4. Test `--dry-run` subprocess cho TUNG consumer (timeout 15s)
5. Test tray imports KHONG sys.exit
6. Test `create_tray_icon()` raises RuntimeError khi deps missing
7. Clean runtime root (`~/.codex/tiktok-schedulers`) truoc va sau

```bash
python "C:/Users/<user>/AppData/Local/Temp/hermes-verify-schedulers.py"
rm -rf ~/.codex/tiktok-schedulers  # clean state artifacts from --dry-run
rm C:/Users/<user>/AppData/Local/Temp/hermes-verify-schedulers.py
```

## CLI usage

```bash
# Test slot assignment
python scheduler.py --dry-run
# Output: [DRY-RUN] tiktok_reg: planned at 2026-07-26T09:30:00+07:00

# Run for real (requires --live safety gate)
python scheduler.py --live

# Run once and exit
python scheduler.py --live --once

# Force run bypassing clock window
python scheduler.py --live --run-now

# Tray (requires pystray + Pillow)
python automation_core/scheduler/tray.py
```

## Reference implementations

- Base scheduler: `D:\Taadaa\automation-core\src\automation_core\scheduler\base.py`
- Time windows: `D:\Taadaa\automation-core\src\automation_core\scheduler\time_windows.py`
- Tray: `D:\Taadaa\automation-core\src\automation_core\scheduler\tray.py`
- Example consumer: `D:\Taadaa\Tiktok_Reg\scheduler.py`
- Lock policy source: `D:\Taadaa\automation-core\src\automation_core\device_lock.py`
