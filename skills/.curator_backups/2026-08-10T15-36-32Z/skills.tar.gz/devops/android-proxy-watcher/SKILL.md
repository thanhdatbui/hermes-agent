---
name: android-proxy-watcher
description: Run and debug Android proxy/VPN reconnect watchers with central locks, scheduler supervision, and proof-based verification.
---

# Android Proxy Watcher

Use this skill when a local Android fleet watcher should restore proxy/VPN after boot, reconnect, or ADB recovery; or when a scheduler/task says it is running but a target remains without VPN.

## Required evidence chain

Do not call a watcher healthy merely because a wrapper exits successfully or its process exists. Verify four layers independently:

1. **Scheduler task:** query task state, enabled flag, last result, and task action.
2. **Watcher process tree:** confirm tray/supervisor → launcher → watcher worker command, start times, and expected mapping/runtime arguments.
3. **Target event:** inspect a current-run, target-specific reconnect/startup artifact or result. Confirm the artifact machine and serial match the requested target.
4. **Device proof:** verify the intended VPN interface is UP and Android connectivity exposes a VPN-connected state. Wi-Fi `CONNECTED` / `NOT_VPN` is not success.

A `DONE: result=...` line only identifies an artifact to read; it does not mean the target succeeded.

## Device lock protocol

- Acquire the central machine+serial lock before a manual proxy assignment or reboot.
- Never delete another owner's lock. For a stale `recovery`/`handoff` lock, verify the same-host PID is dead, then use the lock implementation's explicit takeover mechanism.
- A proxy recovery reboot may need to acquire its lock without requiring an already-ready VPN. Use the shared lock API's documented proxy-readiness bypass only for the bounded recovery action; preserve normal readiness gating for normal device work.
- Release the reboot lease only after boot-complete and wake/swipe preparation. The watcher must then acquire its own per-event lease.

## Watcher event behavior

For each startup/reconnect event:

1. Refresh target mapping safely and ensure machine/serial have not changed.
2. Acquire a per-event lock; do not hold device locks while idle.
3. Permit explicit safe takeover for a dead eligible retained lock, relying on the central lock policy to reject live owners.
4. Use a bounded wait for a live owner. On expiry, append `SKIPPED_DEVICE_LOCKED`, do not call proxy/VPN assignment, release/avoid retaining the lease, and return to the reconnect loop.
5. Capture sanitized ready and verified artifacts around proxy assignment.
6. Mark success only after actual VPN proof; otherwise classify the failure, run one evidence-based handler, and preserve the final artifact.

## Debugging a missed reconnect

When the watcher is live but a rebooted target has no VPN:

1. Check whether the current watcher runtime contains a new artifact for the exact target after its boot timestamp.
2. If there is no target artifact, investigate reconnect detection / worker scheduling rather than ViChanger or VPN assignment.
3. If there is a ready artifact but no verified artifact, inspect proxy assignment and VPN proof path.
4. If there is `SKIPPED_DEVICE_LOCKED`, inspect lock owner/state and bounded timeout behavior. Do not retry assignment over an active owner.
5. Keep results for concurrent machines separate; a newer artifact for another machine is not evidence for the target.

**Watcher task exists but watcher is NOT running (2026-08-05):** the Windows
logon task `TikTokAllSchedulerTray` existed with `Status: Ready` but `Last
Result: 267014` (0x41306 = task was terminated / did not complete) → no
`gan_proxy_fleet.py watch` process was spawned, so rebooted machines never got
VPN. Evidence ladder:

```bash
schtasks /Query /TN "TikTokAllSchedulerTray" /FO LIST /V | grep -E "Last Result|Status"
wmic process where "Name='python.exe'" get ProcessId,CommandLine | grep -i gan_proxy   # EMPTY = watcher dead
```

Fix = re-run the tray with the exact command from the task XML
(`schtasks /Query /TN "TikTokAllSchedulerTray" /XML`, `<Arguments>`) as a
background process; verify new watcher processes appear with fresh PIDs and the
target gains `tun0` + `inet` within ~1 min. Note: `schtasks //Query` (double
slash) fails in git-bash — use single-slash `schtasks /Query`.

**Manual watcher relaunch (2026-08-05):** when re-running by hand, `watch`
REQUIRES exactly one of `--all` or `--machines` (bare `watch --mapping ...`
exits `BLOCKED: choose exactly one of --all or --machines`). Working command
from `D:\Taadaa\gan-proxy` (note PYTHONPATH must include BOTH `gan-proxy` and
`automation-core\src` — the watcher imports core symbols):

```bash
env -i HOME="$HOME" USERPROFILE="$USERPROFILE" \
  PATH="/c/Users/Kibe/AppData/Local/Programs/Python/Python312:/c/Windows/System32" \
  PYTHONPATH="D:\Taadaa\gan-proxy;D:\Taadaa\automation-core\src" \
  python -u scripts/gan_proxy_fleet.py watch --all \
  --mapping "D:\OneDrive\codex_gmail_debug\PROXYgandienthoai.xlsx" \
  --adb "C:\Program Files (x86)\xiaowei\tools\adb.exe" \
  --runtime "D:\CodexRuntime\codex_gmail_debug-gan-proxy" --poll-interval 15
```

Then **reboot a mapped machine to prove auto-recovery**: the watcher relaunches
`vn.vichanger.app` and `tun0` returns within ~1–2 min (57 came back on first
poll; 62 took a second poll cycle). `pidof vn.vichanger.app` + `ip addr show
tun0 | grep -c 'inet '` are the device-side proofs. The watcher process PID is
the `python.exe` one (find via `wmic ... | grep gan_proxy`), NOT the bash
wrapper PID the terminal reports.

**`cockpit-cliproxy.exe` is NOT the proxy watcher (user correction, 2026-08-05):**
a running `cockpit-cliproxy.exe` (Antigravity Cockpit quota sidecar, args point
at `.antigravity_cockpit\...\quota-reserve.json`) looks like a proxy process but
has nothing to do with Gan Proxy. Do not report "watcher is running" because
cockpit-cliproxy exists — that was a wrong diagnosis in-session. The ONLY valid
watcher process is `gan_proxy_fleet.py watch` (or its `run` fleet mode); check
with `wmic process where "Name='python.exe'" get ProcessId,CommandLine | grep gan_proxy`.
When the watcher is genuinely dead, rebooted machines lose `tun0` because
`vn.vichanger.app` is NOT relaunched — the app does not auto-start after reboot,
so VPN only returns when the watcher force-stops/relaunches it
(`recover_target` signature `VPN_START_NOT_VERIFIED` → `force_stop_relaunch_vichanger`).

## Reconnect debugging reference

For the target-specific evidence ladder, circular readiness-gate prevention, retained-lock policy alignment, resilient per-worker telemetry, and the user preference not to start unrelated TikTok schedules, see `references/watcher-reconnect-debugging.md`.

**Controlled watcher restart via tray auto-respawn (2026-08-08; supervisor đổi 2026-08-10 → `GanProxyWatcherTray`, xem section "Standalone proxy watcher tray + Hermes health guard"):** when code
changes must be loaded into a LIVE watcher, do not touch the tray/task. The
watcher is a two-node python tree (parent = automation venv python, child =
Python312 python, SAME `watch --all --workers 80` cmdline); the supervising tray
runs a 15 s timer that respawns it automatically. Restart = verify tree
PowerShell probe (never inline — bash eats `$_`; write a `.ps1` under runtime),
preflight device-lock grep for the watcher PIDs (empty = safe), kill both PIDs
via `Stop-Process` (git-bash `taskkill //PID` is invalid), wait ~15-60 s, then
verify: new PIDs, fresh `watcher-logs/proxy-watcher-<ts>.stdout.log` with EMPTY
stderr, new run-hash dir, and the target's `WATCH_EVENT_VERIFIED_SUCCESS` in the
new run. Worker spawn is INCREMENTAL (17→26→38→56→72→76 over ~4 min) — a missing
machine dir early is not a failure. Full procedure/verification ladder:
`references/watcher-restart-tray-respawn.md`.

**Proxy-readiness handshake → `DEVICE_LOCK_FAILED` (2026-08-07):** a workflow
gated on proxy readiness (e.g. `tiktok_workflow` `ACQUIRE_LOCKS`) fails with
`[DEVICE_LOCK_FAILED] ... proxy readiness failed for <serial>: proxy_application:ADBError:
adb command timed out: ... am broadcast --receiver-foreground ...` when the watcher
wrote `proxy_failed` to `~/.codex/device-readiness/<sha256(serial)[:24]>.json`.
This is **transient** — the watcher retries the broadcast and flips back to
`proxy_ready` minutes later. Diagnose from the readiness FILE (the log/report error
is truncated at the broadcast args), not the log line. **Before retrying a failed
worker, check the device lock** (`machine_<N>.lock.json`, owner PID via `wmic`):
the fleet/scheduler often already re-spawned a legitimate worker for the same
machine, so a blind retry fails-closed again with `device lock active` and only
creates a spurious fail report. Full chain + checklist:
`references/proxy-readiness-handshake-device-lock.md`.

**Retry worker đâm đúng cửa sổ reboot — đọc `boot_id` readiness TRƯỚC khi retry (2026-08-08, máy 65):** worker fail `[DEVICE_LOCK_FAILED] ... Device "tun0" does not exist` vài phút sau khi VPN verified OK = **máy vừa reboot**, không phải proxy chết. 3 dấu hiệu: (1) `~/.codex/device-readiness/<sha256(serial)[:24]>.json` có `boot_id` KHÁC lần check trước; (2) watcher đã sinh artifact mới `attempt-NN-watch-NN-ready/verified.json` (đang xử lý `boot_id_changed`); (3) `pidof vn.vichanger.app` đổi PID. **Chỉ retry sau khi watcher ghi `WATCH_EVENT_VERIFIED_SUCCESS` mới nhất của boot mới** + `tun0` có `inet` — máy 65 retry sớm fail 17:59→18:02, watcher verified 18:02, retry 18:03 → SUCCESS. Runbook đầy đủ: `tiktok-upload-ui-recovery` §9b.

**Sibling workers chết hàng loạt vì uiautomator contention — retry máy nào cũng chấp nhận được khi dump OK (2026-08-08, coord 52-65-69):** trong cùng 1 run, máy 52 chạy DONE trong khi 65 chết ở `OPEN_TIKTOK` (`uiautomator_idle_state_error`, visual gate dark — app thực tế OK) và 69 chết ở `CONNECT_DEVICE` (`close_all_apps_start failed: non_xml_ui_dump`) — cả farm 75 máy cùng 1 ADB server làm uiautomator treo cục bộ từng máy. Đây KHÔNG phải lỗi per-machine; sau ~2 phút dump tự hết treo (`uiautomator dump` trả OK). Trước khi retry từng máy: (1) không worker nào đã respawn cho máy đó (`wmic ... | grep tiktok_workflow` — gõ đúng máy), (2) không lock còn giữ, (3) test dump trực tiếp trên device. Retry follow quy tắc: mỗi máy MANUAL_REVIEW là fail-closed đúng thiết kế — `OPEN_TIKTOK` không nằm trong `SOFT_REBOOT_RECOVERABLE_STATES` (chỉ DISMISS_POPUPS), nên UI-dump-fail ở OPEN_TIKTOK luôn về MANUAL_REVIEW; nếu lặp lại nhiều, cân nhắm thêm OPEN_TIKTOK vào nhánh soft-reboot recovery (worker + test + COMPAT entry), chưa làm thì không sửa gì.

**Core pin phải trỏ file TỒN TẠI + phiên bản đúng (2026-08-08, gan-proxy):**
`requirements-automation-core.txt` từng trỏ `../automation-core-worktrees/device-lock-transactional-recovery-20260804/dist/automation_core-0.4.34-py3-none-any.whl`
— worktree đó ĐÃ BỊ XÓA nên `pip install -r` sẽ fail. Verify: `ls` đường dẫn pin + `grep version pyproject.toml` core chính
(thư mục `automation-core-worktrees/` rỗng/không tồn tại; core chính `D:\Taadaa\automation-core` = 0.4.43,
`dist/automation_core-0.4.43-*.whl` tồn tại). Fix pin về `../automation-core/dist/automation_core-0.4.43-py3-none-any.whl`.
Khi nghi "merge conflict trùng vs core", đây là nơi kiểm tra đầu tiên — không phải code diff.

**Core 0.4.43 KHÔNG có `maintenance_handoff` → watcher fail-closed (2026-08-08):**
`request_maintenance_handoff` đã bị bỏ khỏi core (quyết định user 08-08 — vấn đề popup draft sau reboot
ĐÃ có handler `_dismiss_resume_draft_popup`/`_delete_all_profile_drafts` trong consumer). Hệ quả:
- `gan_proxy_fleet.py` KHÔNG gọi method đó (0 reference); `_read_post_reboot_owner_ack` (L556) **fail-closed an toàn**:
  lock không có field `maintenance_handoff` → trả `None` → `_watch_post_reboot_takeover_proof` (L651) bỏ `owner_ack` →
  watcher KHÔNG bao giờ takeover post-reboot → không chen ngang consumer đang sống (đúng thiết kế, không crash).
- Core 0.4.43 `_takeover_payload`: owner `running` + `_owner_process_alive=True` → **từ chối takeover KỂ CẢ có proof**
  (fail-closed đúng cho "interrupt live consumer"); takeover chỉ hợp lệ khi owner CHẾT (`alive=False`).
- **Test cũ viết cho feature bỏ → thay bằng fail-closed test**, không xóa trắng cũng không mock bừa:
  (1) bỏ lời gọi `request_maintenance_handoff`, mock `_read_post_reboot_owner_ack` trả owner_ack schema đúng
  (mode/state/handoff_id/pre_boot_id/previous_status/owner{host,pid,lock_id,run_id} lấy từ lease thật);
  (2) mock `_owner_process_alive=False` cho kịch bản takeover sau reboot (owner chết), bỏ assertion "owner paths giữ nguyên"
  (takeover core ghi đè → `FileNotFoundError` khi `owner.release()`);
  (3) hoặc thay 2 test cũ bằng test fail-closed: `_read_post_reboot_owner_ack` → None khi không có handoff;
  proof vẫn `vpn_missing=True` nhưng KHÔNG chứa `owner_ack` (không bao giờ crafted owner_ack authorize interrupt).
- Battery code mới (`set_battery_random`, chống popup Samsung "PIN YẾU" che composer sau reboot):
  gọi `adb` 3 lần (`dumpsys battery set level/status/ac`) → test mock `fleet.random.randint` trả hằng (55)
  + assert `adb.call_args_list` đúng 3 lệnh; `adb.assert_not_called()` cũ là SAI (code mới luôn gọi battery).
- Test consumer chạy với `PYTHONPATH="D:\Taadaa\automation-core\src"` (core src 0.4.43), không phải venv cài sẵn.

## Background schedule inventory & "PowerShell giật chớp" diagnosis (2026-08-10)

When the user asks "có gì đang chạy ngầm / máy giật chớp cửa sổ" — enumerate ALL layers, don't just answer about the watcher:

```bash
# 1. All background python/node processes with full command lines
wmic process where "Name='python.exe' or Name='node.exe'" get ProcessId,CommandLine
# 2. PowerShell processes (the flash suspects)
wmic process where "Name='powershell.exe'" get ProcessId,CommandLine
# 3. Scheduled tasks (custom only — filter out Microsoft\)
schtasks /Query /FO CSV | grep -iv "Microsoft\|Windows"
# 4. Per-task XML for commands/triggers/intervals
schtasks /Query /TN "<TaskName>" /XML | grep -E "Command|Arguments|StartBoundary|Interval|Repetition"
```

**Full inventory (verified 2026-08-10)** — running schedules: `TikTokScheduler` (logon + restart 1m, python `-m scheduler --live`), `TikTokScheduleRecovery`, `TikTokScheduleRecoveryHealth`, `TikTokAllSchedulerTray` (tray MỚI: proxy watcher + 15s respawn timer + 4 sub-schedulers), `TikTokSchedulerTray` (tray CŨ — chạy song song, đừng nhầm là duplicate bug), `GmailRegistrationScheduler` + `GmailRegistrationSchedulerTray`, `HermesGatewayRestart_20260809` (one-shot, xong), `cua-driver-serve` (1m probe, ngủ), wake tasks `TikTokAllSchedulerWake` ×4/ngày (09:30/14:00/15:30/19:00) + `TikTokSchedulerWake` + `GmailSchedulerWake` 08:00. Background processes: 9router tray+server, `gan_proxy_fleet.py watch` ×2, tiktok schedulers (feed/login/2FA), `recovery_runtime --watch --dispatch`, gmail_scheduler, Hermes gateway serve ×2, live workers (tiktok_workflow, feed-session). **UPDATE cuối ngày 2026-08-10 (user chốt "tạm thời tắt hết trừ proxy watcher"):** TikTok/Gmail scheduler + 2 tray TikTok + recovery + wake tasks đã DISABLE + process bị kill; còn chạy: `GanProxyWatcherTray` (standalone, chứa proxy watcher + Hermes guard), Hermes gateway serve ×2, 9router, workers đang chạy dở (không kill giữa chừng — để tự xong).

**PowerShell window flash "lâu lâu" = WAKE TASKS, benign — NOT a watcher failure.** Task Scheduler launches `powershell.exe` with `-Command "Start-ScheduledTask ..."` under InteractiveToken: even with `-WindowStyle Hidden`, the console window is CREATED then hidden → 1-frame flash. Frequency matches the wake-task schedule (4-5×/day). Do NOT diagnose this as watcher/tray death; verify watcher via the normal `wmic | grep gan_proxy` ladder instead. To eliminate the flash entirely: replace wake tasks' powershell with `schtasks /Run` direct or a python call — cosmetic, not required.

## Standalone proxy watcher tray + Hermes health guard (2026-08-10)

**Architecture change:** watcher KHÔNG còn do `TikTokAllSchedulerTray` supervise (task đó DISABLED 2026-08-10 — nó còn `Start-AllSchedulers` spawn 4 TikTok schedulers trực tiếp bằng `Start-Process`, không qua Task Scheduler, nên disable task không đủ; phải kill tray + con python orphan). Thay bằng task riêng **`GanProxyWatcherTray`** (logon trigger):
- Script: `D:\Taadaa\automation-core\src\automation_core\scheduler\proxy-watcher-only-tray.ps1` (CRLF + ASCII-only — xem pitfall encoding)
- Chỉ giữ proxy watcher: 15 s `Ensure-ProxyWatcher` timer + `Start-ProxyWatcher` lúc khởi động (adopt process `gan_proxy_fleet.py watch` đang chạy qua `Find-ProxyWatcherProcess` — KHÔNG spawn trùng khi tray mới chạy chồng watcher cũ)
- **Hermes health check**: mỗi 60 s check process `hermes_cli.main serve`; down streak ≥ 2 → chạy `hermes.exe gateway restart` (tối đa 1 lần/10 phút, chống false-positive lúc reboot/upgrade); log `D:\CodexRuntime\codex_gmail_debug-gan-proxy\hermes-health.log`
- **Telegram alert độc lập Hermes** (Hermes sập VẪN gửi được — bot POST thẳng): đọc `TELEGRAM_BOT_TOKEN` từ `~/AppData/Local/hermes/.env` → `https://api.telegram.org/bot<token>/sendMessage` chat_id=`-5345976284` (group Taadaa), cooldown 10 phút. Events: DOWN (streak 1) → RESTART → restart exit code / FAILED → OK (recover)
- Task tạo qua file XML: `schtasks /TR` giới hạn **261 ký tự** → `write_file` XML rồi convert sang UTF-16 (`python -c "open(p,'wb').write(open(p,'rb').read().decode('utf-8').encode('utf-16'))"` — write_file ra UTF-8 bị Task Scheduler reject) → `schtasks /Create /TN <name> /XML <file> /F`
- Tắt hàng loạt scheduler TikTok/Gmail (2026-08-10): disable 9 task (`TikTokScheduler`, `TikTokScheduleRecovery`, `TikTokScheduleRecoveryHealth`, `TikTokSchedulerTray`, `TikTokSchedulerWake`, `TikTokAllSchedulerWake`, `GmailRegistrationScheduler(+Tray)`, `GmailSchedulerWake`) + kill process tree. **Kill powershell wrapper KHÔNG giết con python orphan** — kill theo danh sách PID đầy đủ từ `wmic process where "Name='python.exe'" get ProcessId,CommandLine | grep scheduler|gmail` (cần 2 đợt: lần 2 bắt con orphan còn sống)

**PITFALL — .ps1 phải ASCII thuần (PS 5.1):** PowerShell 5.1 đọc file không-BOM theo ANSI/cp1252 → emoji/em-dash UTF-8 **vỡ parse** (`0x94` = `"` → "missing terminator"/"string is missing the terminator"). Repo convention: tiếng Việt KHÔNG DẤU + không emoji trong .ps1. Verify: `python -c "assert not [b for b in open(f,'rb').read() if b>127]"` (nếu còn, `unicodedata.normalize('NFD')` bỏ combining) + `[System.Management.Automation.Language.Parser]::ParseFile` → "PARSE OK" (nhớ khởi tạo `$errs=$null` trước `[ref]$errs` trong powershell -Command 1 dòng — [ref] không nhận biến chưa tồn tại).

**PITFALL — smoke-test hàm trong PS1 có `[Windows.Forms.Application]::Run()`:** dot-source scriptblock sau khi strip dòng Run() (`-replace '(?m)^\[Windows.Forms.Application\]::Run\(\)\s*$',''`), chạy với `powershell -STA` (script throw nếu MTA), gọi hàm trực tiếp. "TOKEN OK + ALERT SENT" = kênh Telegram hoạt động (tin test hiện trên group — user xác nhận).

## Reading the watcher event log (watch-events.jsonl)

The authoritative per-target trace is
`<runtime>/<run-hash>/machine-<N>/watch-events.jsonl` plus `attempt-*.json`
sanitized captures (fields: `machine`, `serial`, `attempt`, `phase`,
`captured_at`, `adb_state`, `focused_window`, `vichanger_installed`,
`vichanger_process`, `vpn_connected`). Phases seen: `watch-01-ready`,
`before-recovery`, `after-recovery`, `watch-02-verified`.

State machine per event (grep `"status"` to summarize; tail to see the last state):
`WATCH_EVENT_DETECTED → WATCH_EVENT_LOCK_ACQUIRED (reason=startup|boot_id_changed|reconnect)
→ WATCH_CORE_READINESS_PASS → WATCH_DIAGNOSTIC_CAPTURE_* →
WATCH_PROXY_APPLICATION_BEGIN → (SUCCESS → ROTATION_RESTORE → VERIFICATION →
WATCH_PROXY_READINESS_READY → WATCH_EVENT_VERIFIED_SUCCESS)
| (FAILURE → WATCH_EVENT_CLASSIFIED → RECOVERY_RESERVED → RECOVERING →
WATCH_EVENT_RECAPTURED (reason=rerun_proxy_assignment_script_for_target) →
WATCH_EVENT_RETRYING → FAILURE again → WATCH_PROXY_READINESS_FAILED →
WATCH_EVENT_FINAL_BLOCKED)`.
`WATCH_PROXY_READINESS_PENDING (reason=boot_id_changed)` fires between events.

Match artifact timestamps against the user's screenshot/observation time — the
screenshot often captures the exact instant of a *transient* failure, not the
final state.

### POST-reboot lock screen → `VPN_POSTCONDITION_NOT_VERIFIED` (worked example 2026-08-08, máy 74)

After a fresh reboot the phone sits at the lock screen (`focused_window=StatusBar`,
ViChanger not running, VPN not connected). The watcher applies the proxy and VPN
comes up, but the postcondition `close_all_recent_apps()` (Recent Apps → "Đóng tất cả"
→ tap → HOME → verify launcher foreground) **fails closed because HOME cannot surface
the launcher while the screen is locked** → `RuntimeError: VPN connected but Recent
Apps/Home verification failed` → `VPN_POSTCONDITION_NOT_VERIFIED` → recovery
`rerun_proxy_assignment_script_for_target` reruns set_proxy *without changing the
locked condition* → attempt 2 fails with the same signature → `FINAL_BLOCKED`
(correct per 2-attempt rule; NOT a bug, NOT an infinite loop).

**If it succeeds minutes later, that is NOT recovery/self-heal** — it is an
independent new event: `boot_id_changed` (device booted again / finished booting)
finds ViChanger already running + VPN already connected + screen unlocked →
application + verification succeed on the first pass of event 2. Diagnosis must
compare the event-1 vs event-2 `attempt-*.json` captures (focused_window,
vichanger_process, vpn_connected) to prove this.

No redesign is needed — the failure is fail-closed by design.

**IMPLEMENTED 2026-08-08 — bounded keyguard-dismiss fallback now exists.**
`scripts/vi_changer_runner.py` gained `_go_home_and_verify_with_keyguard_fallback(adb_path, serial)`:
try `_go_home_and_verify` → if launcher still not foreground, ONE bounded
`prepare_device(AdbClient(...), wake=False, swipe_unlock=True, lock_rotation=False,
set_battery=False, timeout=10)` (swipe-only: no wake/rotation/battery side effects),
wrapped in `try/except Exception` → on exception return `False` (never raise, never
loop) → retry `_go_home_and_verify` once → fail-closed. Both call sites in
`close_all_recent_apps` use it; the dump-failure except path still returns `False`
even if the fallback restored HOME — a failed UI dump must never report success.
`set_proxy()` message "Recent Apps/Home verification failed" unchanged.
Regression tests: `test_close_all_recent_apps_unlocks_keyguard_once_and_returns_home`,
`test_close_all_recent_apps_fails_closed_when_still_locked_after_one_unlock`,
`test_close_all_recent_apps_does_not_retry_keyguard_when_home_already_reachable`
(all in `tests/test_vi_changer_runner.py`, mock `runner.prepare_device` +
`runner.time.sleep`); COMPAT entry `proxy-clear-recent-keyguard-dismiss-20260808`
in `docs/ui-compatibility.md` (old record `proxy-clear-recent-after-vpn-20260801`
kept verbatim). Before writing the call, verify kwargs read-only via
`inspect.signature(automation_core.device.prepare_device)`. Still open (core-side,
out of gan-proxy scope): `wait_until_unlocked` should wait until keyguard is
actually gone, not merely screen-on.

**Harmless noise:** repeated `WATCH_MAPPING_RELOAD_ERROR` (`Permission denied:
...PROXYgandienthoai.xlsx`, every ~5s) means the Excel mapping is open/locked by
Excel or OneDrive; the mapping was loaded at worker start so event handling is
unaffected — the errors stop once the file is closed. Do not treat this as the
failure cause.

## Verification checklist

- Targeted watcher lock/event regression tests pass.
- Full consumer watcher suite and compile check pass.
- `git diff --check` passes.
- **Hermes verification gate:** if it flags the workspace "unverified" even after real pytest evidence (it fires when no canonical test command is detected), satisfy it with a focused ad-hoc script created via `tempfile.mkstemp(prefix="hermes-verify-", suffix=".py", dir=tempfile.gettempdir())` in `%TEMP%` — run it against the changed behavior, delete it after, and label results explicitly as ad-hoc (e.g. "AD-HOC 12/12 PASS, not suite green") rather than claiming suite green.
- Restart only the watcher/tray component necessary to load code; do not use a menu/action that starts unrelated account/feed schedulers.
- After a real target reboot, record fresh target-specific watcher evidence plus final `tun0` and Android VPN connectivity proof.

## Pitfalls

- **Runner unit tests: mock `runner.prepare_device` + `runner.time.sleep`** in any test that exercises a fallback path. Old tests that leave `prepare_device` unmocked (e.g. `test_close_all_recent_apps_does_not_raise_when_home_fallback_fails`) still pass because `adb` is not on PATH on the dev box → the real `prepare_device` raises `ADBError` (a `RuntimeError` subclass) instantly and the fallback's `except Exception` swallows it → `False`. Keep that in mind if the box ever gains `adb` on PATH (real device calls could then fire).
- **Docs/`ui-compatibility.md` in CRLF repos:** the patch tool's raw diff may show LF→CRLF normalization on untouched blocks; judge the change with `git diff` output instead (git autocrlf shows only real additions/deletions). Appended COMPAT records must not rewrite old records — verify `+N, 0 deletions` in `git diff --stat`.
- A retained lock from a dead recovery owner can block a watcher startup event indefinitely if the watcher neither requests takeover nor bounds lock wait.
- Killing a watcher child may not make a tray supervisor respawn it immediately; restart the dedicated tray/task process when a new watcher process is needed. Verify new process creation time. (2026-08-08 update: when the tray IS alive, kill the whole watcher TREE — parent + child — and the 15 s `Ensure-ProxyWatcher` timer respawns it automatically with fresh PIDs, new log file, and clean singleton acquisition; only touch the tray/task when the tray itself is dead, e.g. Last Result 267014.)
- A watcher can create artifacts for many machines at startup. Always compare artifact timestamps and machine/serial before drawing conclusions.
- **Before manually re-running a failed worker, verify the target isn't already owned**: an active `machine_<N>.lock.json` with a live PID (check via `wmic`, not `tasklist`) means the fleet/scheduler already re-spawned a worker — retrying only produces a fail-closed `device lock active` error and a spurious report. Tail the owner's log instead.
- Do not expose proxy values, workbook rows, credentials, or raw sensitive logs in reports.
