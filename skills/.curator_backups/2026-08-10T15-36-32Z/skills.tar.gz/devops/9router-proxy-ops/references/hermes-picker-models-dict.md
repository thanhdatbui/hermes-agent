# Hermes picker: wiring 9router combo names into custom_providers

Verified 2026-08-09. User: "9router sao có mỗi deepseek flash vs pro? thêm model theo đúng tên hay theo combos?"

## Diagnosis (why the picker only shows 2 models)
- Hermes desktop dropdown + `/model` renders exactly each custom_provider's `models:` dict
  (`discover_models: false`), NOT 9router's `/v1/models` catalog.
- Root cause found: `custom_providers[1]` (9router) `models:` only had 2 entries
  (`deepseek-v4-flash`, `deepseek-v4-pro`). Meanwhile ~20 9router catalog models
  (`gemini-*`, `deepseek-v4-pro-max`, `opencode-free`, `freemodel/*`, `ds/*`, `gc/*`, `API-key`)
  had been dumped into `custom_providers[0]` (name `cockpit`, port 60818 = codex cliproxy) —
  wrong place, made the picker look messy ("loạn").

## Decision: add by COMBO NAME, not route path
- No-slash model string (`gpt-5.6-luna`) → 9router resolves combo → auto fallback chain.
- Slash path (`cx/gpt-5.6-luna`) → direct route, NO fallback.
- Live proof: probe `deepseek-v4-pro` returned `model=big-pickle` (first member
  `cmc/deepseek/deepseek-v4-pro` failed → combo fell back automatically).

## Combo health check (probe before advertising in Hermes)
```bash
curl -s --max-time 60 -X POST http://127.0.0.1:20128/v1/chat/completions \
  -H "Authorization: Bearer $NINEROUTER_API_KEY" -H "Content-Type: application/json" \
  -d '{"model":"<combo-name>","messages":[{"role":"user","content":"hi"}],"max_tokens":5,"stream":false}'
```
- Read the `model` field in the response = which member actually answered.
- `finish_reason=length` + empty content with max_tokens=5 is a SUCCESS for reasoning
  models (deepseek) — don't misread as failure.
- Empty/`?` response = dead combo (route provider gone).
- Result 2026-08-09: alive = deepseek-v4-flash, deepseek-v4-pro, gpt-5.6-luna/sol/terra,
  vision-gemini, opencode-free. Dead = deepseek-v4-pro-max (route `ds/` gone),
  gemini-3.1-pro (route `gc/` gone), API-key (junk name, v98/claude-opus-4-8 slow 39s).
- Catalog caveat: `oc/*` NOT in /v1/models yet still routable via combo; `ds/*`/`gc/*`
  gone AND dead. Catalog absence ≠ dead; probe decides.

## Delete dead combos (dashboard API)
```bash
TOKEN=$(curl -s -D - -o /dev/null -X POST http://localhost:20128/api/auth/login \
  -H 'Content-Type: application/json' -d '{"password":"123456"}' \
  | grep -i '^set-cookie' | sed 's/.*auth_token=\([^;]*\).*/\1/')
curl -s -H "Cookie: auth_token=$TOKEN" http://localhost:20128/api/combos   # {"combos":[...]}
curl -s -X DELETE -H "Cookie: auth_token=$TOKEN" http://localhost:20128/api/combos/<id>
```

## Surgical models-dict edit (the two regex traps)
`patch`/`write_file` REFUSE config.yaml; use python text edit with backup.
1. Backup: `cp config.yaml config.yaml.bak-<ts>`.
2. Block start: slice at `mm.start()` of the `^    models:` line — using `mm.end()`
   produces `models:    models:` (duplicated line, YAML parse fail).
3. Block end regex: `\n(?:  - |[a-z])` — matches next `- name:` (2-space) OR a
   column-0 top-level key. A `\n  (?=[a-z]|- )` regex eats the `gateway:` line
   (indent 0) → whole section deleted.
4. Validate immediately: `python -c "import yaml; yaml.safe_load(open('config.yaml',encoding='utf-8'))"`.
   `hermes config check` does NOT catch this class of error.
5. Verify picker backend without restarting the app:
   `PYTHONPATH=. python -c "from hermes_cli.inventory import load_picker_context, build_models_payload; p=build_models_payload(load_picker_context(), explicit_only=True); print([(r['name'], list((r.get('models') or {}).keys())) for r in p['providers'] if r['name'] in ('9router','cockpit')])"`

## Final state 2026-08-09
- 9router provider models: deepseek-v4-flash (1048576), deepseek-v4-pro (1048576),
  gpt-5.6-luna/sol/terra (256000), vision-gemini (1048576), opencode-free (1048576).
- cockpit provider: only real codex set (gpt-5.6-luna/sol/terra, gpt-5.5, gpt-5.4, gpt-5.2).
- Backups: config.yaml.bak-20260809-204247, bak-models-20260809-205232.
- New sessions (/new) pick up the config; desktop picker may need Refresh Models / app restart.
