# OpenCode free (`oc/*`) qua 9router — verify 2026-08-06

## Combo & KV (DB `C:\Users\Kibe\AppData\Roaming\9router\db\data.sqlite`)
- `combos` table: combo `opencode-free` → `["oc/deepseek-v4-flash-free","oc/mimo-v2.5-free","oc/big-pickle","oc/hy3-free","oc/nemotron-3-ultra-free","oc/north-mini-code-free"]`
- `kv` table: `oc|<model>|llm` → `{"providerAlias":"oc","id":"<model>",...}`
- Credential: OpenCode Go API key (`~/.local/share/opencode/auth.json`, provider `opencode-go`, type=api). opencode CLI KHÔNG cần chạy để gọi `oc/*` qua 9router — 9router giữ credential upstream.

## Probes (đã chạy OK 2026-08-06)
- Non-stream: `{"model":"oc/deepseek-v4-flash-free","messages":[{"role":"user","content":"Reply with exactly: OC_DS_FREE_OK"}],"max_tokens":50,"stream":false,"reasoning":{"enabled":true,"effort":"high"}}` → `content:"OC_DS_FREE_OK"`, `cost:"0"`.
- Stream effort A/B (câu "tại sao bầu trời xanh?", max_tokens 300): `grep -c reasoning_content` → **high=91, max=300** → effort client được tôn trọng (KHÔNG bị translate ép như `cmc/*` với `providerThinking.commandcode.mode="high"`).
- Tool calling: `tools:[{type:function,function:{name:get_time,...}}], tool_choice:"auto"` → trả `tool_calls:[{id,type:"function",function:{name:"get_time",arguments:"{}"}}]` chuẩn.

## Diagnose "server command code sập"
- `opencode run --model <bất kỳ>` (opencode-go, freemodel, commandcode-direct) đều trả `UnknownError: Unexpected server error` + ref id khác nhau mỗi lần → lỗi tầng GATEWAY opencode (auth `sk-gon...` trong auth.json hoặc service opencode.ai outage), KHÔNG phải model cụ thể.
- Phân biệt nhanh: curl 9router `cmc/deepseek/deepseek-v4-flash` (sống = commandcode/deepseek OK) + `oc/deepseek-v4-flash-free` (sống = model opencode free OK). Cả 2 sống mà opencode CLI chết = gateway opencode.
- Log upstream thật: `~/.local/share/opencode/log/opencode.log` — `stream error ... AI_APICallError: Monthly usage limit reached` / `[503] The request queue is full` / `[502] Nvidia ResourceExhausted` = quota upstream; `UnknownError` = gateway.
- opencode CLI không có process nền mặc định (chỉ 9router `cli.js --tray` + `custom-server.js`); `opencode serve` mới là headless server (port mặc định 0, cần `--port`).

## Hermes fallback chain code anchors (reasoning KHÔNG kế thừa)
- `agent/agent_init.py` ~1166: `_fallback_chain` build từ `fallback_providers` (list) / `fallback_model` (legacy dict) — session init, đổi config cần `/new`.
- `agent/chat_completion_helpers.py` `try_activate_fallback` (~1372): skip logic (dedup provider/model/base_url, `_unavailable_fallback_keys` session-suppression, `_fallback_entry_unavailable_without_network`), swap client in-place, **re-resolve reasoning** ~1690: `agent.reasoning_config = resolve_reasoning_config(load_config(), agent.model)`.
- `hermes_constants.py` `resolve_reasoning_config` (~999): ưu tiên `agent.reasoning_overrides.<model>` (spelling-tolerant) → global `agent.reasoning_effort`; session-scoped `/reasoning --session` override thắng tất cả (resolve trước).
- `hermes_cli/fallback_config.py` `get_fallback_chain`: merge `fallback_providers` + legacy `fallback_model`, dedup theo (provider, model, base_url); Gemini implicit fallback được upgrade thành `custom:9router` nếu config có named 9router endpoint.
- `agent/auxiliary_client.py` `_try_main_fallback_chain` (~4113): auxiliary task dùng chung main chain; skip provider bị fail + main provider + "auto".
