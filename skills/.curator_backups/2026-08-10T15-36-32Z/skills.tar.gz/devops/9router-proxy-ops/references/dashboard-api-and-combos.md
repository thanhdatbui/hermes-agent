# Dashboard API + Combo mechanics (verified 2026-08-07)

## Combo resolution — the slash rule
`9router/app/.next-cli-build/server/chunks/3212.js` (module 38775, fn `j`):
```js
async function j(a){ if (a.includes("/")) return null;   // slash → NOT a combo
  let b = await getComboByName(a);                       // no slash → look up combos table
  return b && b.models.length > 0 ? b.models : null; }
```
- `cmc/deepseek/deepseek-v4-flash` (slash) → direct provider route, combo NEVER consulted.
- `deepseek-v4-flash` (no slash) → resolved to combo models `["cmc/deepseek/deepseek-v4-flash","oc/deepseek-v4-flash-free"]`, tried in order.
- So any client config (Hermes `model.default`, `custom_providers[].model`, Codex) must use the combo NAME to get combo fallback.

## Dashboard API auth (curl)
- Endpoint: `POST /api/auth/login` (NOT `/login` — that returns 405). Body `{"password":"123456"}` (or `INITIAL_PASSWORD` env).
- Response 200 sets `set-cookie: auth_token=<jwt>; Path=/; HttpOnly; SameSite=lax`.
- Extract and reuse:
```bash
TOKEN=$(curl -s -D - -o /dev/null -X POST http://localhost:20128/api/auth/login \
  -H 'Content-Type: application/json' -d '{"password":"123456"}' \
  | grep -i '^set-cookie' | sed 's/.*auth_token=\([^;]*\).*/\1/')
curl -b "auth_token=$TOKEN" http://localhost:20128/api/combos
```

## Combo CRUD
- List: `GET /api/combos` → `{"combos":[{id,name,kind,models,createdAt,updatedAt}]}`
- Create: `POST /api/combos` `{"name":"x","models":["a/b","c/d"]}` — name must match `^[a-zA-Z0-9_.\-]+$`; duplicate name → 400.
- Update: `PUT /api/combos/{id}` `{"name":...,"models":[...]}`
- Delete: `DELETE /api/combos/{id}` → `{"success":true}`

## Console log (live diagnostic when requestDetails is stale)
- `GET /api/translator/console-logs` → `{"success":true,"logs":["[12:22:10] ℹ️  [CHAT] Combo \"deepseek-v4-flash\" with 2 models (strategy: fallback, sticky: 1)", ...]}`
- Markers to grep: `[COMBO] Trying model 1/2`, `[COMBO] Model ... succeeded`, `[FALLBACK] ⇄`, `[AUTH] ... locked modelLock_...`, `[TOKEN_REFRESH]`, `ERROR 403/429`.
- `requestDetails` table stopped logging 2026-08-07 (last row 06-08 12:10) despite live traffic — console-log API is the reliable recent-history source.

## Fallback verification recipe (no UI needed)
1. Create throwaway combo: `{"name":"fb-test-verify","models":["cmc/deepseek/NONEXISTENT-MODEL","oc/deepseek-v4-flash-free"]}`
2. `curl -X POST http://127.0.0.1:20128/v1/chat/completions -H "Authorization: Bearer $NINEROUTER_API_KEY" -H 'Content-Type: application/json' -d '{"model":"fb-test-verify","messages":[{"role":"user","content":"hi"}],"max_tokens":8,"stream":false}'`
3. Success = response `"model":"deepseek-v4-flash-free"` + `"cost":"0"`. Console log shows: 403 on fake model → `[FALLBACK] ⇄ ACC:... UNAVAILABLE (403) → NEXT ACCOUNT` → oc model succeeded.
4. DELETE the combo afterwards — user dislikes leftover test combos.

## Hermes config edits (custom_providers is a LIST)
- `patch`/`write_file` REFUSE to touch `~/AppData/Local/hermes/config.yaml` (security guard) — use `hermes config set`.
- `custom_providers` is a list → index it: `hermes config set custom_providers.1.model "deepseek-v4-flash"` (index 1 = 9router after cockpit).
- `hermes config get` does not exist; verify with `hermes config show` or `sed` the file.
- After changing model config, Hermes needs `/new` (or `/model` switch) to reload.

## Gemini free-tier quota (why gemini 429s)
- Free tier: 20 req/day/project/model — `generate_content_free_tier_requests`, quotaId `GenerateRequestsPerDayPerProjectPerModel-FreeTier`.
- 429 → per-account lock 300s (`modelLock_gemini-3.6-flash`); both accounts locked → `[AUTH] gemini | all 2 accounts locked ... reset after 4m 59s`.
- Traffic sources to gemini via 9router: Hermes `auxiliary.vision.model` (image analysis — the usual quota burner), `fallback_providers`, standalone audit jobs.
- If quota is precious: set `auxiliary.vision.model` → `oc/mimo-v2.5-free` (vision-capable free model), or drop gemini from `fallback_providers`.
