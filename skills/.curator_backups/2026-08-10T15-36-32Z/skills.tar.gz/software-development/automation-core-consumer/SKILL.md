---
name: automation-core-consumer
description: "Build and fix consumers of automation-core for Android/TikTok workflows. Covers startup contract, ADB config, workbook mapping, Excel pitfalls, device lock policy, and the Codex↔Claude approval loop."
version: 1.5.0
author: Hermes Agent
metadata:
  hermes:
    tags: [automation-core, android, tiktok, adb, consumer, workbook, openpyxl]
    related_skills: [consumer-scheduler-orchestration, github-code-review]
---

# automation-core-consumer

Build a consumer of `automation-core` for Android/TikTok automation.  
Repo root is typically `D:\Taadaa\<project-name>\`.

## Tooling pitfall: `search_files` fails on Taadaa repo paths

The `tiktok-luot nuoi acc` repo name contains spaces. `search_files`
(ripgrep-backed) mangles the path through MSYS (`/d/Taadaa/tiktok-luot nuoi
acc/...` does not resolve) and fails with `IO error ... The system cannot find
the path specified`. **Do not retry `search_files` repeatedly on a
space-containing repo path** — switch immediately to:
- `terminal` + `grep -n` with a leading `cd "/d/Taadaa/tiktok-luot nuoi acc" &&`
  (quotes required), or
- `read_file` with the native Windows path (`D:\\Taadaa\\...`).

**Broader than spaces (proven 2026-08-07):** `search_files` also fails with the
same `IO error ... The system cannot find the path specified (os error 3)` on
PLAIN `D:/Taadaa/<repo>/<file>` absolute paths that `terminal` + `grep -n`
handles fine. The ripgrep path conversion for this drive layout is unreliable
in general — when `search_files` errors on any Taadaa path, switch to
`terminal` + `grep -n` (with `cd "D:/Taadaa/<repo>" &&`) or `read_file`
immediately; do not retry the search tool. `git diff`/`read_file`/`patch` are
unaffected; only the ripgrep search tool path-mangles.

Also note: repos with `core.autocrlf=true` + LF source show "LF will be
replaced by CRLF" warnings on `git diff` — harmless; use `git diff --numstat`
for the real insertion/deletion counts and re-check `git diff` after each
`patch` tool edit to confirm no line-ending churn crept in.

**CRLF files: always detect before editing and preserve on append.** Some
tracked files are CRLF end-to-end (e.g. `automation-core/tests/test_ui_dump.py`
— 330 CRLF, 0 bare LF). The `patch` tool matches on LF-normalized text, but an
append via `write_file`/shell `>>` writes bare LF and mixes line endings.
Safe append recipe (keeps CRLF):
```python
path = r'D:/Taadaa/...'; data = open(path, 'rb').read()
assert b'\r\n' in data  # detect CRLF first
payload = NEW_TEXT.replace('\n', '\r\n').replace('\r\r\n', '\r\n')
open(path, 'ab').write(payload.encode('utf-8'))
```
For in-place edits on CRLF files, read bytes → decode → `replace('\r\n','\n')`
→ edit on LF → re-encode with `replace('\n','\r\n')` → write. Verify after:
`python -c "d=open(p,'rb').read(); print(d.count(b'\r\n'), d.count(b'\n')-d.count(b'\r\n'))"`
(second number must stay 0). Strongest one-line proof: all three counts equal
(`crlf==lf and cr==crlf`) → `pure_CRLF: True`.

**Multi-part edit via one python replace-script (validator + tests, proven
2026-08-09):** when the user mandates "python binary, KHÔNG patch tool/sed"
(byte-exact CRLF preservation), write ONE script with write_file (not heredoc —
braces/quotes/unicode get mangled), read bytes → normalize `\r\n`→`\n` in
memory → apply each hunk as `text.count(old) == 1` + `text.replace(old, new)`
(count-assert EVERY anchor!) → re-encode `\n`→`\r\n` → write. Pitfalls hit in
the wild:
- **Unterminated last line**: an anchor built with a trailing `\n` never
  matches a file whose final line has no EOL (`old_tail` count-assert fails).
  Inspect first: `tail -c 200 <file> | od -c`; drop the trailing newline from
  the EOF anchor (this session: file ended `findings)` + nothing).
- **MSYS path mangling when running the script from a D: cwd**: bare
  `/c/Users/...` and `$HOME/...` forms mangle to `D:\c\Users\...` /
  `C:\c\Users\...` (uv python can't open). The form that always resolves:
  `python "$(cygpath -w /c/Users/Kibe/script.py)"` — confirmed working from
  `/d/Taadaa/Tiktok-video` cwd.
- **`$?` after a pipe is the LAST command's exit** — `cmd | tail; echo $?`
  reports tail's status (exit 0 despite findings). Capture the real code:
  `cmd > /tmp/out.txt 2>&1; echo "REAL_EXIT=$?"`.

**Spec-driven multi-file .md rule edits (docs-only, proven 2026-08-08):** editing
AGENTS.md / PROJECT_RULES.md / ui-compatibility*.md rule docs across several
Taadaa repos (e.g. adding one canonical rule ID to 8 files per a PLAN/SPEC) is a
different beast from code edits — the spec mandates exact line endings, exact
anchors, and proof that nothing else changed. Working recipe:
1. **Baseline first**: snapshot each repo (`git status --short` + `git diff
   --stat`) and `file <path>` per target file into
   `D:\Taadaa\coordfallback-baseline-<ts>.txt`. The `file` output is the ground
   truth for CRLF/LF. **A file can be MIXED** ("with CRLF, LF line terminators")
   — `automation-core/docs/ui-compatibility-contract.md` has 290 CRLF + 315 LF
   (25 LF-only lines). Do NOT assume pure CRLF/LF and never "normalize".
2. **Backup outside repos**: copy the target files to
   `D:\Taadaa\coordfallback-backup-<ts>\` (NOT inside any repo — untracked files
   in repos pollute diff verification). Note `D:\Taadaa\.git` exists but is an
   EMPTY directory (not a real repo) — root-level baseline/backup artifacts are
   safe there.
3. **Edit via one Python binary-replace script** (write_file, NOT heredoc —
   heredocs mangle quotes/unicode in git-bash; also `python /c/Users/...` gets
   mangled to `D:\c\Users\...`, so run %TEMP% scripts as
   `python "C:/Users/.../script.py"`): read bytes, for each anchor assert
   `data.count(anchor_bytes) == 1`, replace once, write back. Build the anchor/
   replacement with the file's OWN EOL (`s.replace('\n','\r\n')` for CRLF files,
   plain for LF). Never decode/re-encode the whole file (reflows mixed EOLs).
   - **Anchor-count trap**: summing "CRLF-variant count + LF-variant count"
     double-counts single-line anchors (both variants are identical bytes when
     the anchor has no newline) → occ=2 means 1 real occurrence. Count the
     anchor with the file's actual EOL only.
   - Anchor by unique content, never line numbers; lengthen the anchor until
     unique if it appears twice.
4. **Verify byte-level (strongest)**: script asserts
   `backup_bytes + expected_replacements == current_bytes` for every file —
   proves exactly the intended edits happened, EOL preserved, nothing else
   drifted. Also re-grep the canonical ID across ALL target files (the spec
   usually requires it in every one).
5. **Validator + git diff vs baseline**: run the repo's canonical validator
   (`automation-core/tools/check_ui_compatibility.py --workspace-root D:\Taadaa`
   — checks each consumer AGENTS.md contains `ui-compatibility-contract.md` +
   its registry filename, and each registry record has the 9 concepts).
   **Since 2026-08-09 the per-record completeness check is age-split
   (fail-closed):** records NEW (heading date >= 2026-08-09, or ID/owner
   containing `20260809`/`2026-08-09`) missing concepts are hard findings
   (exit 1); OLD records missing concepts become `registry_record_incomplete_legacy:`
   lines on **stderr** and do NOT fail. Expected healthy state NOW: stdout
   `OK: 9/9 consumers`, exit 0, plus ~66 legacy warnings on stderr — that is
   NOT a regression, it is the rule (no retroactive enforcement of pre-existing
   debt). Binding/AGENTS/registry-missing findings still always fail. Detail,
   `_is_new_record` logic, tests: `references/ui-compat-validator-fail-closed-2026-08-09.md`.
   **Prove findings pre-existing**: if the validator flags files you did NOT
   touch, or the same finding exists in the pre-edit backup, it is pre-existing
   — do not fix out-of-scope files. Small `git diff --numstat` numbers = no
   line-ending churn (a whole-file EOL churn shows hundreds of changed lines).
6. **Concurrent dirty files**: other sessions may edit the same repos. Baseline
   `git diff --stat` numbers for files you must NOT touch must be IDENTICAL
   before/after your work — that is the proof you did not disturb them. Report
   pre-existing validator findings honestly instead of editing out-of-scope files.

Full recipe + reusable byte-verify script skeleton:
`references/docs-rule-edit-workflow-2026-08-08.md`.

Second full pass of the same recipe (2026-08-09 — added the canonical+registry
binding, 2 lines, to Tiktok_Reg + tiktok-log-in AGENTS.md → validator
`OK: 9/9 consumers`): `references/docs-edit-binding-2026-08-09.md`. Two
refinements from that pass:
- **Strict-N-line mandate**: when the task says "THÊM 2 dòng" (exactly N lines,
  no new section header), insert the bullets immediately AFTER the anchor's
  first line (the `##` heading) — deterministic, bare +2 diff. When placement
  is free, mirror the established sections (`## Shared UI Compatibility
  Binding` in `tiktok-luot nuoi acc`, `## UI Compatibility Contract` in
  Tiktok-video); keep the bullet format with backticks around both paths.
- **Pitfall**: verifying backslash paths with regex `grep -c` under bash
  returns 0 for strings that ARE present — use `grep -F`/`grep -Fc`. And for a
  **pre-dirty target file**, snapshot `git diff <file>` into the backup dir at
  baseline, then after editing run
  `diff <(grep '^+' baseline.diff) <(grep '^+' after.diff)` — output must be
  ONLY your new lines; together with `--numstat` that proves the pre-existing
  dirty content is untouched.

**Editing GIANT single-file consumer scripts (social_reg_v1.py ~430KB/10k lines,
proven 2026-08-07):** the `patch` tool's fuzzy matching is DANGEROUS here. On
multi-part edits touching Vietnamese-accented CRLF content it repeatedly
mis-matched and re-indented whole blocks (IndentationError cascades), and one
edit TRUNCATED THE FILE TO 0 BYTES (recoverable via `git checkout -- <file>`).
Rules:
- Keep `patch` edits to small, uniquely-anchored single hunks; after EVERY edit
  re-verify with `python -c "import ast; ast.parse(open(p,encoding='utf-8').read())"`.
- If a patch diff shows unexpected re-indentation of lines you did not touch,
  STOP — the match went wrong. Restore (`git checkout -- <file>`) and switch
  strategy rather than "fixing" the cascade with more patches.
- The reliable workflow for multi-part edits: write ONE standalone Python
  script (repo-local, delete after) that reads the file as UTF-8 with CRLF
  preserved, applies each edit as exact `content.replace(old, new, 1)` with
  `assert content.count(old) == 1` before each replace, `ast.parse()` the
  result, writes to a `_fixed.py` sibling, then `mv -f` over the original.
  Count-assertions catch stale/anchor drift immediately instead of fuzzy-silently.
- Backslashes in Windows paths inside heredocs get mangled by bash — put the
  script in the repo dir and run it with a relative filename, and use forward
  slashes (`D:/Taadaa/...`) inside the Python strings.
- After any edit: `file <target>` must still report CRLF; `git diff --check`
  must be clean; then run the real pytest targets (do not skip verification
  just because the edit was scripted).

**Safe multi-file CODE edits inside automation-core (proven 2026-08-08, jitter
0.4.38):** same baseline+backup+byte-replace discipline as the docs-rule
workflow applies to code edits. Extra pitfalls learned the hard way:
- **NEVER open a real repo file with mode `'wb'` from a debug/throwaway probe
  script — it TRUNCATES.** A "does wb work here?" probe opened
  `src/automation_core/tiktok_popup.py` with `'wb'` and wrote `b'TEST'` → the
  file was destroyed (246 lines → 4 bytes, grep/wc suddenly report 0 lines).
  Test-writes only on temp files. On this host direct `'wb'` is also
  intermittently `PermissionError`-ed while `'ab'`/`'rb+'` succeed — the
  RELIABLE write pattern is write `path+'.tmp'` then `os.replace(tmp, path)`
  (atomic rename; worked even when `'wb'` was denied).
- **Restore must verify sha256, not just "file looks back"**: after
  `cp $BACKUP/a.py $BACKUP/b.py .` the files landed flat at the REPO ROOT (cp
  multi-file to `.` ignores each file's intended subdirectory) while the real
  `src/...` paths still held edited content — only the sha256-vs-baseline
  compare caught it. Copy per-file to its explicit destination, then
  sha256-compare ALL of them against the baseline snapshot.
- **Write long python edit scripts via write_file, run with Windows path**:
  long heredocs with braces break bash ("unexpected end of file from `{'"),
  and `python /d/Taadaa/x.py` mangles to `D:\d\Taadaa\x.py` — use
  `python "D:/Taadaa/x.py"`.
- **Inline python with `&` (bitwise ops) in terminal gets rejected** as
  backgrounding ("uses '&' backgrounding") — put such probes in a script file.
- **FakeAdb tap-call assertions**: `adb.shell(["input","tap",str(x),str(y)])`
  records 4 elements — assert `call[:2] == ["input","tap"]` (NOT `call[:3]`,
  which already includes x) and read the coords at indices `[2]`,`[3]` (not
  `[3]`,`[4]`). Run new tests immediately after writing; pytest catches these
  index mistakes in seconds.
- **Proving a failing test is pre-existing**: grep the failing test file for
  imports of your modified modules (`tap_element|dismiss_popup|from
  automation_core.input`); if no import path touches your code and the file
  was already dirty in the baseline `git status`, it is pre-existing — report,
  do not fix out-of-scope.
- Full session detail (jitter design, evidence-bound jitter=0, verify matrix,
  incident timeline): `references/jitter-core-tap-2026-08-08.md`.

**Nested-function definition-order pitfall (proven 2026-08-07):** inside a big
function, a helper called at line N but `def`-ed at line M>N raises `NameError`
at runtime — and if the call site is wrapped in `try/except Exception`, the
error is SILENTLY swallowed and the helper simply never runs. Found:
`_gmail_pull_refresh(1)` at ~7143 was a no-op because its `def` sat at ~7236.
When moving logic earlier in a function (e.g. pulling a refresh call before a
fast-path), you must move the nested `def`s (and their transitive helper deps)
above the first call site — a "move the defs up" edit, not just a call-site edit.
Symptom to grep for: a call line number < its `def` line number in the same
function body.

otp-gmail pull-refresh-before-fast-path ordering fix (audit F1, 2026-08-07) is
in `references/otp-gmail-refresh-before-fastpath.md`.

**Stale installed `automation_core` shadowing `src/` in pytest (proven
2026-08-07):** the Hermes venv site-packages holds an OLD installed copy
(0.4.40) while the repo `src/` is newer (0.4.43). `python -m pytest
tests/test_ui_dump.py` without `PYTHONPATH` imports the STALE installed
package → tests for recently-added behavior fail (pkill tests failed with
`assert ['pkill','-9','-f','atx-agent'] in ...shell_calls`). Always run
automation-core tests with `PYTHONPATH=src python -m pytest ...` and confirm
the import first: `PYTHONPATH=src python -c "import automation_core.ui as u;
print(u.__file__)"` (must point at `D:\Taadaa\automation-core\src\...`). Same
trap hits the Tiktok_Reg runner tests: `PYTHONPATH="D:/Taadaa/automation-core/src;."
python -m pytest tests/...`.

## Startup Contract (must follow exactly)

```
ACQUIRE_LOCKS
→ CONNECT_DEVICE / prepare_device (wake, swipe_unlock, lock_rotation)
→ OPEN_TIKTOK
→ DISMISS_POPUPS
→ ACCOUNT_SWITCHER
→ DISMISS_POPUPS_AFTER_SWITCH
→ ACCOUNT_READY
```

- `prepare_device()` is called ONCE from `automation_core.device`. Consumed parameters: `rotation`, `wake=True`, `swipe_unlock=True`, `lock_rotation=True`.
- No TikTok-specific actions before `prepare_device`.
- TikTok-specific upload logic begins only after `ACCOUNT_READY`.

## OPEN_TIKTOK Implementation (must verify feed loaded)

The handler **must** do more than just call `adapter.launch_app()`. On some devices (e.g. SM-G930S) the app starts but sticks at SplashActivity — the ADB command succeeds but the UI never reaches the feed. This cascades into `PROFILE_ROOT_NOT_CONFIRMED` during account switching because there is no profile root.

**Required pattern — force-stop, launch, verify feed, retry, MANUAL_REVIEW:**

```python
def _handle_open_tiktok(self) -> bool:
    package = self.context.config["tiktok_package"]
    adapter = self.context.adapter
    feed_indicators = ["for you", "following", "đề xuất", "home_tab",
                       "com.ss.android.ugc.trill:id/home"]

    for attempt in range(1, self.ui_retry_limit + 1):
        # 1. Force-stop guarantees a cold start (resets stuck SplashActivity)
        adapter._adb.shell(["am", "force-stop", package], timeout=10, check=False)
        time.sleep(2)

        # 2. Launch via monkey → am start fallback
        if not adapter.launch_app(package):
            if attempt < self.ui_retry_limit: time.sleep(3); continue
            break  # exhausted → MANUAL_REVIEW

        # 3. Poll UI dump for feed indicators (30s timeout, 2s interval)
        if _wait_for_feed(adapter, feed_indicators, timeout=30):
            return True
        if attempt < self.ui_retry_limit: time.sleep(2)

    # All retries exhausted → MANUAL_REVIEW
    self.context.is_ui_unavailable = True
    self.context.error = (
        f"[OPEN_TIKTOK_FAILED] TikTok không load feed/home sau "
        f"{self.ui_retry_limit} lần force-stop+launch. "
        f"Cần MANUAL_REVIEW: mở TikTok thủ công, kiểm tra login/onboarding."
    )
    return False
```

**Key rules:**
- **Force-stop every attempt** — a stuck SplashActivity will not recover without killing the process. Not optional.
- **Poll UI dump for feed** — returning True just because the ADB command succeeded is the root cause of the machine-62 bug. The only signal that matters is finding feed markers (`for you`, `following`, `đề xuất`, `home_tab`) in the UI XML.
- **Inner retry loop** — each attempt does one complete force-stop+launch+wait cycle. After all retries, `is_ui_unavailable=True` forces the outer `_execute_with_ui_retry` to break and `_transition(False)` to route to MANUAL_REVIEW (not FAILED).
- **MANUAL_REVIEW, not FAILED** — a device that can't reach the feed after repeated cold starts won't fix itself on a job-level retry. The user must intervene.

### Soft reboot recovery (optional escalation before MANUAL_REVIEW)

When all `ui_retry_limit` launch attempts fail, the consumer can attempt a **device soft reboot** before escalating to MANUAL_REVIEW. This is gated by a config opt-in (`allow_device_reboot_recovery`, defaults `False` — fail-closed).

**When to add this:** Devices that occasionally enter a deep hang state where even force-stop + cold launch cannot reach the feed, but a full Android boot cycle clears the condition. Samsung S7-era farm devices are the typical case.

**Required pattern — reboot sequence, then retry launch once:**

```python
def _soft_reboot_recovery(self, adapter, package, feed_indicators) -> bool:
    # 1. adb shell reboot
    # 2. adb wait-for-device (120s timeout)
    # 3. Poll sys.boot_completed=1 via getprop (60s timeout)
    # 4. am force-stop TikTok
    # 5. adapter.launch_app(package)
    # 6. _wait_for_feed(adapter, indicators, timeout=30)
    # Return True only if feed confirmed after reboot
```

**Integration point in `_handle_open_tiktok`:** Between the retry loop and the MANUAL_REVIEW block:

```python
# After the for-loop exhausts all attempts
allow_reboot = self.context.config.get("allow_device_reboot_recovery", False)
if allow_reboot:
    reboot_ok = self._soft_reboot_recovery(adapter, package, feed_indicators)
    if reboot_ok:
        return True  # recovery succeeded, workflow continues
    # fall through to MANUAL_REVIEW
```

**Key rules:**
- **Config opt-in, fail-closed** — `allow_device_reboot_recovery` defaults `False`. Must be explicitly set to `True` in the YAML/JSON config file.
- **Log every step** — use `[REBOOT_N/6]` prefix so the log is grep-able during debugging.
- **wait-for-device needs 120s** — some Samsung farm devices take 60-90s to reappear after reboot. The default ADB connection timeout (20s in AdbClient) is too short for this path; pass `timeout=120` explicitly via `adb.run(["wait-for-device"], timeout=120, check=False)`.
- **sys.boot_completed polling** — after `wait-for-device` returns, the device is in `device` state but Android may still be booting. Add a secondary 60s polling loop checking `getprop sys.boot_completed` → `"1"` before assuming readiness.
- **Settle time** — insert `time.sleep(5)` after boot completes before force-stopping or launching. Some devices need a moment after `sys.boot_completed=1` for the UI layer to stabilize.
- **On failure → MANUAL_REVIEW** — if any reboot step fails or the post-reboot launch still can't reach the feed, the handler must fall through to the existing MANUAL_REVIEW path (with `is_ui_unavailable=True`). Never loop back into the retry cycle — reboot is the last resort.
- **Reuses existing infrastructure** — force-stop, `launch_app`, and `_wait_for_feed` are the same methods used in the normal retry loop. No new automation-core changes needed.
- **Error messages include reboot context** — when reboot was attempted and also failed, append "Soft reboot recovery cũng thất bại." to the MANUAL_REVIEW error so the operator knows reboot didn't help.

**Reference implementation:** See `references/device-reboot-recovery.md` for full code, logging format, and the session that introduced this pattern.

### _wait_for_feed helper

```python
def _wait_for_feed(self, adapter, indicators: list[str], timeout=30) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            xml = adapter.dump_ui().lower()
            if any(ind in xml for ind in indicators):
                return True
        except Exception:
            pass
        time.sleep(2)
    return False
```

## Device Lock Policy

- Device lock via `automation_core.device_lock.acquire_device_lock()`.
- Workbook lock via `automation_core.workbook.acquire_workbook_lock()`.
- Locks released in `finally` (via `_release_leases()`).
- **Consumer-side unlock recovery**: After `prepare_device()` returns, if `unlock_state == "locked_or_secure"`, the consumer MUST retry swipe-unlock with more aggressive parameters before proceeding. Do NOT blindly proceed (TikTok won't render on a genuinely locked screen) and do NOT immediately escalate to MANUAL_REVIEW (the core swipe may have been close but slightly mis-timed for this device).
  - Retry swipe from 95% height → 25% height (steeper than core's 85%→35%), with 500ms duration (longer than core's 280ms)
  - Verify unlock via `dumpsys window policy` — check that `mShowingLockscreen=false`, no `keyguardShowing=true`, etc.
  - Up to 3 retry attempts (match `ui_retry_limit` pattern)
  - If retries succeed → continue normally
  - If retries exhausted → `is_ui_unavailable=True` → MANUAL_REVIEW (ask user to unlock manually)
- **Keyguard detection patterns** (reusable module-level constants matching `automation_core.device._window_state()`):

  ```python
  _LOCKED_PATTERNS: tuple[re.Pattern[str], ...] = (
      re.compile(r"mShowingLockscreen\s*=\s*true", re.IGNORECASE),
      re.compile(r"isStatusBarKeyguard\s*=\s*true", re.IGNORECASE),
      re.compile(r"keyguard(?:Showing|Locked)?\s*=\s*true", re.IGNORECASE),
      re.compile(r"showing\s+keyguard", re.IGNORECASE),
  )

  def _is_locked_in_dumpsys(text: str) -> bool:
      return any(pattern.search(text) for pattern in _LOCKED_PATTERNS)
  ```

### Lock retention semantics (MANUAL_REQUIRED / FINAL_BLOCKED)

Classification chia 3 nhánh trong recovery supervisor:
- **DEFERRED_LOCKED** (`lock_safe=False`): lock đang ACTIVE/FOREIGN/BUSY/UNVERIFIABLE → idempotent, không đụng, chờ.
- **MANUAL_REQUIRED** (`lock_safe=True`): sensitive (OTP/2FA/account/mailbox) HOẶC final (cap exhausted/crash) → cần người.
- **AUTO_RECOVERY_PENDING** (`lock_safe=True`): lỗi thường (CAPTURE_INVALID, ADB, network) → tự sửa.

`lock_safe=True` ≠ "giữ lock" — nó nghĩa là **không có lock đang giữ máy**, an toàn để người khác đụng. Lock chỉ giữ khi **đang recovery thật** (owner_active=true).

**Lỗ hổng thiết kế đã sửa (2026-08-06)**: trước đây máy fail (vd CAPTURE_INVALID) → release lock → shift hôm sau nhặt lại y hệt → cày lại 7-slot ladder mỗi lần, tốn quota, không bao giờ tự sửa. `incident_key` = `schedule_day + shift + machine + account_row + failure_signature + artifact_dir` → "terminal" chỉ tồn tại trong cùng shift.

**Fix (consumer-scoped, không đụng core)**: flow `finally` đổi `lease.finish(succeeded=goal_completed)` → `lease.set_status("blocked")` khi fail (giữ lock file, owner_active=false); success giữ `finish(succeeded=True)` (release như cũ). Lock `blocked` không thuộc `_ACTIVE_DEVICE_LOCK_STATUSES` → `acquire_device_lock` từ chối khi shift mới gặp (không takeover nếu không authorize) → máy bị skip, không cày lại.

### Manual release script (gỡ lock tay)

User cần chạy lại máy bị retained → script `python_runner/scripts/release-device-lock.py`:
```
PYTHONPATH=python_runner:. python python_runner/scripts/release-device-lock.py --machine 60 [--serial ...] [--lock-root ...] [--dry-run]
```
- Từ chối active lock (`owner_active=true`) → exit 3 (fail-closed, không đụng worker đang chạy).
- Release blocked/handoff/temporarily_skipped/queued + stale running (PID chết) → exit 0, xóa file, audit JSONL.
- Dùng core `_release_lease_paths(lease_stub, strict=False)` — không xóa tay; stub cần `host/pid/lock_id/lock_paths`.
- Chỉ release lock cùng host (không reclaim remote host).
- **Windows PID check**: `os.kill(pid,0)` KHÔNG đáng tin trên Windows (PermissionError với PID không tồn tại → coi alive sai). Dùng `tasklist /FI "PID eq X" /NH` (check PID string trong stdout).

Chi tiết đầy đủ + test: `references/lock-retention-manual-release-2026-08-06.md`.

## ADB

- ADB is NOT in PATH. Must use explicit path:
  `C:\\Program Files (x86)\\xiaowei\\tools\\adb.exe`
- Configurable via `adb_path` config key.
- `DeviceTransport.__init__` and `AdbClient` both consume `adb_path`.
- **Discovery pattern**: Before live run, check actual ADB availability:
  1. Try `adb_path` config key
  2. Fall back to sibling project config: `python_runner/config.example.yaml` has `adb_path: C:\\Program Files (x86)\\xiaowei\\tools\\adb.exe`
  3. Run `adb -s <serial> get-state` AND `getprop ro.product.model` before any live action.
- **Preflight required after code APPROVED**: Fixture approval is NOT sufficient for live readiness. After Claude APPROVED but before first live run, must:
  1. Read the **real** workbook and check header aliases (e.g. `ID` vs `ID TikTok`, `Máy` vs `May`)
  2. Resolve numeric column types (e.g. `Folder Video = 489.0` → folder `489`)
  3. Check machine-first-row selection and serial/device ID extraction
  4. Verify next-video path exists on disk
  5. Run `adb devices -l` with the exact configured ADB path
  6. Verify no machine or serial lock for the target
  7. **Only then** start the live workflow
- **Lock check**: Must check BOTH `machine_<n>.lock.json` AND `serial_<serial>.lock.json`. A stale serial lock (PID dead) does not block but must be noted.

## Workbook Mapping Pattern

- `Tik1.xlsx` (D:\\OneDrive\\Tiktok\\Tik1.xlsx) is the canonical workbook.
- Columns: `Máy | device ID (= ADB serial) | ID (= TikTok ID) | Folder Video | video gốc | Keyword Video | Hashtag Pool | Video Đã Đăng | Kiểm Tra Dữ Liệu`.
- **No `account_profile` YAML.** All mapping comes directly from the workbook.
- Each workbook (Tik1, Tik2, Tik3, ...) is an independent workflow.
- Consumer supports `--workflow-workbook` CLI arg to point to any TikN workbook.
- Machine-first-row selection: first row per machine number in the workbook.
- Serial/device ID from the workbook is the ADB serial directly.
- **Workbook lock workaround**: When pandas/permission fails on OneDrive-synced workbooks, use `openpyxl.load_workbook(path, read_only=True, data_only=True)` instead. This avoids file-lock conflicts with OneDrive sync.

### Inventory/Reconcile: Separate Mapping from Credential Tracking

For account reconciliation, do **not** force one workbook to serve two incompatible schemas:

- **Safe mapping workbook** is the source for inventory: machine number, ADB serial/device ID, and expected TikTok IDs. Pass it as `--workbook`.
- **Tracking workbook** (for example `taikhoan_dat_v2_updated .xlsx`) is the source for account/login fields. Pass it separately as `--tracking-workbook`; it is read only when an expected account is missing on-device and needs a login attempt.

Required flow:

```
safe mapping: machine + device ID + expected IDs
→ inspect account switcher
→ reboot/refresh only for an evidenced stale-navigation signature
→ select only expected IDs still missing on device
→ tracking workbook: retrieve the matching account data for those IDs
→ login and verify switcher again
```

Rules:
- Never pass the credential-tracking workbook as the inventory mapping merely because it contains account IDs; it may not have a usable serial header.
- Never derive credentials from the safe mapping workbook; it intentionally omits them.
- The reconciliation CLI should require distinct explicit arguments (`--workbook`, `--tracking-workbook`) and thread the tracking path only into the login-provider selection function.
- Before a live run, run a read-only parser check against the exact safe workbook: selected machine resolves to exactly one serial and the expected account count is nonzero. Treat a schema error as a pre-lock/config failure, not a device failure.
- Add regression tests proving the two paths are distinct and that only `device_missing` IDs are requested from the tracking provider.

### Canonical Header Normalization

Headers have many variants. Always normalize with:
- Unicode NFKC
- NBSP (\\u00a0, \\u200b) → space
- Collapse whitespace
- lowercase
- Strip diacritics (đ→d, ê→e, etc.)
- Known aliases per field (e.g. "ID" / "username" → "ID TikTok")

**"Missing required fields: ID TikTok" — check the CELL, not the header:**
Header `ID` map đúng qua alias → `ID TikTok`, nhưng nếu **giá trị ô trống
(None)** cho máy đó thì `validate_row()` vẫn throw
`AccountSourceError("Missing required fields: ID TikTok")`. Đừng mất thời gian
vào code path/alias — debug theo thứ tự:
1. Chạy `AccountSource(...).read_row()` trực tiếp cho máy đó → xem row keys
   và giá trị `ID TikTok`.
2. Đọc workbook bằng openpyxl in ra header canonical + giá trị các máy fail:
   ```python
   import openpyxl
   from tiktok_workflow.account_source import canonical_header
   wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
   sheet = wb["TaiKhoan"]
   headers = {i+1: canonical_header(c.value) for i, c in
              enumerate(next(sheet.iter_rows(min_row=1, max_row=1)))}
   # ... in row theo máy, check headers[c] == "ID TikTok" và giá trị
   ```
3. Header map ổn mà giá trị None → **dữ liệu workbook thiếu**, báo user điền
   hoặc loại máy đó khỏi danh sách chạy (không phải bug code).

**Serial column aliases** (all known variants — missing one causes `CONFIG_ERROR: account workbook is missing serial column`):
- `"so seri"`, `"series model may"`, `"phoneid"`, `"phone id"`, `"serial"`
- `"device id"`, `"deviceid"` ← real-world workbooks often use "device ID" as the column header
- When adding a consumer, always check the actual workbook column headers with `openpyxl` before hardcoding `SERIAL_HEADERS`.

### `taikhoan_dat_v2_updated .xlsx` column layout (verified 2026-08-10)

Source tracking workbook `D:\OneDrive\Tiktok_Reg\taikhoan_dat_v2_updated .xlsx`, sheet `Tài Khoản`:

| idx | Header | Ghi chú |
|---|---|---|
| 0 | Máy | |
| 1 | Tik | |
| 2 | ID | TikTok ID |
| 3-6 | PASS / 2FA / GMAIL / PASS MAIL | credentials — không in/log |
| 7 | NGÀY THÁNG NĂM SINH | DOB |
| 8 | NGÀY TẠO | |
| **9** | **device ID** | **= serial/ADB serial — cột serial ĐÚNG** |
| 10 | (không header) | rác — không đọc |

**Pitfall shifted columns:** có lịch sử 23 dòng bị lệch 1 cột — DOB/NGÀY TẠO đẩy sang phải,
serial rơi xuống cột 10 (K). Script cũ `tiktok-log-in/scripts/sync_taikhoan_run_safe.mjs` đọc
`row?.[10]` (SAI) → `SOURCE_SERIAL_CONFLICT:<máy>:0` khi source gần như không còn serial ở cột đó.
**Luôn đọc serial ở idx 9, và xác nhận bằng regex serial** (`^[0-9a-fA-F]{14,20}$`) thay vì tin vị trí
cố định — nếu cột 9 toàn ngày tháng (dạng `dd/mm/yyyy`) thì đang lệch cột, cần shift
(c10→c9, c9→c8, c8→c7) trước khi đồng bộ.

**Canonical sync script:** farm tự động rebuild `taikhoan_run_safe.xlsx` qua
`tiktok-luot nuoi acc/scripts/sync-safe-workbook.py` (đọc header linh hoạt, EXTRA_MACHINES 75-80,
6 slots/máy, atomic publish qua `single_writer_workbook_update` + reopen-verify). Đừng viết script
sync mới — tái sử dụng script này; wrapper cron chỉ cần gọi nó (xem
`consumer-scheduler-orchestration/references/hermes-cron-watchdog-sync-example.md`).

### Excel Data Type Pitfalls

- `Folder Video` can be an int/float (489 or 489.0). Must convert safely:
  `int(x) → str(x)` for int, `str(int(x)) if x == int(x) else str(x)` for float.
- `Video Đã Đăng` can be int/float/None. Must int-cast with zero default.
- `EmptyCell` (openpyxl read-only mode) has no `column_letter`. Iterate by index.
- `video_number` override must propagate to `context.video_number` and workbook write.

## ACCOUNT_SWITCHER Error Handling — Simplified (v2)

`_handle_account_switcher()` calls `open_profile_root()` then `open_switcher()` from `automation_core.tiktok.account_switcher`. The consumer must **NOT** add fallback tiers, coordinate hacks, subpage-clearing helpers, or recovery pipelines. Core is the single source of truth for navigation.

### Required pattern

```
_handle_account_switcher():
  1. if not dismiss_popups_core(): return False  ← check is_ui_unavailable after dismiss
  2. open_profile_root(adapter)                  ← core call, no consumer fallback
  3. if not dismiss_popups_core(): return False  ← popups may appear after profile loads
  4. open_switcher(adapter)                      ← core call, no recovery tiers
  5. if not dismiss_popups_core(): return False  ← popups after switcher opens
  6. return True
```

**CRITICAL — check is_ui_unavailable after every _dismiss_popups_core() call.**
`_handle_dismiss_popups()` can fail silently (UI dump exception sets `is_ui_unavailable=True` and returns `False`). If the caller ignores the return value, the state machine proceeds into core navigation with a broken UI, producing confusing downstream errors. Always gate: `if not self._dismiss_popups_core(): return False`.

On ANY core failure (AccountSwitcherError or other exception):
- Set `context.is_ui_unavailable = True`
- Populate `context.error` with `[ACCOUNT_SWITCHER_FAILED]` + core error + MANUAL_REVIEW instructions
- Save checkpoint
- Call `_detect_account_switcher_edge_cases()` for CAPTCHA/login detection
- Return False → state machine routes to MANUAL_REVIEW

### Helper methods

```python
def _dismiss_popups_core(self) -> bool:
    """Dismiss popups best-effort using core module.

    Returns:
        True nếu dismiss OK (hoặc không có popup), False nếu is_ui_unavailable bị set.
    """
    try:
        self._handle_dismiss_popups()
    except Exception:
        pass  # Best-effort
    return not self.context.is_ui_unavailable

def _fail_account_switcher(self, err_msg: str) -> None:
    """Centralized error logging → MANUAL_REVIEW."""
    self.context.is_ui_unavailable = True
    full_msg = (
        f"[ACCOUNT_SWITCHER_FAILED] {err_msg}. "
        f"Cần MANUAL_REVIEW: kiểm tra TikTok đã login chưa, "
        f"dismiss popup/onboarding thủ công rồi retry."
    )
    self.context.error = full_msg
    self.context.checkpoint.update({
        "last_state": WorkflowState.ACCOUNT_SWITCHER.value,
        "error": full_msg,
    })
    logger.error(full_msg)
    self._detect_account_switcher_edge_cases()
```

### Rules

- **No consumer-side recovery.** Do NOT add `_fallback_tap_profile_tab`, `_reset_to_home_feed`, `_reopen_tiktok_clean`, `_clear_profile_subpage_before_navigation`, or `_verify_clean_profile_root`. These have been removed from all consumers.
- **Only core: `open_profile_root` and `open_switcher`.** Do NOT import `leave_profile_subpage`, `is_switcher_open`, `is_profile_subpage`, or `find_switcher_anchor` from the consumer. Core handles all internal retries and subpage clearing.
- **All failures → MANUAL_REVIEW.** A device that can't navigate to profile/switcher after core's internal retries needs human intervention, not a job-level retry.
- **Dismiss popups before and after** every core navigation call. Use the existing `_handle_dismiss_popups()` which delegates to `automation_core.popup.detect_popup`.

### Core `coordinate_fallback` adapter hook (2026-08-07)

Core's `open_switcher` (and via delegation `open_account_switcher`) now honours
an optional adapter hook `coordinate_fallback(action: str) -> tuple[int, int] | None`.
Call order when no semantic anchor resolves: `switcher_image_point` → hook
(`action="switcher"`) → else raise `SWITCHER_ANCHOR_AMBIGUOUS`. Hook absent or
returning `None` = exactly the old behaviour (no crash, no TypeError) — fully
backward compatible. A consumer with a legit coordinate need (stale/frozen dump
on a specific device) should implement THIS hook, not any consumer-side
coordinate hack. Contract wording, call-site order, and pytest recipes for the
hook (with/without hook, XML fixtures that reliably yield no-anchor):
`references/account-switcher-coordinate-fallback-2026-08-07.md`.

## Các section chi tiết (trim 2026-08-09)

> adb-install-and-topology-notes.md

