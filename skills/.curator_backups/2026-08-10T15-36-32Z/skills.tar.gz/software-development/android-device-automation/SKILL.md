---
name: android-device-automation
description: Patterns for automating Android devices — VPN preflight, TikTok login flows, UI popup handling, AdbKeyboard input, and reconcile workflows across consumer repos.
---

# Android Device Automation

General patterns for automating Android devices (Samsung SM-G930 series) in consumer
repos that depend on `automation-core`. Covers TikTok login, account inventory,
VPN/proxy preflight, popup dismissal, and the reconcile workflow.

## VPN / Proxy Preflight (MANDATORY)

Before ANY device interaction after a reboot, the VPN must be connected. The
workbook `PROXYgandienthoai.xlsx` maps serials to proxy requirements.

```python
from automation_core.preflight import require_android_vpn, serial_is_mapped_in_workbook
from automation_core.adb import AdbClient

adb = AdbClient(adb_path, serial, default_timeout=20)
require_android_vpn(
    adb,
    required=serial_is_mapped_in_workbook(
        proxy_mapping_path, serial,
        serial_headers=("phoneId", "deviceId", "serial"),
    ),
)
```

This check MUST run:
- After acquiring device lock, before any device action
- In the `verify_post_reboot` callback of `reboot_and_restore`

If the proxy watcher (`gan-proxy/scripts/vi_c`) holds a lock, the device is NOT
ready — skip or wait; never force-run without VPN.

## Target Identity Reconciliation (Mandatory for Recovery)

A machine number is not sufficient target identity: workbook mappings can change
between a failed run and a later manual check. Before inspecting, resuming, or
running recovery from an artifact:

1. Read the incident artifact's recorded target/serial.
2. Resolve the **current** machine-to-device-ID mapping from the approved
   config/workbook, reading only the required mapping fields.
3. Compare them before acquiring or using a lock. If they differ, stop recovery:
   report `MACHINE_SERIAL_MAPPING_MISMATCH` with redacted identifiers and treat
   the old artifact as a different target until an operator reconciles it.
4. A read-only status probe may confirm the current mapped device is online, but
   must never be presented as evidence that it is the device in the old artifact.

This prevents replaying a capture/UiAutomator recovery against a different phone
that happens to have the same machine label.

## Consent / Popup Dismissal

After TikTok data-clear or fresh install, multiple popups can appear:

### UniversalPopupActivity (consent popup)
- **Activity**: `UniversalPopupActivity`
- **Detection**: use `dumpsys activity activities` (NOT `uiautomator dump` — it hangs on Samsung)
- **Dismissal**: swipe up from bottom

```python
activities_text = str(adb.shell(["dumpsys", "activity", "activities"]).stdout)
if "UniversalPopupActivity" in activities_text:
    adb.shell(["input", "swipe", "540", "1600", "540", "400", "300"])
```

### Google Sign-In Popup
- **Activity**: `AssistedSignInActivity` (package `com.google.android.gms`)
- **Dismissal**: back key

### Google Play Post-Install Popups (2026-07-29)
After `force-stop` + `monkey start`, Google Play Store may show on devices where it hasn't been fully initialized (first-time setup after factory reset):
1. **ToS**: `com.android.vending/...TosActivity` — "Điều khoản dịch vụ" with "Chấp nhận"/"Từ chối". Tap "Chấp nhận".
2. **PlayCore**: `com.android.vending/...PlayCoreAcquisitionActivity` — "TikTok cần tải các tệp bổ sung". Tap "Tải xuống qua Play".

Detection: check `current_package == "com.android.vending"` in the startup wait loop. After dismissing, re-issue `monkey -p <pkg> 1`. Handled by `_dismiss_play_popups()` in `account_inventory.py`.

### Profile Navigation Fallback
When `navigator.tap_profile(screenshot)` (image-based navigation) fails, fall back to coordinate tap:
```python
navigator.tap(972, 1857)  # Profile tab bottom-right at 1080x1920
```

## TikTok UI Versions

| Version | Signup → Login path |
|---------|-------------------|
| 46.x (legacy) | Account switcher → Add account → "Sử dụng số điện thoại/email/tên người dùng" → Email tab |
| 44.2.3 (newer) | Account switcher → Add account → "Bạn đã có tài khoản? Đăng nhập" → "Sử dụng số điện thoại/email/tên người dùng" → Email tab |
| 37.x (machine 7) | Signup screen → back once → "Tiếp tục với email/tên người dùng" |

**Rule**: The `choose_login_method` code in the adapter must NOT hardcode one path.
Always check for text presence and fall through. The signup screen has both
"Tiếp tục với email" (signup) and "Bạn đã có tài khoản? Đăng nhập" (login link at bottom).

## AdbKeyboard Text Input

- **IME**: `com.github.uiautomator/.AdbKeyboard`
- **APK source**: `D:\Taadaa\tiktok-luot nuoi acc\.ai-runs\*\app-sync\source_60\apks\com.github.uiautomator\00_base.apk`
- **Send text**: `am broadcast -a ADB_KEYBOARD_INPUT_TEXT --es text <base64>`
- **Pitfall**: On SM-G930W8, broadcast returns `result=-1` and ADB shell hangs after broadcast. Text IS entered successfully though — use fire-and-forget with short timeout (5-8s), don't wait for shell exit.
- **Alternative**: `adb shell input text <base64>` only works if AdbKeyboard is active IME, and the plain-text form can leak special chars. Prefer broadcast.

## 2FA / TOTP

TikTok accounts may require 2FA. The TOTP secret is stored in the tracking workbook
column `2FA`. Use `pyotp` to generate codes:

```python
import pyotp
code = pyotp.TOTP(totp_secret).now()
```

Codes expire every 30s — generate and submit immediately (don't generate ahead of time).

## Post-Login Popups

After successful login, dismiss these popups in order:
1. "Cho phép TikTok truy cập vào danh bạ?" → tap "TỪ CHỐI"
2. "Hãy cùng kiểm tra bảo mật nhanh nhé" → tap "Đóng" (top-right corner)
3. Privacy policy (`SparkActivity`) → scroll to bottom, tap "Agree"/"Đồng ý" (rendered in WebView, not detectable by uiautomator — use coordinate taps at y=1700-1850 after heavy scrolling)

## Reconcile Script Patterns

The reconcile script (`scripts/reconcile_tiktok_accounts.py`) does:
1. Acquire device lock
2. VPN preflight (with `--proxy-mapping`)
3. Inventory device accounts via `collect_device_inventory`
4. Compare with workbook
5. Login missing accounts
6. Verify

If inventory fails with a rebootable error, soft-reboot and retry. The `_soft_reboot`
function MUST pass `proxy_mapping` to `reboot_and_restore`'s `verify_post_reboot`
callback, which calls `require_android_vpn`.

### Parent-held lock across reboot

If reconcile intentionally retains the machine+serial lock across reboot, it must not merely wait for a proxy watcher that needs the same lock. Use `reboot_and_restore(..., wait_for_proxy_ready_after_reboot=...)` so the parent invokes the existing proxy provider under its own lease, then verify `tun0` plus Android VPN. The provider must verify the parent PID/host/machine/serial/lock-id before loading the scoped mapping; never expose the proxy through argv/logs.

When using `acquire_device_lock(..., live_vpn_verifier=fn)`, ensure the core version propagates `fn` into `wait_for_proxy_ready`. A stale `proxy_pending` marker plus `verifier_calls=[]` is evidence of a propagation regression. Fix in isolated automation-core worktree, use the merge guard, bump from the current version, run tests with `PYTHONPATH=src`, build/verify/install the wheel between live runs, then live-probe lock acquisition.

## automation-core API Notes (v0.2.40+)

- `reboot_and_restore(adb, *, cleanup_before_reboot, recover_post_reboot, verify_post_reboot, boot_timeout=180)` — all 3 callbacks are REQUIRED keyword-only args
- `wait_until_unlocked(adb)` — use as `recover_post_reboot`
- `prepare_device(adb)` — returns `DeviceReadiness`; use inside `verify_post_reboot` (or wrap with VPN check)
- `soft_reboot_and_wait` was REMOVED in v0.2.40; use `reboot_and_restore` instead

## SM-G930 Model Differences

| Model | Behavior |
|-------|----------|
| SM-G930F | Standard. Broadcast works normally. |
| SM-G930W8 | Broadcast hangs shell. Swipe-unlock pattern may differ. |

## Reference Files

- `references/tiktok-coordinates.md` — exact coordinates, resource-ids, workbook paths, and popup dismissal patterns (verified 2026-07-29)
- `references/gmail-otp-magic-link.md` — Gmail OTP/magic-link reading for TikTok reg: TikTok sends a link not a code, search-loop bugs + fixes, auto-sync OFF root cause, Gmail live-check on OTP timeout (incl. identity-verify classifier gap), CAPTCHA-dead mailbox delete flow via add-mail repo, existing-account login, MACHINE_DEVICES int/str key pitfall

## Pitfalls

- **NEVER `pm clear` (or delete app data for) TikTok `com.ss.android.ugc.trill` without an explicit user command.** User fury incident 2026-08-07: clearing TikTok data wiped every account/session logged into that device (machine 34 lost someone else's accounts). It also does NOT log the device out of the bound account anyway (session is device-bound server-side, see below) — so it's both destructive AND useless. To switch/remove a TikTok account: use in-app logout, or ask the user. This rule is also written into `Tiktok_Reg/AGENTS.md` and `add mail khoi phuc/AGENTS.md` (Safety And Ownership).
- **uiautomator dump hanging (E=137 / "Killed" / "Bad file descriptor") = atx-agent wedged.** Force-stopping `com.github.uiautomator*` packages alone does NOT release the UiAutomationService handle — the helper process holds it. **Use `pkill -9` (SIGKILL), NOT plain `pkill` (SIGTERM)** — a wedged atx-agent parks in `futex_wait_queue_me` (S-state) and silently IGNORES SIGTERM (pkill exits 0 but the process survives, dump stays E=137 forever, runner stuck in a transport-recovery loop). `pkill -9 -f atx-agent` kills it hard and dump returns to exit 0 immediately (live-proven SM-G930F/W8; machine 34 2026-08-07: SIGTERM E=137 persisted, SIGKILL → E=0 instantly). A wedged `uiautomator dump` child additionally needs `pkill -9 -f uiautomator` ("could not get idle state" persists after atx kill alone; may return "Operation not permitted" for the u0_a196 app — harmless, atx kill + `uiautomator quit` suffice). This is NOT a reason to reboot. Core logic: `_recover_uiautomator` in automation-core ≥0.4.43 uses SIGKILL (markers `ATX_AGENT_PROCESS_MARKER`, `UIAUTOMATOR_PROCESS_MARKER`). Manual one-shot: `adb shell pkill -9 -f atx-agent; adb shell am force-stop com.github.uiautomator; adb shell uiautomator quit; uiautomator dump` → E=0.
- **Restarting atx-agent after a kill/reboot**: `adb shell /data/local/tmp/atx-agent -d` FAILS (`unknown short flag '-d'`) — the correct start command is `adb shell "nohup /data/local/tmp/atx-agent server >/dev/null 2>&1 &"` (listen on 7912). After starting the process you must ALSO start the uiautomator service via `curl -X POST http://127.0.0.1:7912/uiautomator` (port-forwarded) — until it returns `{"running":true}`/`Already started`, core `capture_ui_xml` with `provisioning_policy=REQUIRE_PROVISIONED` keeps failing with `DEVICE_NOT_PROVISIONED` even though `get_ui_xml` (shell dump) works. Symptom pattern to recognize: shell `uiautomator dump` returns E=0 but the consumer flow still logs `automation-core failed code=DEVICE_NOT_PROVISIONED` — that's the persistent-uiautomator service, not the shell dump, and not a real provisioning problem.
- **automation-core ≥0.4.38 REMOVED the old transport-recovery API** (`AndroidTransportRecoveryError`, `MissingVpnRecoveryError`, `recover_android_transport`, `recover_missing_android_vpn` from `device_recovery`). Consumer runners importing those break with `ImportError` right after upgrade. **RESOLVED 2026-08-07 — the 4 symbols + 2 result dataclasses were merged verbatim from wheel 0.4.32 into source** (`automation-core/src/automation_core/device_recovery.py`) → core **0.4.42** (legacy API + expected_marker) → **0.4.43** (pkill -9 SIGKILL). No more venv cherry-pick; upgrade path is now `pip install --force-reinstall --no-deps <new-wheel>` + bump `REQUIRED_CORE_VERSION` in the runner (else `AUTOMATION_CORE_VERSION_MISMATCH:expected=...;actual=...` at import). If you hit the old-API ImportError on a stale venv, reinstall ≥0.4.42. (Signature note: 0.4.32-era `AndroidTransportRecoveryError.__init__(serial, state_path, reason)` — positional, NOT kwarg-only `state_path=`.)
- **A logged-in TikTok session on S7 is device-bound and survives `pm clear` + android_id reset + GMS clear.** TikTok binds server-side via firmware-level ID. TikTok 46.x profile exposes no Settings/Add-account node in the a11y tree, so scripted UI logout is not possible. If the bound account isn't yours, factory reset (`adb shell recovery --wipe_data`) is the only clean path — confirm with the user first (loses all accounts/config). Do NOT assume the visible @handle is the target email's account (machine 34 was logged into someone else's `@skiperenok`).
- **Google `AssistedSignInActivity` overlay after TikTok data-clear**: with Google accounts on the device, relaunching TikTok can land on `com.google.android.gms/.auth.api.credentials.assistedsignin.ui.AssistedSignInActivity` over the TikTok profile, blocking `[02_profile]`/`[04_add_account]` → `TIKTOK_STARTUP_NOT_FOREGROUND`. Dismiss with BACK (`input keyevent 4`); it may reappear while the stale session persists.
- **Farm accessibility is OFF (`settings get secure accessibility_enabled` = 0, `enabled_accessibility_services` = null).** Chrome/WebView then exposes ONLY `url_bar` in the hierarchy — form fields (`loginfmt`, `i0116`, `i0118`, `passwordEntry`) and page text are invisible to `ui_xml`/`uiautomator dump` (returns 0 nodes). A login flow that "found the email field then can't find the password field" on this farm is usually this, not a selector bug. Screen is actually fine (screenshot shows the Microsoft login page); the tree just has no content. Workarounds: reset the tab and re-run (fresh render sometimes re-exposes), pick a machine whose Chrome session is clean, or use coordinate/screenshot-based fallbacks. Do NOT change shared selectors for this.
  - **Chrome 138 makes this worse and semantic fallbacks fail too**: `uiautomator dump` returns 0 nodes and `tap_text`-style semantic taps can't see buttons ("Could not select Keep me signed in: Yes"). **Coordinate fallback is the reliable escape**: pixel-scan the screenshot for the Microsoft blue button (b>140, 0<r<120, 60<g<140), tap the centroid. Verified on 1080x1920: keep-signed-in "Có/Yes" blue region x=[80,1000] y=[1000,1680], centroid `(540,1593)` → after tap, URL proof `outlook.live.com/mail/0/inbox` and login SUCCEEDS. TalkBack service is absent on the farm (`pm list services` empty) so enabling accessibility isn't an option.
- **Samsung OneUI task-switcher (RecentsActivity) can get stuck on top of Chrome.** Detection: `dumpsys activity top` shows `DecorView@...[RecentsActivity]` + `button_cancel`/`button_done` while `mResumedActivity` says Chrome; Back (`keyevent 4`) and HOME (`keyevent 3`) don't dismiss it. Fix: `am force-stop com.sec.android.app.launcher`, then `input keyevent 3`, then `am start -a android.intent.action.VIEW -p com.android.chrome -d <url>` to re-open Chrome cleanly. Run the automation again from the clean state.
- **TikTok home feed is misclassified as the personal profile by naive marker checks** (machine 34, 2026-08-07): `_is_personal_profile_screen_xml` returned True on the FEED, so the runner believed it was on the profile and called `open_account_switcher` on the feed → `SWITCHER_ANCHOR_AMBIGUOUS` → endless force-stop/relaunch loop. Feed false-positive sources and the fixes that work:
  - "Đã follow"/"Thích" appear in the feed bottom tabs → before accepting the follower-tab triple, require an extra header marker.
  - "Chia sẻ" ("chia se video") matches the feed share button → same header-marker requirement.
  - "follower" as SUBSTRING matches the feed share button "Đăng lại cho follower" → match follower count as a DEDICATED node with regex `^(?:[\d.,\s]*)?(?:nguoi dang follow|dang follow|followers?)$`, never substring.
  - Creator names (non-@, no-space, 3-30 chars, e.g. "Thanh Thượng Tiên") appear in the feed → profile-name detection requires `clickable=true` AND header region (bounds y1 ≤ ~300); creator names sit mid-screen (y>1000) and are `clickable=false`.
  - Also check the header marker BEFORE the home-feed guard inside `_is_personal_profile_screen_xml` (a stale dump can carry both feed and profile markers).
- **TikTok 46.x account dropdown opens by tapping the profile NAME, not a "switch account" marker**: profile header shows `text='yobi' bounds=[435,117][645,183]` (center ~540,150) with a notification badge (9+) covering the chevron; tapping the name node opens "Chuyển đổi tài khoản" + account list (yobi1965/xuanpham81/lyvy981...) + "Thêm tài khoản". Core `find_switcher_anchor` only finds it when the dump is fresh (kill atx first — see atx pitfall) and `identity` values include the display name (not just the @username).
- **`expected_marker` in core `capture_ui_xml` must be a state-UNIQUE marker**: passing "hồ sơ" (Profile) is useless — the "Hồ sơ" bottom-tab text exists on EVERY TikTok screen including the feed, so marker-miss never fires and the atx-kill retry never triggers. Pick a marker only present on the target state (e.g. the profile username, or "sửa hồ sơ"/"edit profile").
- **Some devices never render the TikTok Profile tab (machine 34 SM-G930K, TikTok 46.x):** tap profile tab → splash → back to feed, even right after reboot with fresh TikTok; dump stays feed ("Tây Ninh") while the log claims "profile selected" (that's `is_profile_tab_selected` false-positive on tab-selected+feed markers). The only proven winning path (run 182529: profile → dropdown → Add account → email → OTP) was when the machine was ALREADY on the TikTok login screen (`SignUpOrLoginActivity`) — the runner never needed the profile. **Fix: detect a login surface up front (`_is_login_method_surface_xml` / `_has_email_form`) and skip profile/dropdown entirely, falling straight through to `fill_email_and_next`** (step 7). Don't return early and don't call `continue_email_signup_from_entry` (that helper only matches `registration_entry` state, i.e. a logged-out profile, NOT a login screen). Note `SignUpOrLoginActivity` is NOT exported — `am start -n ...SignUpOrLoginActivity` fails with Security exception, so you cannot deep-link to it; and never log out a logged-in account to reach the login screen without asking the user (device-bound session is lost).
- **A crashed batch leaks BOTH `machine_<N>.lock.json` AND `serial_<SERIAL>.lock.json`** with the same dead PID (2026-08-07, machine 34). The next runner cleans one kind but still hits the other → `DEVICE_LOCKED` FINAL_BLOCKED in ~39s. Remove BOTH lock kinds before re-running. Verify PID death with **`wmic process where "ProcessId=N" get ProcessId,CommandLine`** — `tasklist //FI "PID eq N"` can silently return EMPTY even when the process is alive on git-bash, which would make you delete a live runner's lock. (A fresh runner may also create its own serial lock and still get blocked by the stale machine lock — clean both.)
- **Never** use `uiautomator dump` to check for popups in startup loops — it hangs on Samsung when UiAutomation service is busy. Use `dumpsys activity` instead.
- **Never** run device actions without VPN preflight after a reboot. The proxy watcher needs time to assign proxy.
- **Never** tap "Tiếp tục với email" on the signup screen — that's for creating NEW accounts. Tap "Bạn đã có tài khoản? Đăng nhập" at the bottom.
- ADB `keyevent 26` is POWER — toggles screen ON/OFF. Use `keyevent 82` (MENU) to wake without risk of turning screen off.
