---
name: hermes-profile-toolsets
description: "Create & verify Hermes profiles with toolset lockdown — agent.disabled_toolsets read-only coordinator (2-profile anti-self-write setup), runtime tool verification."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [hermes, profiles, toolsets, disabled_toolsets, lockdown, read-only, coordinator, delegation]
    related_skills: [hermes-agent, hermes-multi-deploy, hermes-orchestration-dispatcher]
---

# Hermes Profile Creation & Toolset Lockdown

Create isolated Hermes profiles (`~/.hermes/profiles/<name>/` — or `%LOCALAPPDATA%\hermes\profiles\<name>\` on Windows) and lock them down by disabling write/exec toolsets via `agent.disabled_toolsets`. Primary use case: the 2-profile anti-self-write design — a **read-only coordinator** session that cannot write files/run code, forcing it to delegate (`delegate_task`) to a **worker** running in the default profile.

**Rule of thumb for the lockdown list** — disable every toolset that can write/execute; keep every toolset that is read-only plus `delegation` (delegate_task is the whole point of a coordinator):

```yaml
agent:
  disabled_toolsets:
    - file            # write_file + patch (also removes read_file/search_files — accepted trade-off)
    - terminal        # terminal + process
    - code_execution  # execute_code
    - computer_use    # desktop GUI control
    - cronjob         # scheduled jobs
    - project         # workspace switching (project_create/switch)
    - memory          # memory writes
    - image_gen       # image_generate — auto-enabled by subset-inference, NOT default-off!
    - kanban          # board write tools (also check_fn-gated to workers; block at resolution level too)
```

## Verified mechanics (source-verified against hermes_cli)

- `agent.disabled_toolsets` is a **list of toolset NAMES** in `config.yaml`. In `hermes_cli/tools_config.py::_get_platform_tools` it is subtracted from the enabled-toolset set **AFTER** bundle expansion (`hermes-cli` → individual configurable toolsets), so it works correctly per toolset name and overrides everything else (incl. `hermes tools` picker).
- **`hermes config set` CANNOT write list values.** `set_config_value` (`hermes_cli/config.py`) only coerces bool/int/float. A JSON string `'["file","terminal"]'` is stored as a plain string → at runtime `{str(ts) for ts in <string>}` iterates CHARACTERS → silent no-op (nothing disabled, no error). Use the python yaml fallback below on the PROFILE config.
- `file` is NOT granular: `{read_file, write_file, patch, search_files}` in one toolset. Blocking it costs read_file/search_files. Decision: block anyway — keeping `file` lets the coordinator self-write, defeating the whole design. Coordinator verifies via worker reports, `session_search`, `skill_view`, web/browser.
- Traps: `image_gen` is auto-enabled by static subset-inference (its one tool `image_generate` is in `_HERMES_CORE_TOOLS` and image_gen is NOT in `_DEFAULT_OFF_TOOLSETS = {homeassistant, spotify, discord, discord_admin, video, video_gen, x_search}`). Same for `kanban` (tools in core; real schema is check_fn-gated to `HERMES_KANBAN_TASK` workers, but block it anyway for airtight resolution). `coding`/`debugging`/`project`/`safe`/`search` are NOT in `CONFIGURABLE_TOOLSETS` → they do NOT leak via subset-inference; no need to block.
- Toolset changes apply to **new sessions only** (prompt-cache invariant) — `/reset` or a fresh session.

## Steps

1. **Snapshot default profile integrity**: `sha256sum ~/.hermes/config.yaml` (before AND after — proof default untouched).
2. **Create profile** (inherits model/provider/.env/SOUL.md/skills/delegation/approvals from active profile):
   ```bash
   hermes profile create coordinator --clone --description "Coordinator: read-only, delegates workers"
   # --no-skills for empty; --clone-all for full state copy; alias wrapper created (e.g. coordinator.bat)
   ```
3. **Set `agent.disabled_toolsets`** — official CLI can't (see above), so use the bundled script:
   ```bash
   python scripts/set_disabled_toolsets.py <profile_config_path> [toolset ...]
   # e.g. C:\Users\<user>\AppData\Local\hermes\profiles\coordinator\config.yaml
   ```
   This is the sanctioned fallback: yaml.safe_load → modify ONLY the profile's config → yaml.safe_dump(sort_keys=False, allow_unicode=True). Never hand-edit the DEFAULT config; default's `hermes config set` is the only path there.
4. **Verify chain** (all PASS required):
   - `hermes profile list` (◆ marks active) + `hermes profile show <name>` (path/model/skills/.env)
   - `hermes --profile <name> config check` (version ✓, no errors); `hermes --profile <name> config path` routes to profile file
   - **Runtime tool resolution** — the real proof (not grep): `python scripts/verify_profile_tools.py <profile_config_path>` — calls `_get_platform_tools(cfg, "cli")` + `resolve_toolset()` and asserts write tools ABSENT / read+delegate PRESENT. Exit 0 = lockdown intact.
   - `sha256sum ~/.hermes/config.yaml` unchanged; optionally re-resolve DEFAULT profile and confirm write_file/patch/terminal still PRESENT (worker unaffected).
   - Smoke test a real boot: `hermes -p <name> chat -q "Reply with exactly: OK"` — must return the answer, not a tool error.

## Pitfalls

- **`hermes config set agent.disabled_toolsets '["a","b"]'` silently does nothing** (string stored → char-iteration no-op). Always python-yaml or verify after.
- **Do not disable `delegation`** on the coordinator — `delegate_task` is how it hands work to the worker profile. Worker = default profile via plain `hermes` (no `-p`).
- **Remaining soft-writes if `skills`/`browser` kept**: `skill_manage` (writes SKILL.md) and `browser_click`/`type` (web interaction, not local write). Documented trade-offs; add `skills`/`browser` to the list for absolute strictness.
- **YAML dump drops comments** in the cloned config — cosmetic only, runtime only cares about parseable structure.
- Profile dirs are per-profile isolated: sessions, skills, memories, cron. `--clone` copies skills → coordinator gets 100+ skills; `--no-skills` gives a bare profile.
- On Windows the venv python is `%LOCALAPPDATA%\hermes\hermes-agent\venv\Scripts\python.exe` (has yaml + hermes_cli importable with `sys.path.insert(0, <hermes-agent dir>)`).

## Support files

- `scripts/set_disabled_toolsets.py` — set the lockdown list on a profile config (parameterized)
- `scripts/verify_profile_tools.py` — runtime tool-resolution verification (write-absent / read-present asserts)
- `references/disabled-toolsets-mechanics.md` — source-verified internals: line numbers, full toolset→tools inventory, traps, final verified 23-tool coordinator inventory
