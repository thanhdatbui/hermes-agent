---
name: hermes-gateway-ops
description: Configure, run, verify, and extend the Hermes messaging gateway (Telegram setup, channel_overrides chat→repo binding, multi-session semantics, Windows install/terminal quirks).
---

# Hermes Gateway Ops

Trigger: set up or operate the messaging gateway (Telegram first), bind a chat/group to a repo via `channel_overrides`, explain multi-session on Telegram, verify a bot is online, or debug gateway config.

## CLI commands

```bash
hermes gateway setup          # wizard interactive — chọn platform, nhập token/user ID, tự ghi config, offer start/restart
hermes gateway                # chạy foreground (WSL/Docker/Termux khuyên dùng foreground)
hermes gateway start|stop|restart|status
hermes gateway install [--start-now] [--start-on-login] [--system] [--force]
hermes gateway list           # trạng thái tất cả profiles
hermes gateway enroll         # relay connector (experimental)
```

Gateway = **1 background process** chạy TẤT CẢ platform đã cấu hình cùng lúc + cron scheduler (tick 60s) + session store per chat + voice (STT/TTS). Token/secret → `.env`, KHÔNG bao giờ vào config.yaml; behavioral settings → config.yaml. Bots cần model provider + tool providers (TTS, web). Token lộ → BotFather `/revoke`.

## Setup (Telegram)

1. Bot: @BotFather → `/newbot` → token `123456789:ABC...` — **secret, never paste into chat** (user enters it in wizard or .env themselves).
2. User ID: @userinfobot → numeric ID.
3. Config: `hermes gateway setup` (wizard) OR edit `.env` at `$HERMES_HOME/.env` (Windows: `C:\Users\Kibe\AppData\Local\hermes\.env`):
   ```
   TELEGRAM_BOT_TOKEN=...
   TELEGRAM_ALLOWED_USERS=111111,222222   # comma-separated IDs
   ```
4. Start:
   - Foreground test: `hermes gateway`
   - Auto-start (Windows): `hermes gateway install --start-on-login --start-now` → creates Scheduled Task ONLOGON; if UAC is skipped it **falls back to a Startup-folder `.vbs`** — still works, no admin needed.
   - `hermes gateway restart` drains cleanly (auto-approved by smart approval).
5. Verify: `hermes gateway status`; log `%LOCALAPPDATA%\hermes\logs\gateway.log` for `[Telegram] Connected to Telegram (polling mode)` + `✓ telegram connected` + `set_my_commands OK`. Session key format: `agent:main:telegram:dm:<uid>` / `telegram:group:<chat_id>:<uid>`.

Gateway runs the SAME profile/config as the desktop (`config.yaml`), so the `/model` switcher on Telegram shows every provider configured on the machine — **numbers in parens = model count per provider** (`total_models`), not priority, NOT provider order (source-verified 2026-08-09 `plugins/platforms/telegram/adapter.py:5150` `_build_provider_keyboard`: `label = f"{p['name']} ({count})"`). `✔` = provider hiện tại của session. Set model cụ thể: `/model provider:model`.

## .env pitfalls (verified 2026-08-08)

- The .env often ships with **commented template lines** (`# TELEGRAM_BOT_TOKEN=...`). Users paste values onto them but keep the `#` → gateway silently ignores them. Uncomment both lines.
- Users paste the value **including the template's trailing comment** (`# Comma-separated user IDs` becomes part of the value → 54 chars, invalid). Strip with `value.split('#')[0].strip()`.
- Never print secret values; validate shape only (regex + char counts):
  - token: `^\d{6,12}:[A-Za-z0-9_-]{30,40}$`
  - users: `^\d+(,\d+)*$`
- Fix via byte-safe Python (preserve CRLF, keep everything else untouched), then re-validate.

## Windows terminal quirks (git-bash) — GUI launches

- `cmd //c start notepad` and bare `notepad.exe file` are **unreliable** (bare notepad blocks the shell and gets killed on timeout).
- **Working method: `explorer.exe "C:\path\to\file"`** — opens via default association (Notepad for .env) and the process survives.
- `tasklist //FI` is broken in git-bash (like `schtasks //Query`) → use `wmic process where "Name='x.exe'" get ProcessId,CommandLine`.
- PowerShell `-Command "..."` with `$_` gets bash-mangled (`$_` expands to last arg) → **always single-quote** the PS command: `powershell -NoProfile -Command 'Get-Process notepad | ...'`.

## channel_overrides — bind a chat/group to a repo

The built-in mechanism for "1 group = 1 repo": per-channel `system_prompt` (+ optional model/provider). Lookup matches **chat_id, then thread_id**. The binding is instruction-level (agent is told to `cd` into the repo every command), not a hard shell cwd pin — good enough for practical use; hard isolation would need separate gateway/profile per repo.

```yaml
gateway:
  platforms:
    telegram:
      channel_overrides:
        "-5435853713":            # group chat_id (quotes OK ở FILE yaml; còn CLI path thì KHÔNG nháy — xem bên dưới)
          system_prompt: "Bạn phụ trách repo D:\\Taadaa\\Tiktok-video (main). Trước MỌI lệnh terminal phải cd /d/Taadaa/Tiktok-video; tuân theo AGENTS.md/HANDOFF.md/PROJECT_RULES.md; không sửa file ngoài repo; không đọc credential/workbook."
```

- Set via CLI — **numeric key phải KHÔNG nháy** (đã dính bẫy và sửa thật 2026-08-08):
  `hermes config set gateway.platforms.telegram.channel_overrides.-5435853713.system_prompt "..."` → `hermes gateway restart`.
- PITFALL (lỗi thật trong session): set path kèm nháy như `...channel_overrides."-5435853713".system_prompt` → CLI ghi key literal `"-5435853713"` (cả dấu nháy là một phần key) → override **âm thầm không bao giờ khớp** (bot không nhận system_prompt). Kiểm tra key: `list(ov.keys())` qua python yaml — nếu thấy key/có nháy là sai. Sửa: set lại key không nháy, rồi xóa key nháy bằng python yaml load→safe_dump round-trip + `hermes config check` (CLI không có unset), xác nhận còn đúng `['-5435853713']`.
- **New system_prompt only applies to NEW sessions — user must run `/new` in the channel** (prompt is baked at session creation; an existing session keeps its old prompt).
- Get the chat_id: `grep -oE "telegram:(group|forum|dm):[0-9-]+" gateway.log | sort -u`.
- `hermes config get` does NOT exist — use `hermes config show`.

## Verification: override đã tới model chưa (state.db)

Không dựa vào tự báo cáo của bot — đọc transcript thật:
- `$HERMES_HOME/state.db` (SQLite): bảng `messages` có `session_id, role, content` — query session của chat lấy assistant answer + tool output, xác nhận agent làm đúng system_prompt (vd tự cd đúng repo trước lệnh).
- `system_prompts` table chỉ có `hash, prompt` (KHÔNG có cột session_id) — đừng query nó theo session_id.
- Session key → session_id: `$HERMES_HOME/sessions/sessions.json` (map session_key → session_id; group key dạng `agent:main:telegram:group:<chat_id>:<user_id>`).

## Multi-session semantics (verified in source)

- Session key = `platform:chat_type:chat_id[:thread_id]` → **every chat, group, and thread = a separate session/context**.
- Telegram DM **"New Thread"** client button (shown above the input box: "Type any message to create a new thread") → `message_thread_id` → separate Hermes session, natively supported. Not a slash command — no "thread" command exists; `/topic` handling exists in code for topic-enabled chats but is not a visible registered command.
- Commands: `/new` (reset context — does NOT create a new Telegram chat), `/title <name>` + `/resume <name>` + `/sessions` (named sessions, switch like tabs), `/background <prompt>` (parallel background run, result delivered back to the chat — fire-and-forget), `/sethome` (cron delivery target).
- Groups: unless BotFather Group Privacy is OFF (`/mybots → Bot Settings → Group Privacy`) or the bot is promoted to admin, the bot only sees `/`-commands and replies — ordinary group chatter is invisible.
- Deep-dive (source paths, SessionSource/thread_id, dm_topics config, ChannelOverride dataclass): see `references/multi-session-and-channels.md`.

## Telegram display presets and change discipline

Use this when the user asks about Telegram noise, progress, heartbeats, or process-result notifications.

### First: distinguish inquiry from authorization

- A question such as “can I revert it?”, “what modes exist?”, or “would preset X be better?” is **not** permission to change `config.yaml`.
- First inspect and report the current effective values and named choices. Apply `hermes config set` only after the user explicitly chooses a preset/key.
- After changing, read back the exact affected keys. State whether each setting is Telegram-scoped or global; do not claim a restart is needed unless verified.

### Naming for quick user requests

Call these **Telegram display presets**. The user can later say, for example, “set Telegram preset 1”. Define the chosen key values inline before applying; preset names are convenience labels, not a built-in Hermes enum.

| Setting | Valid/useful values | Scope and effect |
|---|---|---|
| `display.platforms.telegram.tool_progress` | `all`, `off`, `log` | Per Telegram. Tool-start/progress bubble; `log` writes locally rather than chat. |
| `display.platforms.telegram.tool_progress_grouping` | `accumulate`, `separate` | Per Telegram. `accumulate` edits one progress bubble; `separate` emits one per tool. |
| `display.platforms.telegram.interim_assistant_messages` | `true`, `false` | Per Telegram. Natural mid-turn status messages, independent of tool progress. |
| `display.platforms.telegram.long_running_notifications` | `true`, `false` | Per Telegram. Heartbeat for long-running turns. |
| `display.platforms.telegram.thinking_progress` | `true`, `false` | Per Telegram. Scratch/thinking relay; default to off in groups. |
| `display.background_process_notifications` | `all`, `result`, `error`, `off` | **Gateway-global**, not Telegram-only: `all` includes running output + final; `result` only final success/failure; `error` only non-zero final; `off` silent. |
| `streaming.enabled` | `true`, `false` | Global token-delta streaming; separate from tool/process progress. |

### Practical presets

1. **Theo dõi live, ít spam:** tool `all`, grouping `accumulate`, interim `true`, long-running `true`, background `result`, thinking `false`, streaming `false`. This gives one evolving progress bubble plus an outcome, without token/thinking noise.
2. **Theo dõi đầy đủ:** tool `all`, grouping `accumulate`, interim/long-running `true`, background `all`; use only when frequent live output is wanted.
3. **Gọn nhưng không mất dấu:** tool `off`, interim/long-running `true`, background `result`.
4. **Chỉ kết quả/lỗi:** tool/interim/long-running/thinking `off`, background `error`; explain explicitly that an apparently stuck task has no live clue until it fails or the user asks status.

Use `hermes config set` for every approved value (never hand-edit config). Verify with a redacted YAML read or `hermes config show`; never print secrets.

## Coordination pitfall (user preference, 2026-08-08)

Background-process notifications from unrelated farm jobs (e.g. tiktok_workflow workers) land in whatever chat is open. When the user is mid-topic on something else (like gateway setup): **report the worker status in 2–3 lines, do NOT launch into multi-step recovery**, and ask before retrying machines. The user explicitly pushed back on a hijacked conversation.

## Group chat (Telegram) gotchas

- BotFather **privacy mode ON** mặc định → bot chỉ thấy `/command`, reply vào tin bot, service messages.
- Tắt: BotFather → `/mybots` → Bot Settings → **Group Privacy → Off**. ⚠️ **BẮT BUỘC xoá + thêm lại bot vào group** — Telegram cache privacy state lúc bot join.
- Hoặc: promote bot làm group admin (luôn nhận mọi message, không cần đổi privacy).
- Chỉ trả lời khi được gọi + observe context:
  ```yaml
  gateway:
    platforms:
      telegram:
        allowed_chats: ["-100xxx"]
        group_allowed_chats: ["-100xxx"]
        require_mention: true
        observe_unmentioned_group_messages: true
  ```
  Env tương đương: `TELEGRAM_ALLOWED_CHATS`, `TELEGRAM_GROUP_ALLOWED_CHATS`, `TELEGRAM_OBSERVE_UNMENTIONED_GROUP_MESSAGES`. Unmentioned messages chỉ append làm observed context, không dispatch agent.

## Global rule & /personality

**Rule chung cho MỌI chat không override** (group mới tự nạp, không cần đụng tay): `agent.system_prompt`. Đổi nhanh không restart = `/personality`:
```yaml
agent:
  personalities:
    van_hanh_mac_dinh:           # /personality <tên>
      description: "..."
      system_prompt: "..."       # ghi config.yaml + áp in-memory ngay lượt sau
```
`/personality` (liệt kê) · `/personality <tên>` (đổi) · `/personality none` (xóa). Nhóm có override thắng global → `/personality` không đổi được rule của chúng.

## Verify round-trip

1. `hermes gateway status` / `hermes gateway list` — process running.
2. Log `$HERMES_HOME/logs/gateway.log`: `[Telegram] Connected to Telegram (polling mode)` + `✓ telegram connected` + `set_my_commands OK (52 cmds)`. Khi user nhắn: `Ignoring /start platform ping for session agent:main:telegram:dm:<user_id>` → session đã tạo (user_id phải khớp `TELEGRAM_ALLOWED_USERS`).
3. User nhắn `/start` + `/model` trên điện thoại → có reply = round-trip hoàn chỉnh.

## Pitfalls (merged)

- **MEDIA:/path attachments do GATEWAY process (host) gửi**, không phải trong container → terminal backend docker: path phải host-visible, mount qua `terminal.docker_volumes`, emit `MEDIA:/home/user/.hermes/cache/documents/...`.
- Token `[SILENT]` / `NO_REPLY` = agent giữ turn trong transcript nhưng không gửi gì ra chat; failed turns vẫn surface lỗi.
- Docs: `/docs/user-guide/gateway` → 404. Vào hermes-agent.nousresearch.com/docs → sidebar **"Messaging Platforms"**.
- Bot riêng cho từng project, không dùng chung token bot khác.
- Nhiều platform cùng lúc OK — thêm token từng platform rồi `hermes gateway restart`. ⚠️ `/new` KHÔNG restart gateway: config đọc 1 lần lúc khởi động; sửa config → bắt buộc restart (restart = ngắt agent đang chạy — chờ batch xong).
- Nâng cấp bot (optional): `/setcommands`; `status_indicator: true` dưới `gateway.platforms.telegram.extra` (mặc định off); `command_menu.max_commands` cap 60 (clamp 1..100).

## Báo cáo user (bắt buộc khi chạy batch dài)

- KHÔNG gửi từng bước / tool output trung gian — các lượt trung gian `[SILENT]`; chỉ 1 báo cáo cuối (kết quả từng máy, thời gian, file log) hoặc lỗi cần xử lý.
- Ảnh màn hình máy N: `adb -s <serial> exec-out screencap -p` (serial từ `config-machine-N.yaml` / workbook mapping), KHÔNG cần mở app mirror. Không tìm được serial → báo rõ, không đoán.
- VPS không thay được máy LAN (ADB USB bắt buộc cùng LAN); VPS chỉ làm não (terminal backend ssh / adb -H relay).

## Platform comparison

`references/platforms-comparison.md` — matrix voice/images/files/threads/reactions/typing/streaming ~28 platform + khuyến nghị (Telegram #1; Discord #2; WhatsApp rủi ro lock; SMS trả phí; Email cho alert).
Chi tiết gắn group↔repo (lấy chat_id, prompt chuẩn, verify state.db): `references/channel-overrides-repo-binding.md` + `references/channel-repo-binding.md`.

## See also

- `android-proxy-watcher` — farm VPN/proxy recovery ladder (device-level).
- `9router-proxy-ops` — model provider side of the same stack.
