# Chẩn đoán Hermes session lag

## Bước 1 — Process (kiểm tra RAM/CPU loại trừ)
```bash
# BẮT BUỘC single-quote ngoài, $_ không bị bash nuốt:
powershell.exe -NoProfile -Command 'Get-Process | Sort-Object WS -Descending | Select-Object -First 20 Name,Id,CPU,@{n="MemMB";e={[math]::Round($_.WS/1MB)}} | Format-Table -AutoSize | Out-String -Width 200'
```
- `Hermes.exe` PID cha = main; `--type=renderer` con = UI (đây là cái lag khi cuộn/gõ, ~800MB với session nặng)
- `msedgewebview2` ~1.1GB là WebView của desktop app — bình thường
- `python -m hermes_cli.main serve` = backend agent (PID 36088 dạng này); mỗi slash_worker = 1 session active

## Bước 2 — Per-session API stats (parser python)
```bash
python3 - <<'EOF'
import re, os, collections
pat = re.compile(r'\[(\d{8}_\d{6}_\w+)\].*API call #\d+.*in=(\d+).*out=(\d+).*latency=([\d.]+)s')
stats = collections.defaultdict(lambda: {'n':0,'in':0,'lat':0.0,'maxlat':0.0,'maxts':''})
for f in ['agent.log','agent.log.1']:
    p = os.path.join(os.path.expanduser('~'),'AppData','Local','hermes','logs',f)
    try:
        for line in open(p, encoding='utf-8', errors='replace'):
            m = pat.search(line)
            if not m: continue
            s, tin, lat = m.group(1), int(m.group(2)), float(m.group(4))
            st = stats[s]
            st['n']+=1; st['in']+=tin; st['lat']+=lat
            if lat>st['maxlat']: st['maxlat']=lat; st['maxts']=line[:19]
    except FileNotFoundError: pass
for s,st in sorted(stats.items(), key=lambda x:-x[1]['n']):
    print(f"{s}: calls={st['n']} avg_in={st['in']//max(st['n'],1)} avg_lat={st['lat']/max(st['n'],1):.1f}s max_lat={st['maxlat']:.1f}s @ {st['maxts']}")
EOF
```
Tiêu chí: `avg_in` ~300K+/call → thủ phạm (context bloat). `avg_lat` 10s+ = token-heavy, không phải network.

## Bước 3 — Compression events
```bash
grep -h 'Preflight compression' ~/AppData/Local/hermes/logs/agent.log | tail -10
grep -h 'context compression started\|context compression done' ~/AppData/Local/hermes/logs/agent.log | tail -10
```
- `Preflight compression: ~527,538 tokens >= 524,288 threshold` = sắp bị nén
- `messages=716->554 rough_tokens=~203,885` = nén xong, session vẫn còn 554 messages → UI vẫn nặng

## Ngưỡng nén thực tế
- Config: `compression.threshold` (0.5 default), `target_ratio` (0.2), `protect_last_n` (20)
- ctx deepseek qua 9router = 1,048,576 → threshold 0.5 = nén ở ~524K; 0.3 = ~314K; 0.2 = ~210K
- `DEEPSEEK_V4_REASONING_EFFORTS = ("low","high","max")`, default effort deepseek = "high"
- Config mới chỉ áp cho session mới (reasoning_config + compression resolve lúc session init)

## Config đã set máy này (2026-08-06)
- `compression.threshold: 0.3` (trước 0.5)
- `agent.reasoning_effort: max`, `reasoning_overrides: {gemini/gemini-3.6-flash: high}`
- Model: `cmc/deepseek/deepseek-v4-flash` @ custom:9router `http://127.0.0.1:20128/v1`
