---
name: hermes-session-tuning
description: "Chẩn đoán Hermes session lag (context bloat → compression threshold), tinh chỉnh compression, và kiểm tra/ép reasoning_effort khi route qua 9router (deepseek v4)."
---

# Hermes Session Tuning (lag + reasoning qua 9router)

## Trigger
- User kêu Hermes lag / session chậm dù RAM-CPU vẫn còn thừa
- Cần kiểm tra model deepseek đang chạy reasoning nào (THINK:auto vs high vs max trong 9router console log)
- Muốn ép reasoning effort chắc chắn qua 9router

## 1. Chẩn đoán lag — KHÔNG phải RAM/CPU, là context token
Thứ tự:
1. Process check: `powershell.exe -NoProfile -Command 'Get-Process | Sort-Object WS -Descending | Select-Object -First 20 Name,Id,CPU,...'` — **bọc toàn bộ lệnh PS trong single-quote**, `$_` bị bash/MSYS nuốt nếu dùng double-quote.
2. Hermes.exe renderer con (`--type=renderer`) + msedgewebview2 = UI Electron (renderer ~800MB với session nặng là bình thường). CPU cao không phải nguyên nhân chính.
3. Grep log per-session: `grep 'conversation_loop: API call' agent.log` → parser python tính `avg_in` mỗi session (xem `references/lag-diagnosis.md`). Session nào `avg_in` ~300K+ tokens/call là thủ phạm.
4. `grep 'Preflight compression'` + `grep 'context compression started/done'` → nén có chạy trễ không.

Nguyên nhân lag chính: **context tokens khổng lồ mỗi API call**. Deepseek ctx 1M + threshold 0.5 → nén chỉ ở ~524K, session chạy cả ngày ở 300-500K/call → latency ~11s/call, bất kể máy mạnh cỡ nào. UI renderer nặng (500+ messages trong DOM) là phụ.

Fix:
- `hermes config set compression.threshold 0.3` — nén sớm (~314K cho ctx 1M), giữ call ~200-250K. Trade-off: nén nhiều lần hơn, mất chi tiết sớm hơn. 0.2 = nhanh nhất nhưng nén liên tục.
- **Config chỉ áp cho session MỚI** — session cũ đã phình phải `/new` mới hết lag.
- Session 500+ messages nên `/new` dù đã nén (UI vẫn nặng).

## 2. Reasoning effort qua 9router (deepseek v4)
- Hermes config: `agent.reasoning_effort: max` → resolve thành `{'enabled': True, 'effort': 'max'}`. DeepSeek V4 chỉ chấp nhận **low/high/max** (`DEEPSEEK_V4_REASONING_EFFORTS`); "medium" bị reject → provider default.
- Wire: transport gửi `extra_body.reasoning={"enabled":true,"effort":"max"}` khi `_supports_reasoning_extra_body()` true = custom:9router + localhost:20128 + model `cmc/deepseek/*` (các custom endpoint khác KHÔNG gửi reasoning).
- 9router console log `THINK:X` đọc từ body sau translate, ưu tiên: `output_config.effort` → `thinking` → `reasoning_effort`/`reasoning.effort` → `thinkingConfig` → `enable_thinking`.
- **Cách ép chắc chắn 100%: đổi tên model kèm suffix** — `cmc/deepseek/deepseek-v4-flash(max)` hoặc `(high)`. 9router parse suffix làm override cứng `{mode:"level"}`; `(auto)`→auto; `(none|off)`→tắt; `(1234)`→budget tokens. Không suffix → đọc body, body không có gì → provider default (auto).
- **THINK:auto trong log DÙ config max** — nguyên nhân: (a) request chạy trước khi đổi config (reasoning_config resolve lúc session init → cần /new hoặc /model), (b) fallback gemini (`fallback_providers: gemini/gemini-3.6-flash` qua cùng 9router, `reasoning_overrides: high`), (c) Hermes version đang chạy khác code trên disk.
- Verify nhanh: `curl -s POST http://127.0.0.1:20128/v1/chat/completions -d '{"model":"cmc/deepseek/deepseek-v4-flash","messages":[{"role":"user","content":"hi"}],"max_tokens":5}'` — nhưng nguồn thật là console log 9router (cần auth, `/login`).

## Pitfalls
- PowerShell qua bash: `powershell.exe -NoProfile -Command '...'` — single-quote toàn bộ, `$_`/`$()` bị MSYS nuốt → ParserError.
- 9router bundle minified (`app/.next-cli-build/server/chunks/*.js`) — grep multi-line fail; đọc bằng python `open(..., errors='replace')` + `re.finditer`.
- `hermes config set KEY VAL` là đường chuẩn — AGENTS.md cấm hand-edit config.yaml.
- Máy này HERMES_HOME = `C:\Users\Kibe\AppData\Local\hermes` (config.yaml, logs, source), KHÔNG phải `~/.hermes`. Log: `logs/{agent,errors,desktop,gui}.log`.
- 9router hay có bản mới: check banner dashboard (vd v0.5.45 → v0.5.50).

## Log forensics (`~/AppData/Local/hermes/logs/agent.log`, agent.log.1, …)

Parse with Python regex:
- Per-session API stats: `agent.conversation_loop: API call #N: ... in=<tokens> out=... latency=<s>s` — aggregate avg_in, avg_latency, max_latency per session id.
- **Regex thực tế đã chạy được (2026-08-07)**: `API call #(\d+):.*?in=(\d+) out=(\d+) total=(\d+) latency=([\d.]+)s` — format đầy đủ: `API call #15: model=cmc/deepseek/deepseek-v4-flash provider=custom in=237237 out=578 total=237815 latency=12.5s`. Pattern `in=[0-9]+.*latency=[0-9.]+s` cũng OK nếu chỉ cần 2 field.
- `agent.turn_context: conversation turn: session=<id> ... history=<n>` — message count.
- `agent.turn_context: Preflight compression: ~N tokens >= threshold` — compression trigger.
- `agent.conversation_compression: context compression started/done` — messages N->M, rough_tokens. A compression run blocks the session ~1-2 min (visible "lag spike").

Rule of thumb from real data: avg_in > ~250-300K tokens/call ⇒ multi-second+ latency; 700+ messages ⇒ UI jank; a session at 500K+ tokens pre-compression is the laggy one.

## Memory tool ≠ lag driver (user hỏi 2026-08-07 — trả lời kèm số liệu)

User hỏi "dọn memory có giúp lag/tốn quota k". Trả lời verify bằng số liệu thật:
- Memory tool = `~/AppData/Local/hermes/.../memories`, bơm vào system prompt mỗi turn. 2,200 chars ≈ **~600 token ≈ 0.3%** của 1 API call 193K token. Dọn memory giảm quota RẤT NHỎ, không giảm lag.
- **Lag thật = context token bloat**: session 2,659 calls → avg **in=193,200** / max **483,924** tokens/call, latency avg **17.0s** / max **159.6s**, 276 calls >300K. Đây là số liệu chuẩn khi user kêu lag.
- Đừng đề xuất dọn memory như fix lag — fix thật là `/new` session (reset về ~10K/call) + tránh 2 session nặng song song (cùng renderer + 9router → nhân đôi tải).
- Dọn memory vẫn đáng làm: giảm quota nhẹ + focus tốt hơn (entry cũ/ít dùng làm model phân tâm → retry → tốn quota gián tiếp). Nhưng nói rõ với user là không phải fix lag.

## Cross-session interference

Multiple heavy sessions share one renderer process and one 9router instance — running two 500K-token sessions simultaneously doubles proxy load and UI DOM. Advise closing/`/new`-ing one when both are active.

## References
- `references/lag-diagnosis.md` — lệnh chẩn đoán + parser python per-session stats.
- `references/reasoning-effort-wire-path.md` — source-map file:line đã verify (Hermes + 9router JS) cho toàn bộ đường reasoning.
