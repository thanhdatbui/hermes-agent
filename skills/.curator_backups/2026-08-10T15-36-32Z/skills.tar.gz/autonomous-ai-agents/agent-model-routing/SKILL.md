---
name: agent-model-routing
description: "Route coordinator and worker agents by task difficulty and cost."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [agents, orchestration, model-routing, delegation, cost]
    category: autonomous-ai-agents
    related_skills: [hermes-agent, codex, opencode]
---

# Agent Model Routing Skill

Use this skill when one agent coordinates work while another model or coding CLI performs implementation. It defines routing by role, difficulty, quota, and verification needs. It does not prescribe a permanent ranking for models; provider catalogs and model IDs change, so verify the live catalog before configuring.

## When to Use

- Hermes should plan, delegate, and verify rather than implement everything itself.
- A coding worker has different quota or quality characteristics from the coordinator.
- Multiple models such as Codex and OpenCode Go need role-based routing.
- A local OpenAI-compatible router is being considered for centralized credentials and fallback.

## Prerequisites

- Know the actual provider/model IDs from the provider's current model picker or CLI.
- Confirm which agent can call tools and which agent owns filesystem changes.
- Keep a verification path: diff inspection, tests, logs, or another concrete artifact.

## How to Run

1. Classify the request as routine implementation, architecture/review, or debugging/recovery.
2. Select a coordinator model that is cheap and reliable at planning/tool orchestration.
3. Select a worker model based on implementation difficulty, not brand preference.
4. Delegate with explicit scope, acceptance criteria, workdir, and proof requirements.
5. Inspect the worker's result and run or request verification.
6. Escalate only after evidence: normal worker → stronger review model → recovery/debug model.

## Quick Reference

| Role | Default strategy |
|---|---|
| Coordinator | Cheap, stable model with reliable tool calls and delegation |
| Routine worker | Fast coding model with good repository execution |
| Architecture/review | Strong reasoning model |
| Recovery/debugging | Strong reasoning model after a classified failure |
| Final gate | Coordinator verifies proof; never trust a completion claim alone |

A practical split when Codex quota is available is: Hermes coordinator on a low-cost OpenCode Go model; **Codex Sol for BOTH planning AND coding**; Codex Luna ONLY for debugging under D:/Taadaa automation workflows. Use Claude Opus at low effort as the default independent reviewer, with OpenCode only as reviewer fallback when Claude quota/provider access fails. The loop is Worker implementation → Reviewer audit → Worker accepts/rejects each finding with evidence → Reviewer consensus re-check, bounded by a maximum round count and persisted state/artifacts.

**Latest routing override — 2026-08-09 (highest precedence for this user):**
- When the coordinator session is **gpt-5.6-terra**, it remains read-only; its fresh implementation worker is **gpt-5.6-luna with reasoning_effort=high**.
- Before `delegate_task`, configure the Hermes delegation pin exactly: `delegation.provider: cockpit`, `delegation.model: gpt-5.6-luna`, `delegation.reasoning_effort: high`. Do not inherit Terra for implementation and do not substitute Luna/max unless the user explicitly requests it.
- The bound Luna/high worker owns the exclusive patch/test scope; Terra inspects the diff and verifies independently.

**This user's model routing (CRITICAL — explicitly corrected multiple times; refreshed 2026-08-06):**
- **Hermes (deepseek-v4-flash, 9router)** = coordinator + task SIMPLE + triage/đọc log + **vòng debug nhanh**. Debug nên để deepseek (chạy nhanh); dựng script/bài mới → Codex.
- **Codex gpt-5.6-luna/max** = worker implement/live (AGENTS.md: worker duy nhất được patch/live). Trong Codex app, spawn subagent cùng hệ sinh thái GPT (luna/terra/sol) cho mượt.
- **gpt-5.6-terra / deepseek-v4-pro** = audit/review CHÍNH (READ-ONLY — đưa root-cause/plan, KHÔNG patch; người thực thi lại là Luna/max hoặc Hermes).
- **gpt-5.6-sol** = plan tổng + case khó nhất (high→extra_high→ultra, session MỚI mỗi nấc, làm khác đi).
- **Claude** = audit hard-trigger / plan tổng, quota-gated (`claude-quota-preflight.ps1`, 5h<85% + weekly<90%).
- **Gemini 3.6 flash** = VISION cho deepseek + fallback audit CUỐI cùng. KHÔNG làm auditor chính — user đánh giá "bợ dái, không tư duy phản biện" (sycophant, no critical thinking). Đã cấu hình `auxiliary.vision`.
- **OpenCode** = fallback reviewer (sau terra/pro/sol) — **đã set up thành lớp audit free TRƯỚC Gemini (2026-08-06)**: **CASCADE model mạnh→yếu, hết quota/502 mới qua model kế**: `nemotron-3-ultra-free` (mạnh nhất, hay 502 ResourceExhausted) → `ling-3.0-flash-free` (ổn định, verdict thật) → `longcat-2.0-free` → `north-mini-code-free` (fallback nhẹ). KHÔNG dùng `deepseek-v4-flash-free` (trùng family user); `mimo/laguna` trả template giả → bỏ. Wrapper `D:\Taadaa\tools\invoke-opencode-audit.ps1` (chạy OK, exit 0, output JSONL **UTF-16** — đọc bằng `encoding='utf-16'`, verdict nằm trong các part `{"type":"text","part":{"type":"text","text":...}}`). **Audit chain đã chốt: OpenCode free (cascade) → Gemini 3.6 Flash → Command Code → fresh Codex (Sol/Terra)** — OpenCode là lớp MỚI đứng TRƯỚC Gemini. OpenCode phát hiện findings xuyên section (P1/P2/P3 — các section khác ngoài vùng sửa vẫn mâu thuẫn Luna-only) mà ds-pro + Gemini không thấy — dùng khi cần audit chéo policy toàn file. `freemodel/*` (gpt-5.6-luna free) → 401 Insufficient balance — không dùng được. **PITFALL (user corrected 2026-08-06):** luôn chạy `opencode models | grep -i free` TRƯỚC khi chọn model audit — **KHÔNG chọn model trùng family với model chính của user** (user đang dùng deepseek ở mọi nơi → `opencode/deepseek-v4-flash-free` bị user chặn vì "gọi deepseek của nó hơi bị trùng"). PHẢI TEST từng free model bằng `opencode run` thật với ĐÚNG args wrapper (`--agent taadaa-review --format json`): `nemotron-3-ultra-free` → 502 ResourceExhausted (Nvidia worker limit 32/32) khi dùng agent+json nhưng thỉnh thoảng chạy được (quota reset); `mimo-v2.5-free`/`laguna-s-2.1-free` → trả template giả (echo format, không audit thật) hoặc không output; **`ling-3.0-tiny-free` → ổn định + verdict thật (đọc file, findings line-level; **tên MỚI 2026-08-07 thay `ling-3.0-flash-free` — catalog đổi, smoke OK**)`. **PITFALL tốc độ (2026-08-07)**: `ling-3.0-tiny-free` audit cả repo timeout >600s (exit 124) — **phải dùng prompt FOCUSED (liệt kê đúng file + câu hỏi, cấm quét toàn repo) + timeout 900s**; `north-mini-code-free` hiện **401 upstream** (không dùng được); `longcat-2.0-free` chạy được + nhanh hơn (smoke OK). **PITFALL RepoRoot (2026-08-07)**: `invoke-opencode-audit.ps1 -RepoRoot D:\Taadaa` → opencode glob `**/*.py` thấy worktree cũ (`automation-core-codex-tiktok-add-phone-vietnamese`, `context-worktrees/Tiktok_Reg-reduce-context`) → audit NHẦM file, báo "feature không tồn tại" dù có thật (nemotron cũng đạt MAX_STEPS trước khi xong = audit không hoàn chỉnh). **Phải trỏ RepoRoot vào repo CHÍNH (`D:\Taadaa\automation-core` / `D:\Taadaa\Tiktok_Reg`), audit multi-repo chia 2 prompt chạy 2 lần.** Chi tiết matrix + cascade: `references/opencode-free-model-audit.md`.
- **Escalation ladder Taadaa**: Hermes flash (simple) → fail → Codex Luna/max (worker, làm khác đi) → vẫn fail → deepseek-v4-pro HOẶC terra review (read-only, plan mới) → fresh Luna/max làm theo plan → case khó nhất → Sol. Cùng 1 evidence chỉ review 1 lần (1 audit slot).
- **Hermes `delegate_task` subagents: model NOT selectable per call** (source-verified 2026-08-05 in `tools/delegate_tool.py`). Subagents run whatever `delegation.provider/model/reasoning_effort` config sets, or inherit the parent model when unset — so a Hermes session on a cheap model (e.g. 9router flash) cannot spawn a Luna/max worker or a Sol planner through `delegate_task`. Per-role model mixing (worker Luna/max + planner Sol + auditor) is a **Codex-app capability but ONLY within its GPT catalog** (verified 2026-08-05: `~/.codex/cockpit-local-access-model-catalog.json` lists exactly 10 models — gpt-5.6-luna/sol/terra, gpt-5.5, gpt-5.4, gpt-5.4-mini, gpt-5.3-codex, gpt-5.3-codex-spark, GPT Image 2, codex-auto-review; **no Gemini/Claude/DeepSeek/Command Code**). Non-GPT audit models (Gemini/Claude/Command Code/OpenCode/DeepSeek) therefore go through **CLI wrappers (`invoke-*.ps1` → 9router `:20128`) in BOTH apps** — the Codex GUI cannot spawn them as subagents either; the 9router provider exists only in Codex CLI `config.toml`, not in the app catalog. A Hermes subagent with a *different* model is possible only when the model shares the parent's provider (e.g. `delegation.provider: 9router` + `delegation.model: cmc/deepseek/deepseek-v4-pro` works — same provider, different model; a Gemini/Claude/Command Code subagent does not). On Hermes, route plan/audit roles through CLI wrappers instead. To make Hermes subagents run Luna/max, set `delegation.provider: cockpit`, `delegation.model: gpt-5.6-luna`, `delegation.reasoning_effort: max` (cockpit = local custom provider at `http://localhost:60818/v1`, `api_mode: codex_responses`, key `COCKPIT_API_KEY`, models gpt-5.6-luna/sol/terra — already defined in this machine's config). This cockpit path is **live-verified** (2026-08-05: `POST /v1/responses` model `gpt-5.6-luna` + `reasoning.effort=max` → `status: completed`). Re-verified on Hermes **0.20.0** (2026-08-05): `delegate_task` STILL has no per-task model — `_MODEL_HIDDEN_TASK_FIELDS` is only `{acp_command, acp_args}`, not model. Source-level details live in skill `hermes-orchestration-dispatcher`, `references/hermes-subagent-model-routing.md`.

**Live capability matrix** (9router/cockpit probes, vision model status, delegation config recipes): `references/model-capability-matrix.md`. Re-probe before relying — credentials/quota change. **9router reasoning control (THINK:X trong console log, `providerThinking` DB settings, mode `"thinking"` invalid→auto, suffix `(high)`/`(max)` bị 403, deepseek effort allowed set, session compression threshold): `references/9router-reasoning-thinking-control.md`.** **UPDATE 2026-08-06: user added GPT upstream to 9router → `gpt-5.6-luna/terra/sol` (bare or `cx/` prefix) now respond via 9router HTTP `:20128`** (curl `/v1/chat/completions` → 200 `resp_...`). This REVERSES the earlier "Terra/Sol are Codex-CLI-only" claim: Hermes can now call terra/sol in-app via HTTP for plan/audit — no `codex exec` needed. Codex app catalog (`cockpit-local-access-model-catalog.json`) is unchanged (still GPT-only, no Gemini/Claude/DeepSeek); but the 9router route now covers GPT too. See `references/9router-http-calling.md` for verified call recipes (tool_choice=none, continuation rounds, Claude 403, Kimi finish=length). **Vision fallback is now WORKING on this machine**: `gemini/gemini-3.6-flash` via 9router sees images (≥64x64 px; tiny 2x2/8x8 test PNGs get `400 Unable to process input image` — a size quirk, not a capability gap), and `auxiliary.vision` is configured so the DeepSeek coordinator auto-falls back to Gemini for image analysis. See the reference for the exact config + `hermes config set` workflow (agent cannot edit config.yaml directly).

**2-mode symmetric orchestration (user-final, 2026-08-06 — file `D:\Taadaa\HERMES_SUBAGENT_RULES.md`):**
Model self-identifies the app from 2 signals in its system prompt: (1) Model line (`cmc/deepseek/deepseek-v4-flash` = Hermes; `gpt-5.6-luna` = Codex), (2) tool set (Hermes has `skill_view`/`memory`/`cronjob`/`session_search`; Codex has `apply_patch`/MCP).
- **HERMES mode** (main=deepseek-v4-flash): worker = deepseek-v4-flash/high via `delegate_task` (inherits parent model) → fail → deepseek-v4-pro (9router HTTP, read-only plan — **rescuer/auditor chuẩn, hợp lệ**) → fail → gpt-5.6-terra → sol (9router HTTP, read-only). Audit: v4-pro (thường) → terra (khó vừa) → sol (khó thật). Vision = gemini-3.6-flash.
- **CODEX mode** (main=gpt-5.6-luna/max): worker = luna/max native subagent → fail → terra/sol → fail → deepseek-v4-pro (read-only). Audit = deepseek-v4-pro.
- Golden rule: worker = subagent spawned by the same app (the ONLY thing that patches/runs live); rescuers/auditors (v4-pro/terra/sol) are READ-ONLY advisors — they produce plan/verdict, never patch. **v4-pro auditing/rescuing a flash worker is LEGITIMATE (same deepseek family, higher tier — user-approved 2026-08-07; it is the standard rescuer in the escalation table). "Crossover reviewer from a different family" is NOT a hard gate banning v4-pro — it is only a strengthening preference: hard-medium → terra, hard → sol; Codex luna → v4-pro (different vendor).**

**Worker policy FINAL (2026-08-06 — v8; SUPERSEDES đoạn "Worker fallback equivalence" cũ bên dưới — đó là thiết kế v1–v7 user đã bỏ):** AGENTS.md Taadaa đã đơn giản hoá lần cuối — worker theo APP, không spec: Hermes (ds-flash) → worker `deepseek-v4-flash/high` (UPDATE 2026-08-06 tối: user sweep reasoning max→high TOÀN BỘ — config `agent.reasoning_effort: high`, mọi AGENTS.md + HERMES_SUBAGENT_RULES.md đã đổi `flash/max`→`flash/high`, `reasoning_effort=max`→`=high`, `deepseek-v4-flash`/`max`→`/high`; `gpt-5.6-luna/max`/`Luna/max`/`Sol/max` GIỮ NGUYÊN); Codex (luna) → worker `gpt-5.6-luna/max`; **LUNA≡FLASH equivalent roles** — worker nào làm task nào cũng được, kể cả live (user chốt 2 model ngang nhau, bỏ hẳn hard gate "live phải luna"); **KHÔNG model fallback trong policy** (hết quota/outage = tool layer: Hermes `fallback_providers`, 9router auto-route — NGOÀI policy); **session-as-worker = fallback DUY NHẤT**: spawn worker subagent CONFIRMED fail (runtime-unavailable/capability-unavailable/429 có source+provider+pin) → ghi `SUBAGENT_RUNTIME_UNAVAILABLE` trước side effect → session tự làm bằng model session; timeout/unknown/ambiguous → reconcile (prove không còn worker/session/process/lease/action) → không chứng minh được → `LIVE_ATTEMPT_UNKNOWN_AFTER_CRASH` + `FINAL_BLOCKED`. **Fallback ordering (v8): (1) in-process subagent với session model → (2) gated Codex CLI transport (Codex sessions ONLY, cùng session-model pin) → (3) session-as-worker (mọi session); Hermes không có CLI route — thẳng (1)→(3).** Bỏ hẳn khái niệm effective pin / `WORKER_PROFILE_MISMATCH`-cho-fallback, bỏ hẳn section Coordinator Direct Fallback, Model Routing = 1 reference + 2 mapping. **Vòng đồng bộ cuối (sau OpenCode findings):** 6 findings P1/P2 — các section KHÁC ngoài 2 vùng chính vẫn mâu thuẫn Luna-only (v4 header L8, canonical block L76, "DeepSeek never executor" L145, "remains Luna/max" L936, fallback ordering chưa rõ, watchdog/escalation headings) + 3 P3 cosmetic → fix hết, toàn file hết mâu thuẫn Luna-only (grep `sole desktop patch/live worker`/`remains Luna/max` = 0 ngoài deprecated section). **Kết quả cuối: 4 audit độc lập APPROVE** (ds-pro plan 7/7 + ds-pro file thật 5/5 + Gemini file thật 6/6 + OpenCode free APPROVE — Claude bị chặn weekly 91%≥90% exit 22) + verify 20/20 + validator exit 0; hash cuối `07bade5e66ee7a37c4c00ba561de56dab214e23d5374b58abcfa1913482993cc`. Rule chi tiết: `D:\Taadaa\HERMES_SUBAGENT_RULES.md`. Đừng áp dụng fallback-equivalence/effective-pin bên dưới cho policy hiện tại. **Recipe sweep hàng loạt flash/max→flash/high (pattern thay thế, PITFALL Python PermissionError → dùng sed, verify grep): `references/rule-file-bulk-reasoning-sweep.md`.**

**Audit gate — mandatory vs skipped (user-final 2026-08-06):** audit is a GATE for hard cases, NOT a default for every task.
- **Thường (debug 1 bug, 1 file consumer)**: flash worker sửa → fail → v4-pro cứu (read-only plan) → flash làm theo → test pass → **DONE, KHÔNG audit**.
- **Khó vừa (multi-file, 1 repo, logic phức tạp)**: v4-pro plan → flash làm → test pass → audit CHỈ nếu rủi ro (logic shared/ambiguous) → **terra**.
- **Khó thật (policy/core/live/recovery/lock/multi-repo/kiến trúc)**: backup → v4-pro plan → **Sol audit (bắt buộc, là gate)** → worker sửa theo findings → verify.
- **Khó vừa gọi terra, khó quá mới gọi sol** — không đốt sol cho việc terra xử lý được. Audit REJECT = sửa plan theo findings + re-audit (material change mở slot mới), KHÔNG implement plan bị reject.

**Pitfall**: Do NOT use Codex Luna for planning or routine coding — user has explicitly rejected this routing. Luna is debugging-only for this user's automation ecosystem.

**Pitfall (2026-08-06)**: Do NOT use Gemini as the primary audit/reviewer — user: "bợ dái lắm, không có tư duy phản biện" (sycophantic, no critical thinking). Gemini = vision + last-resort audit fallback only. Do NOT set `delegation.model` to Luna/max on Hermes — user decided against it; the rule file is `D:\Taadaa\HERMES_SUBAGENT_RULES.md` (pointer in memory). **Terra/Sol are READ-ONLY advisors — they never patch; deepseek-v4-pro via 9router is also review-only. After a reviewer verdict, a FRESH Luna/max (or Hermes for small fixes) executes the plan — reviewers are never the executor.**

**Pitfall (2026-08-06, policy-change plan)**: A weak-model (deepseek-v4-pro) policy plan is almost always REJECTED by a strong auditor (GPT-5.6-Sol) for: (1) repeating the same rule 3× with different force (`may`/`is pinned`/`is permitted`) instead of ONE canonical source; (2) classification not fail-closed (no consumer-root allowlist, no symlink/submodule/shared-path handling, tests with network/ADB side effects, scope drift mid-task); (3) direct-fallback clauses that punch through core gates (fallback banning "scheduler/lock/live" but not core offline edits); (4) edit boundaries by line-number drifting and swallowing the next heading (must anchor by unique heading/marker, verify 1 start/end, never include other headings in the payload); (5) duplicating rules across sections instead of referencing; (6) missing scope-drift gates (worker must self-stop + return handoff when it detects ADB/live/credential/recovery path); (7) inferring validator green from the script's name instead of running baseline-before + after; (8) contradictory escalation advice (banning "escalate consumer-normal to Luna" while recommending "big task → Luna"). **Never hand a raw v4-pro plan to a flash worker to implement — audit first; REJECT = fix plan + re-audit, not implement.** Full findings: `hermes-orchestration-dispatcher` SKILL.md → "AGENTS.md scope-split".

**Pitfall (2026-08-06, policy-change plan — REJECT lần 3, root cause = user decision)**: Khi plan policy-change bị auditor REJECT nhiều vòng liên tiếp, kiểm tra xem **chính quyết định user có phải gốc rễ không**. Vụ AGENTS.md scope-split: user quyết định "fallback luna↔flash ngang hàng cho CẢ live" → GPT-5.6-Sol REJECT 3 lần (v1: 8 findings — lặp rule, classification không fail-closed, edit-boundary drift, validator không baseline; v2: fallback tự mâu thuẫn với "Luna sole worker"; v3: live-STOP phải tách theo lớp, `unavailable` taxonomy trộn model/transport, effective pin không được chứng minh, dispatch-generation không lifecycle, Model Routing vẫn restate contract, validator gate không kiểm chứng). **Khi auditor REJECT nhiều vòng vì một quyết định policy bất thường của user (VD fallback model ngang hàng cho live — 2 model khác hãng/capability fallback lẫn nhau cho live rủi ro cao), đừng tự làm vòng 4 — chỉ ra cho user rằng chính quyết định đó là gốc rễ và đề xuất đơn giản hoá** (bỏ fallback flash cho live → live = Luna DUY NHẤT, luna down → STOP + `SUBAGENT_RUNTIME_UNAVAILABLE` → Sol APPROVE nhanh, vẫn đạt mục tiêu chính: Hermes flash patch consumer-normal). Fallback model cho live là chỗ auditor bảo vệ mạnh nhất (lạm dụng fallback). Chi tiết: `hermes-orchestration-dispatcher` SKILL.md → "AGENTS.md scope-split v3".

## Procedure

### Portable Hermes setup and migration

When moving a coordinator/worker setup to another PC, separate portable behavior from machine-local state:

1. Move or clone the Hermes source repo if it contains custom code or bundled skill changes; the repo alone is not the complete user configuration.
2. Export the active Hermes profile with `hermes profile export default -o <archive>.tar.gz`, then import it on the destination with `hermes profile import <archive>.tar.gz --name default`. This carries user-facing configuration, skills, plugins, cron, scripts, persona, and related preferences while intentionally excluding credentials and runtime databases.
3. Install the external worker CLIs independently on the destination (Claude Code and Codex) and verify their versions.
4. Authenticate again on the destination with each CLI and with Hermes (`hermes auth add ...`) instead of copying `.env`, `auth.json`, or CLI credential directories through Git/cloud storage.
5. Run `hermes doctor`, `hermes skills list`, and `hermes tools list`; execute a harmless task in a Git repository to verify the coordinator → worker → verification path.
6. If user-level skills override bundled skills, ensure the exported `skills/` content is included and inspect the destination's effective skill list after import.

Do not copy the entire Hermes home blindly: caches, SQLite state, locks, absolute paths, and secrets are machine-specific. A manual migration should copy `config.yaml`, `SOUL.md`, user `skills/`, `plugins/`, `cron/`, and `scripts/`, then re-authenticate secrets separately.

### Coordinator prompt contract

Tell the coordinator explicitly:

- Do not implement the main task itself unless a tiny coordinator-side fix is necessary.
- Break the request into independently verifiable worker tasks.
- Require workers to report changed files, commands run, and concrete output.
- Inspect the result and classify failures before retrying.
- Do not report success without proof.

Keep coordinator access to read-only inspection and verification tools where possible. Do not remove its ability to inspect diffs, logs, and tests: a delegation-only coordinator cannot validate worker claims.

### Escalation policy

- Routine implementation: fast worker first.
- Design or broad refactor: stronger worker/reviewer first.
- Test failure: classify the failure, then use a different recovery action/model; do not blindly rerun.
- Repeated identical failure: stop and report the signature and artifact rather than looping.

### Router decision

Use a local router when several clients need one credential store, provider fallback, or one stable OpenAI-compatible endpoint. First smoke-test the direct path (client → provider), then add the router hop. In the routed path:

```text
client → local router → upstream provider/model
```

Store the upstream credential in the router. Configure the client with the router endpoint and the router's local authentication key, not the upstream credential. Keep direct configuration when only one client needs the provider or when simpler debugging is more valuable than centralized routing.

## Pitfalls

- Do not use the strongest coding model for every coordinator turn; orchestration usually does not need maximum coding ability.
- Do not assume a model name or catalog is current; verify the live `/models` list/provider metadata.
- Do not confuse an upstream provider key with a local router key.
- Do not make the coordinator pure delegation-only if no component can independently inspect and verify results.
- Do not retry the same failed worker command without a changed hypothesis or recovery action.
- Do not claim success from a worker's prose alone.
- **Do not leave `delegation.max_iterations` at the default for large multi-repo/live tasks** (2026-08-10, measured): `max_iterations` is a CEILING, not a target — a worker that finishes early still stops early, so raising it costs nothing on small tasks, but at cap 50 multi-repo patch+verify+live tasks (which realistically need 70–120 calls) drop mid-task. Measured over 87 delegation summaries: 21 dropped (24%) overall, 62% on the heaviest day; each drop loses context and the successor worker re-triages from scratch — more expensive than letting the worker run. Fix: raise to 100 for multi-repo sweeps (user-approved), re-evaluate at 150 if drops persist near 90–100. When a worker still drops, dispatch a SUCCESSOR with triage state attached (summary file path + exact before→after list), never a blank spec. Measure the drop rate from the delegation cache: `~/AppData/Local/hermes/cache/delegation/subagent-summary-*.txt`, grep per file for "hết lượt tool"/"giới hạn tool"/"chưa hoàn tất"/"LIVE_PARTIAL".

## Verification

For each worker task, record:

- selected model and reason;
- workdir/repository scope;
- changed files or explicit no-change result;
- test/build/lint commands and actual output;
- unresolved risks or recovery attempts.

For router setup, verify the local endpoint with a harmless smoke request, confirm the requested model ID is accepted, and confirm the upstream key is not exposed in the client configuration or logs.
